DROP TABLE cmf_admin_menu;

CREATE TABLE `cmf_admin_menu` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '父菜单id',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '菜单类型;1:有界面可访问菜单,2:无界面可访问菜单,0:只作为菜单',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '状态;1:显示,0:不显示',
  `list_order` float NOT NULL DEFAULT '10000' COMMENT '排序',
  `app` varchar(40) NOT NULL DEFAULT '' COMMENT '应用名',
  `controller` varchar(30) NOT NULL DEFAULT '' COMMENT '控制器名',
  `action` varchar(30) NOT NULL DEFAULT '' COMMENT '操作名称',
  `param` varchar(50) NOT NULL DEFAULT '' COMMENT '额外参数',
  `name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '菜单名称',
  `icon` varchar(20) NOT NULL DEFAULT '' COMMENT '菜单图标',
  `remark` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '备注',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `status` (`status`) USING BTREE,
  KEY `parent_id` (`parent_id`) USING BTREE,
  KEY `controller` (`controller`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=211 DEFAULT CHARSET=utf8mb4 COMMENT='后台菜单表';

INSERT INTO cmf_admin_menu VALUES("1","0","0","0","9999","admin","Plugin","default","","插件中心","cloud","插件中心");
INSERT INTO cmf_admin_menu VALUES("2","1","1","0","1000","admin","Hook","index","","钩子管理","","钩子管理");
INSERT INTO cmf_admin_menu VALUES("3","2","1","0","1000","admin","Hook","plugins","","钩子插件管理","","钩子插件管理");
INSERT INTO cmf_admin_menu VALUES("4","2","2","0","1000","admin","Hook","pluginListOrder","","钩子插件排序","","钩子插件排序");
INSERT INTO cmf_admin_menu VALUES("5","2","1","0","1000","admin","Hook","sync","","同步钩子","","同步钩子");
INSERT INTO cmf_admin_menu VALUES("6","0","0","1","10","admin","Setting","default","","设置","cogs","系统设置入口");
INSERT INTO cmf_admin_menu VALUES("7","6","1","0","1000","admin","Link","index","","友情链接","","友情链接管理");
INSERT INTO cmf_admin_menu VALUES("8","7","1","0","1000","admin","Link","add","","添加友情链接","","添加友情链接");
INSERT INTO cmf_admin_menu VALUES("9","7","2","0","1000","admin","Link","addPost","","添加友情链接提交保存","","添加友情链接提交保存");
INSERT INTO cmf_admin_menu VALUES("10","7","1","0","1000","admin","Link","edit","","编辑友情链接","","编辑友情链接");
INSERT INTO cmf_admin_menu VALUES("11","7","2","0","1000","admin","Link","editPost","","编辑友情链接提交保存","","编辑友情链接提交保存");
INSERT INTO cmf_admin_menu VALUES("12","7","2","0","1000","admin","Link","delete","","删除友情链接","","删除友情链接");
INSERT INTO cmf_admin_menu VALUES("13","7","2","0","1000","admin","Link","listOrder","","友情链接排序","","友情链接排序");
INSERT INTO cmf_admin_menu VALUES("14","7","2","0","1000","admin","Link","toggle","","友情链接显示隐藏","","友情链接显示隐藏");
INSERT INTO cmf_admin_menu VALUES("15","6","1","0","1000","admin","Mailer","index","","邮箱配置","","邮箱配置");
INSERT INTO cmf_admin_menu VALUES("16","15","2","0","1000","admin","Mailer","indexPost","","邮箱配置提交保存","","邮箱配置提交保存");
INSERT INTO cmf_admin_menu VALUES("17","15","1","0","1000","admin","Mailer","template","","邮件模板","","邮件模板");
INSERT INTO cmf_admin_menu VALUES("18","15","2","0","1000","admin","Mailer","templatePost","","邮件模板提交","","邮件模板提交");
INSERT INTO cmf_admin_menu VALUES("19","15","1","0","1000","admin","Mailer","test","","邮件发送测试","","邮件发送测试");
INSERT INTO cmf_admin_menu VALUES("20","6","1","0","1000","admin","Menu","index","","后台菜单","","后台菜单管理");
INSERT INTO cmf_admin_menu VALUES("21","20","1","0","1000","admin","Menu","lists","","所有菜单","","后台所有菜单列表");
INSERT INTO cmf_admin_menu VALUES("22","20","1","0","1000","admin","Menu","add","","后台菜单添加","","后台菜单添加");
INSERT INTO cmf_admin_menu VALUES("23","20","2","0","1000","admin","Menu","addPost","","后台菜单添加提交保存","","后台菜单添加提交保存");
INSERT INTO cmf_admin_menu VALUES("24","20","1","0","1000","admin","Menu","edit","","后台菜单编辑","","后台菜单编辑");
INSERT INTO cmf_admin_menu VALUES("25","20","2","0","1000","admin","Menu","editPost","","后台菜单编辑提交保存","","后台菜单编辑提交保存");
INSERT INTO cmf_admin_menu VALUES("26","20","2","0","1000","admin","Menu","delete","","后台菜单删除","","后台菜单删除");
INSERT INTO cmf_admin_menu VALUES("27","20","2","0","1000","admin","Menu","listOrder","","后台菜单排序","","后台菜单排序");
INSERT INTO cmf_admin_menu VALUES("28","20","1","0","1000","admin","Menu","getActions","","导入新后台菜单","","导入新后台菜单");
INSERT INTO cmf_admin_menu VALUES("29","6","1","0","1000","admin","Nav","index","","导航管理","","导航管理");
INSERT INTO cmf_admin_menu VALUES("30","29","1","0","1000","admin","Nav","add","","添加导航","","添加导航");
INSERT INTO cmf_admin_menu VALUES("31","29","2","0","1000","admin","Nav","addPost","","添加导航提交保存","","添加导航提交保存");
INSERT INTO cmf_admin_menu VALUES("32","29","1","0","1000","admin","Nav","edit","","编辑导航","","编辑导航");
INSERT INTO cmf_admin_menu VALUES("33","29","2","0","1000","admin","Nav","editPost","","编辑导航提交保存","","编辑导航提交保存");
INSERT INTO cmf_admin_menu VALUES("34","29","2","0","1000","admin","Nav","delete","","删除导航","","删除导航");
INSERT INTO cmf_admin_menu VALUES("35","29","1","0","1000","admin","NavMenu","index","","导航菜单","","导航菜单");
INSERT INTO cmf_admin_menu VALUES("36","35","1","0","1000","admin","NavMenu","add","","添加导航菜单","","添加导航菜单");
INSERT INTO cmf_admin_menu VALUES("37","35","2","0","1000","admin","NavMenu","addPost","","添加导航菜单提交保存","","添加导航菜单提交保存");
INSERT INTO cmf_admin_menu VALUES("38","35","1","0","1000","admin","NavMenu","edit","","编辑导航菜单","","编辑导航菜单");
INSERT INTO cmf_admin_menu VALUES("39","35","2","0","1000","admin","NavMenu","editPost","","编辑导航菜单提交保存","","编辑导航菜单提交保存");
INSERT INTO cmf_admin_menu VALUES("40","35","2","0","1000","admin","NavMenu","delete","","删除导航菜单","","删除导航菜单");
INSERT INTO cmf_admin_menu VALUES("41","35","2","0","1000","admin","NavMenu","listOrder","","导航菜单排序","","导航菜单排序");
INSERT INTO cmf_admin_menu VALUES("42","1","1","1","1000","admin","Plugin","index","","插件列表","","插件列表");
INSERT INTO cmf_admin_menu VALUES("43","42","2","0","1000","admin","Plugin","toggle","","插件启用禁用","","插件启用禁用");
INSERT INTO cmf_admin_menu VALUES("44","42","1","0","1000","admin","Plugin","setting","","插件设置","","插件设置");
INSERT INTO cmf_admin_menu VALUES("45","42","2","0","1000","admin","Plugin","settingPost","","插件设置提交","","插件设置提交");
INSERT INTO cmf_admin_menu VALUES("46","42","2","0","1000","admin","Plugin","install","","插件安装","","插件安装");
INSERT INTO cmf_admin_menu VALUES("47","42","2","0","1000","admin","Plugin","update","","插件更新","","插件更新");
INSERT INTO cmf_admin_menu VALUES("48","42","2","0","1000","admin","Plugin","uninstall","","卸载插件","","卸载插件");
INSERT INTO cmf_admin_menu VALUES("49","0","0","0","2000","admin","User","default","","管理组","users","管理组");
INSERT INTO cmf_admin_menu VALUES("50","49","1","1","1000","admin","Rbac","index","","角色管理","","角色管理");
INSERT INTO cmf_admin_menu VALUES("51","50","1","0","1000","admin","Rbac","roleAdd","","添加角色","","添加角色");
INSERT INTO cmf_admin_menu VALUES("52","50","2","0","1000","admin","Rbac","roleAddPost","","添加角色提交","","添加角色提交");
INSERT INTO cmf_admin_menu VALUES("53","50","1","0","1000","admin","Rbac","roleEdit","","编辑角色","","编辑角色");
INSERT INTO cmf_admin_menu VALUES("54","50","2","0","1000","admin","Rbac","roleEditPost","","编辑角色提交","","编辑角色提交");
INSERT INTO cmf_admin_menu VALUES("55","50","2","0","1000","admin","Rbac","roleDelete","","删除角色","","删除角色");
INSERT INTO cmf_admin_menu VALUES("56","50","1","0","1000","admin","Rbac","authorize","","设置角色权限","","设置角色权限");
INSERT INTO cmf_admin_menu VALUES("57","50","2","0","1000","admin","Rbac","authorizePost","","角色授权提交","","角色授权提交");
INSERT INTO cmf_admin_menu VALUES("58","0","1","0","10000","admin","RecycleBin","index","","回收站","","回收站");
INSERT INTO cmf_admin_menu VALUES("59","58","2","0","1000","admin","RecycleBin","restore","","回收站还原","","回收站还原");
INSERT INTO cmf_admin_menu VALUES("60","58","2","0","1000","admin","RecycleBin","delete","","回收站彻底删除","","回收站彻底删除");
INSERT INTO cmf_admin_menu VALUES("61","6","1","0","1000","admin","Route","index","","URL美化","","URL规则管理");
INSERT INTO cmf_admin_menu VALUES("62","61","1","0","1000","admin","Route","add","","添加路由规则","","添加路由规则");
INSERT INTO cmf_admin_menu VALUES("63","61","2","0","1000","admin","Route","addPost","","添加路由规则提交","","添加路由规则提交");
INSERT INTO cmf_admin_menu VALUES("64","61","1","0","1000","admin","Route","edit","","路由规则编辑","","路由规则编辑");
INSERT INTO cmf_admin_menu VALUES("65","61","2","0","1000","admin","Route","editPost","","路由规则编辑提交","","路由规则编辑提交");
INSERT INTO cmf_admin_menu VALUES("66","61","2","0","1000","admin","Route","delete","","路由规则删除","","路由规则删除");
INSERT INTO cmf_admin_menu VALUES("67","61","2","0","1000","admin","Route","ban","","路由规则禁用","","路由规则禁用");
INSERT INTO cmf_admin_menu VALUES("68","61","2","0","1000","admin","Route","open","","路由规则启用","","路由规则启用");
INSERT INTO cmf_admin_menu VALUES("69","61","2","0","1000","admin","Route","listOrder","","路由规则排序","","路由规则排序");
INSERT INTO cmf_admin_menu VALUES("70","61","1","0","1000","admin","Route","select","","选择URL","","选择URL");
INSERT INTO cmf_admin_menu VALUES("71","6","1","0","1000","admin","Setting","site","","网站信息","","网站信息");
INSERT INTO cmf_admin_menu VALUES("72","71","2","0","1000","admin","Setting","sitePost","","网站信息设置提交","","网站信息设置提交");
INSERT INTO cmf_admin_menu VALUES("73","199","1","0","1000","admin","Setting","password","","密码修改","","密码修改");
INSERT INTO cmf_admin_menu VALUES("74","73","2","0","1000","admin","Setting","passwordPost","","密码修改提交","","密码修改提交");
INSERT INTO cmf_admin_menu VALUES("75","6","1","0","30","admin","Setting","upload","","上传设置","","上传设置");
INSERT INTO cmf_admin_menu VALUES("76","75","2","0","1000","admin","Setting","uploadPost","","上传设置提交","","上传设置提交");
INSERT INTO cmf_admin_menu VALUES("77","199","1","0","1000","admin","Setting","clearCache","","清除缓存","","清除缓存");
INSERT INTO cmf_admin_menu VALUES("78","6","1","1","20","admin","Slide","index","","幻灯片管理","","幻灯片管理");
INSERT INTO cmf_admin_menu VALUES("79","78","1","0","1000","admin","Slide","add","","添加幻灯片","","添加幻灯片");
INSERT INTO cmf_admin_menu VALUES("80","78","2","0","1000","admin","Slide","addPost","","添加幻灯片提交","","添加幻灯片提交");
INSERT INTO cmf_admin_menu VALUES("81","78","1","0","1000","admin","Slide","edit","","编辑幻灯片","","编辑幻灯片");
INSERT INTO cmf_admin_menu VALUES("82","78","2","0","1000","admin","Slide","editPost","","编辑幻灯片提交","","编辑幻灯片提交");
INSERT INTO cmf_admin_menu VALUES("83","78","2","0","1000","admin","Slide","delete","","删除幻灯片","","删除幻灯片");
INSERT INTO cmf_admin_menu VALUES("84","78","1","0","1000","admin","SlideItem","index","","幻灯片页面列表","","幻灯片页面列表");
INSERT INTO cmf_admin_menu VALUES("85","84","1","0","1000","admin","SlideItem","add","","幻灯片页面添加","","幻灯片页面添加");
INSERT INTO cmf_admin_menu VALUES("86","84","2","0","1000","admin","SlideItem","addPost","","幻灯片页面添加提交","","幻灯片页面添加提交");
INSERT INTO cmf_admin_menu VALUES("87","84","1","0","1000","admin","SlideItem","edit","","幻灯片页面编辑","","幻灯片页面编辑");
INSERT INTO cmf_admin_menu VALUES("88","84","2","0","1000","admin","SlideItem","editPost","","幻灯片页面编辑提交","","幻灯片页面编辑提交");
INSERT INTO cmf_admin_menu VALUES("89","84","2","0","1000","admin","SlideItem","delete","","幻灯片页面删除","","幻灯片页面删除");
INSERT INTO cmf_admin_menu VALUES("90","84","2","0","1000","admin","SlideItem","ban","","幻灯片页面隐藏","","幻灯片页面隐藏");
INSERT INTO cmf_admin_menu VALUES("91","84","2","0","1000","admin","SlideItem","cancelBan","","幻灯片页面显示","","幻灯片页面显示");
INSERT INTO cmf_admin_menu VALUES("92","84","2","0","1000","admin","SlideItem","listOrder","","幻灯片页面排序","","幻灯片页面排序");
INSERT INTO cmf_admin_menu VALUES("93","6","1","0","40","admin","Storage","index","","文件存储","","文件存储");
INSERT INTO cmf_admin_menu VALUES("94","93","2","0","1000","admin","Storage","settingPost","","文件存储设置提交","","文件存储设置提交");
INSERT INTO cmf_admin_menu VALUES("95","6","1","0","1000","admin","Theme","index","","模板管理","","模板管理");
INSERT INTO cmf_admin_menu VALUES("96","95","1","0","1000","admin","Theme","install","","安装模板","","安装模板");
INSERT INTO cmf_admin_menu VALUES("97","95","2","0","1000","admin","Theme","uninstall","","卸载模板","","卸载模板");
INSERT INTO cmf_admin_menu VALUES("98","95","2","0","1000","admin","Theme","installTheme","","模板安装","","模板安装");
INSERT INTO cmf_admin_menu VALUES("99","95","2","0","1000","admin","Theme","update","","模板更新","","模板更新");
INSERT INTO cmf_admin_menu VALUES("100","95","2","0","1000","admin","Theme","active","","启用模板","","启用模板");
INSERT INTO cmf_admin_menu VALUES("101","95","1","0","1000","admin","Theme","files","","模板文件列表","","启用模板");
INSERT INTO cmf_admin_menu VALUES("102","95","1","0","1000","admin","Theme","fileSetting","","模板文件设置","","模板文件设置");
INSERT INTO cmf_admin_menu VALUES("103","95","1","0","1000","admin","Theme","fileArrayData","","模板文件数组数据列表","","模板文件数组数据列表");
INSERT INTO cmf_admin_menu VALUES("104","95","2","0","1000","admin","Theme","fileArrayDataEdit","","模板文件数组数据添加编辑","","模板文件数组数据添加编辑");
INSERT INTO cmf_admin_menu VALUES("105","95","2","0","1000","admin","Theme","fileArrayDataEditPost","","模板文件数组数据添加编辑提交保存","","模板文件数组数据添加编辑提交保存");
INSERT INTO cmf_admin_menu VALUES("106","95","2","0","1000","admin","Theme","fileArrayDataDelete","","模板文件数组数据删除","","模板文件数组数据删除");
INSERT INTO cmf_admin_menu VALUES("107","95","2","0","1000","admin","Theme","settingPost","","模板文件编辑提交保存","","模板文件编辑提交保存");
INSERT INTO cmf_admin_menu VALUES("108","95","1","0","1000","admin","Theme","dataSource","","模板文件设置数据源","","模板文件设置数据源");
INSERT INTO cmf_admin_menu VALUES("109","95","1","0","1000","admin","Theme","design","","模板设计","","模板设计");
INSERT INTO cmf_admin_menu VALUES("111","49","1","1","1000","admin","User","index","","管理员","","管理员管理");
INSERT INTO cmf_admin_menu VALUES("112","111","1","0","1000","admin","User","add","","管理员添加","","管理员添加");
INSERT INTO cmf_admin_menu VALUES("113","111","2","0","1000","admin","User","addPost","","管理员添加提交","","管理员添加提交");
INSERT INTO cmf_admin_menu VALUES("114","111","1","0","1000","admin","User","edit","","管理员编辑","","管理员编辑");
INSERT INTO cmf_admin_menu VALUES("115","111","2","0","1000","admin","User","editPost","","管理员编辑提交","","管理员编辑提交");
INSERT INTO cmf_admin_menu VALUES("116","111","1","0","1000","admin","User","userInfo","","个人信息","","管理员个人信息修改");
INSERT INTO cmf_admin_menu VALUES("117","111","2","0","1000","admin","User","userInfoPost","","管理员个人信息修改提交","","管理员个人信息修改提交");
INSERT INTO cmf_admin_menu VALUES("118","111","2","0","1000","admin","User","delete","","管理员删除","","管理员删除");
INSERT INTO cmf_admin_menu VALUES("119","111","2","0","1000","admin","User","ban","","停用管理员","","停用管理员");
INSERT INTO cmf_admin_menu VALUES("120","111","2","0","1000","admin","User","cancelBan","","启用管理员","","启用管理员");
INSERT INTO cmf_admin_menu VALUES("121","199","1","0","1000","user","AdminAsset","index","","资源管理","file","资源管理列表");
INSERT INTO cmf_admin_menu VALUES("122","121","2","0","1000","user","AdminAsset","delete","","删除文件","","删除文件");
INSERT INTO cmf_admin_menu VALUES("123","110","0","1","10000","user","AdminIndex","default1","","用户组","","用户组");
INSERT INTO cmf_admin_menu VALUES("124","123","1","1","10000","user","AdminIndex","index","","本站用户","","本站用户");
INSERT INTO cmf_admin_menu VALUES("125","124","2","0","10000","user","AdminIndex","ban","","本站用户拉黑","","本站用户拉黑");
INSERT INTO cmf_admin_menu VALUES("126","124","2","0","10000","user","AdminIndex","cancelBan","","本站用户启用","","本站用户启用");
INSERT INTO cmf_admin_menu VALUES("127","123","1","1","10000","user","AdminOauth","index","","第三方用户","","第三方用户");
INSERT INTO cmf_admin_menu VALUES("128","127","2","0","10000","user","AdminOauth","delete","","删除第三方用户绑定","","删除第三方用户绑定");
INSERT INTO cmf_admin_menu VALUES("130","129","1","0","1000","user","AdminUserAction","edit","","编辑用户操作","","编辑用户操作");
INSERT INTO cmf_admin_menu VALUES("131","129","2","0","1000","user","AdminUserAction","editPost","","编辑用户操作提交","","编辑用户操作提交");
INSERT INTO cmf_admin_menu VALUES("132","129","1","0","1000","user","AdminUserAction","sync","","同步用户操作","","同步用户操作");
INSERT INTO cmf_admin_menu VALUES("162","58","2","0","1000","admin","RecycleBin","clear","","清空回收站","","一键清空回收站");
INSERT INTO cmf_admin_menu VALUES("163","1","1","1","1000","plugin/Swagger","AdminIndex","index","","Swagger","","Swagger");
INSERT INTO cmf_admin_menu VALUES("164","6","1","1","10","plugin/Configs","AdminIndex","index","","系统参数设置","","系统参数设置");
INSERT INTO cmf_admin_menu VALUES("167","0","1","1","1000","admin","member","default","","用户管理","user-o","");
INSERT INTO cmf_admin_menu VALUES("168","167","1","1","1000","admin","member","index","","用户管理","","");
INSERT INTO cmf_admin_menu VALUES("169","1","1","1","1000","/plugin/form","AdminIndex","setting","","生成CURD","","");
INSERT INTO cmf_admin_menu VALUES("179","0","1","0","8000","admin","dingdan","index","","订单管理","reorder","");
INSERT INTO cmf_admin_menu VALUES("180","179","1","1","1000","admin","shop_order","index","","订单管理","","");
INSERT INTO cmf_admin_menu VALUES("183","182","1","0","10000","admin","Shop","edit","","编辑","","");
INSERT INTO cmf_admin_menu VALUES("184","182","1","0","10000","admin","Shop","add","","添加","","");
INSERT INTO cmf_admin_menu VALUES("185","182","1","0","10000","admin","Shop","find","","查看","","");
INSERT INTO cmf_admin_menu VALUES("186","182","1","0","10000","admin","Shop","delete","","删除","","");
INSERT INTO cmf_admin_menu VALUES("191","190","1","0","10000","admin","FormTest","edit","","编辑","","");
INSERT INTO cmf_admin_menu VALUES("192","190","1","0","10000","admin","FormTest","add","","添加","","");
INSERT INTO cmf_admin_menu VALUES("193","190","1","0","10000","admin","FormTest","find","","查看","","");
INSERT INTO cmf_admin_menu VALUES("194","190","1","0","10000","admin","FormTest","delete","","删除","","");
INSERT INTO cmf_admin_menu VALUES("195","190","1","0","10000","admin","FormTest","recommend_post","","推荐","","");
INSERT INTO cmf_admin_menu VALUES("196","190","1","0","10000","admin","FormTest","list_order_post","","排序","","");
INSERT INTO cmf_admin_menu VALUES("198","6","1","0","10000","plugin/weipay","admin_index","index","","小程序设置","","");
INSERT INTO cmf_admin_menu VALUES("199","0","2","0","10000","admin","moren","index","","子权限","","");
INSERT INTO cmf_admin_menu VALUES("200","0","1","1","3000","admin","tiku","index","","题库管理","quora","");
INSERT INTO cmf_admin_menu VALUES("201","200","1","1","10000","admin","Answer","index","","答题类型","","");
INSERT INTO cmf_admin_menu VALUES("202","201","1","0","10000","admin","Answer","edit","","编辑","","");
INSERT INTO cmf_admin_menu VALUES("203","201","1","0","10000","admin","Answer","add","","添加","","");
INSERT INTO cmf_admin_menu VALUES("204","201","1","0","10000","admin","Answer","find","","查看","","");
INSERT INTO cmf_admin_menu VALUES("205","201","1","0","10000","admin","Answer","delete","","删除","","");
INSERT INTO cmf_admin_menu VALUES("206","0","1","1","10000","admin","jilu","index","","答题记录","bars","");
INSERT INTO cmf_admin_menu VALUES("207","206","1","1","10000","admin","AnswerResult","index","","答题结果","","");
INSERT INTO cmf_admin_menu VALUES("208","207","1","0","10000","admin","AnswerResult","find","","查看","","");
INSERT INTO cmf_admin_menu VALUES("209","206","1","1","10000","admin","AnswerWrong","index","","错题记录","","");
INSERT INTO cmf_admin_menu VALUES("210","209","1","0","10000","admin","AnswerWrong","find","","查看","","");



DROP TABLE cmf_answer;

CREATE TABLE `cmf_answer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL COMMENT '名称',
  `list_order` int(11) DEFAULT '1000',
  `create_time` bigint(20) DEFAULT NULL COMMENT '创建时间',
  `update_time` bigint(20) DEFAULT NULL COMMENT '更新时间',
  `delete_time` bigint(20) DEFAULT '0' COMMENT '删除时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COMMENT='答题类型';

INSERT INTO cmf_answer VALUES("1","Ⅲ类试题","1000","1728034031","","0");
INSERT INTO cmf_answer VALUES("2","Ⅱ类试题","1000","1728034038","","0");



DROP TABLE cmf_answer_class;

CREATE TABLE `cmf_answer_class` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) DEFAULT NULL COMMENT '题类型',
  `name` varchar(255) DEFAULT NULL COMMENT '名称',
  `introduce` varchar(2555) DEFAULT NULL COMMENT '介绍',
  `list_order` int(11) DEFAULT '1000',
  `create_time` bigint(20) DEFAULT NULL COMMENT '创建时间',
  `update_time` bigint(20) DEFAULT NULL COMMENT '更新时间',
  `delete_time` bigint(20) DEFAULT '0' COMMENT '删除时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COMMENT='类型管理';

INSERT INTO cmf_answer_class VALUES("1","","Ⅲ类试题","","1000","1728034031","","0");
INSERT INTO cmf_answer_class VALUES("2","","Ⅱ类试题","","1000","1728034038","","0");
INSERT INTO cmf_answer_class VALUES("3","2","医用类试题","医用类试题","1000","1728034631","1728373769","1728373769");
INSERT INTO cmf_answer_class VALUES("4","2","非医用类试题","非医用类试题","1000","1728034640","1728373766","1728373766");
INSERT INTO cmf_answer_class VALUES("5","2","X射线试题","三部分     题型：单选题/多选题","1000","1728373788","","0");
INSERT INTO cmf_answer_class VALUES("6","1","医用类试题","","1000","1728962609","","0");
INSERT INTO cmf_answer_class VALUES("7","1","非医用类试题","","1000","1728962625","","0");
INSERT INTO cmf_answer_class VALUES("8","2","Y射线试题","","1000","1729220220","","0");



DROP TABLE cmf_answer_question;

CREATE TABLE `cmf_answer_question` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) DEFAULT NULL COMMENT '题类型',
  `name` varchar(255) DEFAULT NULL COMMENT '标题',
  `option` text COMMENT '选项',
  `answer` text COMMENT '答案',
  `answer_key` varchar(255) DEFAULT NULL COMMENT '答案key',
  `answer_letter` varchar(255) DEFAULT NULL COMMENT '答案字母',
  `option_type` tinyint(4) DEFAULT '1' COMMENT '选项类型:1单选,2多选,3填空',
  `analysis` varchar(255) DEFAULT NULL COMMENT '试题解析',
  `score` varchar(255) DEFAULT NULL COMMENT '分数',
  `list_order` int(11) DEFAULT '1000',
  `create_time` bigint(20) DEFAULT NULL COMMENT '创建时间',
  `update_time` bigint(20) DEFAULT NULL COMMENT '更新时间',
  `delete_time` bigint(20) DEFAULT '0' COMMENT '删除时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=69 DEFAULT CHARSET=utf8mb4 COMMENT='题库管理';

INSERT INTO cmf_answer_question VALUES("5","4","测试测试测试测试侧test","a:5:{i:0;a:4:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:6:\"jyyyyy\";s:5:\"image\";s:81:\"https://oss.ausite.cn/dzkf382/admin/20241005/eb55ec9d32e8b25f2f7907c0f19fbd0f.jpg\";s:8:\"isSelect\";i:0;}i:1;a:4:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:7:\"rtreter\";s:5:\"image\";s:82:\"https://oss.ausite.cn/dzkf382/admin/20241005/693063f6268230fdd9c5b8cbd7470151.jpeg\";s:8:\"isSelect\";i:0;}i:2;a:4:{s:5:\"alias\";s:1:\"C\";s:6:\"answer\";s:7:\"ccccccc\";s:5:\"image\";s:82:\"https://oss.ausite.cn/dzkf382/admin/20241005/693063f6268230fdd9c5b8cbd7470151.jpeg\";s:8:\"isSelect\";i:0;}i:3;a:4:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:6:\"ceerwe\";s:5:\"image\";s:81:\"https://oss.ausite.cn/dzkf382/admin/20241005/c95dfaf6260e181f47d3f5d61b8f6544.jpg\";s:8:\"isSelect\";i:0;}i:4;a:4:{s:5:\"alias\";s:1:\"E\";s:6:\"answer\";s:5:\"ttttt\";s:5:\"image\";s:82:\"https://oss.ausite.cn/dzkf382/admin/20241005/7d8f766b13986aedb0e42ad1766fe9df.jpeg\";s:8:\"isSelect\";i:0;}}","a:3:{i:0;a:4:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:6:\"jyyyyy\";s:5:\"image\";s:81:\"https://oss.ausite.cn/dzkf382/admin/20241005/eb55ec9d32e8b25f2f7907c0f19fbd0f.jpg\";s:8:\"isSelect\";i:1;}i:1;a:4:{s:5:\"alias\";s:1:\"C\";s:6:\"answer\";s:7:\"ccccccc\";s:5:\"image\";s:82:\"https://oss.ausite.cn/dzkf382/admin/20241005/693063f6268230fdd9c5b8cbd7470151.jpeg\";s:8:\"isSelect\";i:1;}i:2;a:4:{s:5:\"alias\";s:1:\"E\";s:6:\"answer\";s:5:\"ttttt\";s:5:\"image\";s:82:\"https://oss.ausite.cn/dzkf382/admin/20241005/7d8f766b13986aedb0e42ad1766fe9df.jpeg\";s:8:\"isSelect\";i:1;}}","0,2,4","A,C,E","1","","10","1000","1728092799","1728111611","0");
INSERT INTO cmf_answer_question VALUES("6","4","但是抚慰费","a:3:{i:0;a:4:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:7:\"ererere\";s:5:\"image\";s:82:\"https://oss.ausite.cn/dzkf382/admin/20241005/a76d8dae7c4bdc3b57eff8e0b0217ef8.jpeg\";s:8:\"isSelect\";i:0;}i:1;a:4:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:4:\"3454\";s:5:\"image\";s:81:\"https://oss.ausite.cn/dzkf382/admin/20241005/82dd3d18aab295faae715299fc04010b.jpg\";s:8:\"isSelect\";i:0;}i:2;a:4:{s:5:\"alias\";s:1:\"C\";s:6:\"answer\";s:7:\"fyrtrtr\";s:5:\"image\";s:82:\"https://oss.ausite.cn/dzkf382/admin/20241005/218d81ae63a6466ffafa019a84544b94.jpeg\";s:8:\"isSelect\";i:0;}}","a:2:{i:0;a:4:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:7:\"ererere\";s:5:\"image\";s:82:\"https://oss.ausite.cn/dzkf382/admin/20241005/a76d8dae7c4bdc3b57eff8e0b0217ef8.jpeg\";s:8:\"isSelect\";i:1;}i:1;a:4:{s:5:\"alias\";s:1:\"C\";s:6:\"answer\";s:7:\"fyrtrtr\";s:5:\"image\";s:82:\"https://oss.ausite.cn/dzkf382/admin/20241005/218d81ae63a6466ffafa019a84544b94.jpeg\";s:8:\"isSelect\";i:1;}}","0,2","A,C","1","","10","1000","1728097343","1728109709","0");
INSERT INTO cmf_answer_question VALUES("7","4","efefefe","a:3:{i:0;a:4:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:5:\"ttttt\";s:5:\"image\";N;s:8:\"isSelect\";i:0;}i:1;a:4:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:6:\"yyyyyy\";s:5:\"image\";N;s:8:\"isSelect\";i:0;}i:2;a:4:{s:5:\"alias\";s:1:\"C\";s:6:\"answer\";s:6:\"pppppp\";s:5:\"image\";N;s:8:\"isSelect\";i:0;}}","a:2:{i:0;a:4:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:6:\"yyyyyy\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}i:1;a:4:{s:5:\"alias\";s:1:\"C\";s:6:\"answer\";s:6:\"pppppp\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}}","1,2","B,C","1","","1","1000","1728097409","1728097850","1728097850");
INSERT INTO cmf_answer_question VALUES("8","5","第一部分001","a:2:{i:0;a:4:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:1:\"a\";s:5:\"image\";N;s:8:\"isSelect\";i:0;}i:1;a:4:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:1:\"b\";s:5:\"image\";N;s:8:\"isSelect\";i:0;}}","a:1:{i:0;a:4:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:1:\"a\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}}","0","A","1","","10","1000","1728374153","1728380543","1728380543");
INSERT INTO cmf_answer_question VALUES("9","5","第一部分02","a:3:{i:0;a:4:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:1:\"b\";s:5:\"image\";N;s:8:\"isSelect\";i:0;}i:1;a:4:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:1:\"c\";s:5:\"image\";N;s:8:\"isSelect\";i:0;}i:2;a:4:{s:5:\"alias\";s:1:\"C\";s:6:\"answer\";s:1:\"d\";s:5:\"image\";N;s:8:\"isSelect\";i:0;}}","a:2:{i:0;a:4:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:1:\"b\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}i:1;a:4:{s:5:\"alias\";s:1:\"C\";s:6:\"answer\";s:1:\"d\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}}","0,2","A,C","2","","2","1000","1728374174","","0");
INSERT INTO cmf_answer_question VALUES("10","6","第二部分01","a:2:{i:0;a:4:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:1:\"a\";s:5:\"image\";N;s:8:\"isSelect\";i:0;}i:1;a:4:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:1:\"b\";s:5:\"image\";N;s:8:\"isSelect\";i:0;}}","a:1:{i:0;a:4:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:1:\"b\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}}","1","B","1","11111111111111111111111111111111111222222222222222222222222","10","1000","1728374193","1729561775","0");
INSERT INTO cmf_answer_question VALUES("11","6","第二部分02","a:4:{i:0;a:4:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:1:\"a\";s:5:\"image\";N;s:8:\"isSelect\";i:0;}i:1;a:4:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:1:\"b\";s:5:\"image\";N;s:8:\"isSelect\";i:0;}i:2;a:4:{s:5:\"alias\";s:1:\"C\";s:6:\"answer\";s:1:\"c\";s:5:\"image\";N;s:8:\"isSelect\";i:0;}i:3;a:4:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:1:\"d\";s:5:\"image\";N;s:8:\"isSelect\";i:0;}}","a:2:{i:0;a:4:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:1:\"b\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}i:1;a:4:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:1:\"d\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}}","1,3","B,D","2","10101010","10","1000","1728374211","1729561787","0");
INSERT INTO cmf_answer_question VALUES("12","7","第三部分01","a:2:{i:0;a:4:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:1:\"a\";s:5:\"image\";N;s:8:\"isSelect\";i:0;}i:1;a:4:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:1:\"b\";s:5:\"image\";N;s:8:\"isSelect\";i:0;}}","a:1:{i:0;a:4:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:1:\"a\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}}","0","A","1","","8","1000","1728374239","","0");
INSERT INTO cmf_answer_question VALUES("13","7","第三部分02","a:4:{i:0;a:4:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:1:\"a\";s:5:\"image\";N;s:8:\"isSelect\";i:0;}i:1;a:4:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:1:\"b\";s:5:\"image\";N;s:8:\"isSelect\";i:0;}i:2;a:4:{s:5:\"alias\";s:1:\"C\";s:6:\"answer\";s:1:\"c\";s:5:\"image\";N;s:8:\"isSelect\";i:0;}i:3;a:4:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:1:\"d\";s:5:\"image\";N;s:8:\"isSelect\";i:0;}}","a:2:{i:0;a:4:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:1:\"a\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}i:1;a:4:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:1:\"d\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}}","0,3","A,D","2","","5","1000","1728374259","","0");
INSERT INTO cmf_answer_question VALUES("16","5","1+3=","a:3:{i:0;a:3:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:1:\"5\";s:8:\"isSelect\";i:0;}i:1;a:3:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:1:\"4\";s:8:\"isSelect\";i:0;}i:2;a:3:{s:5:\"alias\";s:1:\"C\";s:6:\"answer\";s:1:\"6\";s:8:\"isSelect\";i:0;}}","a:1:{i:0;a:3:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:1:\"4\";s:8:\"isSelect\";i:1;}}","1","B","1","","5","1000","1728548219","1728548281","1728548281");
INSERT INTO cmf_answer_question VALUES("17","5","x*x=12","a:5:{i:0;a:3:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:4:\"1*12\";s:8:\"isSelect\";i:0;}i:1;a:3:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:3:\"2*3\";s:8:\"isSelect\";i:0;}i:2;a:3:{s:5:\"alias\";s:1:\"C\";s:6:\"answer\";s:3:\"2*6\";s:8:\"isSelect\";i:0;}i:3;a:3:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:3:\"3*4\";s:8:\"isSelect\";i:0;}i:4;a:3:{s:5:\"alias\";s:1:\"E\";s:6:\"answer\";s:3:\"5*6\";s:8:\"isSelect\";i:0;}}","a:3:{i:0;a:3:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:4:\"1*12\";s:8:\"isSelect\";i:1;}i:1;a:3:{s:5:\"alias\";s:1:\"C\";s:6:\"answer\";s:3:\"2*6\";s:8:\"isSelect\";i:1;}i:2;a:3:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:3:\"3*4\";s:8:\"isSelect\";i:1;}}","0,2,3","A,C,D","2","","20","1000","1728548219","1728548276","1728548276");
INSERT INTO cmf_answer_question VALUES("18","5","兽用X射线装置属于（　　）类射线装置。","a:4:{i:0;a:3:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:3:\"Ⅰ\";s:8:\"isSelect\";i:0;}i:1;a:3:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:3:\"Ⅱ\";s:8:\"isSelect\";i:0;}i:2;a:3:{s:5:\"alias\";s:1:\"C\";s:6:\"answer\";s:3:\"Ⅲ\";s:8:\"isSelect\";i:0;}i:3;a:3:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:6:\"其他\";s:8:\"isSelect\";i:0;}}","a:1:{i:0;a:3:{s:5:\"alias\";s:1:\"C\";s:6:\"answer\";s:3:\"Ⅲ\";s:8:\"isSelect\";i:1;}}","2","C","1","","2","1000","1728549177","","0");
INSERT INTO cmf_answer_question VALUES("19","5","下列说法中，不正确的是（　　）。","a:4:{i:0;a:3:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:69:\"与人相比，动物细胞对电离辐射所造成的损害不敏感\";s:8:\"isSelect\";i:0;}i:1;a:3:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:57:\"辐射可以影响机体造红细胞和白细胞的能力\";s:8:\"isSelect\";i:0;}i:2;a:3:{s:5:\"alias\";s:1:\"C\";s:6:\"answer\";s:45:\"辐射可以影响晶状体，造成白内障\";s:8:\"isSelect\";i:0;}i:3;a:3:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:81:\"在X线摄影过程中，年龄不满18岁的青少年不能对动物进行保定\";s:8:\"isSelect\";i:0;}}","a:1:{i:0;a:3:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:69:\"与人相比，动物细胞对电离辐射所造成的损害不敏感\";s:8:\"isSelect\";i:1;}}","0","A","1","","2","1000","1728549177","","0");
INSERT INTO cmf_answer_question VALUES("20","5","下列说法中，正确的是（　　）。","a:4:{i:0;a:3:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:39:\"机体细胞对辐射基本同样敏感\";s:8:\"isSelect\";i:0;}i:1;a:3:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:63:\"电离辐射仅仅破坏生殖细胞的染色体物质（DNA）\";s:8:\"isSelect\";i:0;}i:2;a:3:{s:5:\"alias\";s:1:\"C\";s:6:\"answer\";s:39:\"禁止对患病动物使用化学保定\";s:8:\"isSelect\";i:0;}i:3;a:3:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:51:\"只有产生后代以后，才能发觉遗传损害\";s:8:\"isSelect\";i:0;}}","a:1:{i:0;a:3:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:51:\"只有产生后代以后，才能发觉遗传损害\";s:8:\"isSelect\";i:1;}}","3","D","1","","2","1000","1728549177","","0");
INSERT INTO cmf_answer_question VALUES("21","5","下列说法中，正确的是（　　）。","a:4:{i:0;a:3:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:45:\"兽医保定人员常暴露在原射线束下\";s:8:\"isSelect\";i:0;}i:1;a:3:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:45:\"使用遮线器可以减少散射线的产生\";s:8:\"isSelect\";i:0;}i:2;a:3:{s:5:\"alias\";s:1:\"C\";s:6:\"answer\";s:88:\"铝滤过有助于增加穿透能力弱的软射线，从而增加X线片的影像质量\";s:8:\"isSelect\";i:0;}i:3;a:3:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:60:\"散射线是由原射线束与阳极的相互作用造成的\";s:8:\"isSelect\";i:0;}}","a:1:{i:0;a:3:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:45:\"使用遮线器可以减少散射线的产生\";s:8:\"isSelect\";i:1;}}","1","B","1","","2","1000","1728549177","","0");
INSERT INTO cmf_answer_question VALUES("22","5","检查铅手套和铅围裙裂缝和缺损最具确定性的方法是（　　）。","a:4:{i:0;a:3:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:22:\"对其进行X线摄影\";s:8:\"isSelect\";i:0;}i:1;a:3:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:33:\"将其挂到阳光下或灯光下\";s:8:\"isSelect\";i:0;}i:2;a:3:{s:5:\"alias\";s:1:\"C\";s:6:\"answer\";s:12:\"手工检查\";s:8:\"isSelect\";i:0;}i:3;a:3:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:14:\"B和C都正确\";s:8:\"isSelect\";i:0;}}","a:1:{i:0;a:3:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:22:\"对其进行X线摄影\";s:8:\"isSelect\";i:1;}}","0","A","1","","2","1000","1728549177","","0");
INSERT INTO cmf_answer_question VALUES("23","5","兽医X线摄影规定要求围裙和手套应为（　　）厚度的铅当量。","a:4:{i:0;a:3:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:3:\"1cm\";s:8:\"isSelect\";i:0;}i:1;a:3:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:4:\"10mm\";s:8:\"isSelect\";i:0;}i:2;a:3:{s:5:\"alias\";s:1:\"C\";s:6:\"answer\";s:5:\"0.5mm\";s:8:\"isSelect\";i:0;}i:3;a:3:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:5:\"0.5cm\";s:8:\"isSelect\";i:0;}}","a:1:{i:0;a:3:{s:5:\"alias\";s:1:\"C\";s:6:\"answer\";s:5:\"0.5mm\";s:8:\"isSelect\";i:1;}}","2","C","1","","2","1000","1728549177","","0");
INSERT INTO cmf_answer_question VALUES("24","5","下列哪一项是人体安全检查用X射线装置的核心部件（　　）。","a:4:{i:0;a:3:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:9:\"探测器\";s:8:\"isSelect\";i:0;}i:1;a:3:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:12:\"传送装置\";s:8:\"isSelect\";i:0;}i:2;a:3:{s:5:\"alias\";s:1:\"C\";s:6:\"answer\";s:28:\"一体化的X射线发生器\";s:8:\"isSelect\";i:0;}i:3;a:3:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:18:\"辐射安全系统\";s:8:\"isSelect\";i:0;}}","a:1:{i:0;a:3:{s:5:\"alias\";s:1:\"C\";s:6:\"answer\";s:28:\"一体化的X射线发生器\";s:8:\"isSelect\";i:1;}}","2","C","1","","2","1000","1728549177","","0");
INSERT INTO cmf_answer_question VALUES("25","5","当在摄影床保定动物时，保定人员应该在床尾呈（　　），这样可以增加保定者与散射线源之间的距离。","a:4:{i:0;a:3:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:12:\"倚靠姿势\";s:8:\"isSelect\";i:0;}i:1;a:3:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:12:\"直立姿势\";s:8:\"isSelect\";i:0;}i:2;a:3:{s:5:\"alias\";s:1:\"C\";s:6:\"answer\";s:12:\"端坐姿势\";s:8:\"isSelect\";i:0;}i:3;a:3:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:12:\"以上均可\";s:8:\"isSelect\";i:0;}}","a:1:{i:0;a:3:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:12:\"直立姿势\";s:8:\"isSelect\";i:1;}}","1","B","1","","2","1000","1728549177","","0");
INSERT INTO cmf_answer_question VALUES("26","5","柜式X射线行李包检查系统辐射安全的常规检测频率为（　　）。","a:4:{i:0;a:3:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:12:\"三年一次\";s:8:\"isSelect\";i:0;}i:1;a:3:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:12:\"两年一次\";s:8:\"isSelect\";i:0;}i:2;a:3:{s:5:\"alias\";s:1:\"C\";s:6:\"answer\";s:12:\"每年一次\";s:8:\"isSelect\";i:0;}i:3;a:3:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:12:\"每月一次\";s:8:\"isSelect\";i:0;}}","a:1:{i:0;a:3:{s:5:\"alias\";s:1:\"C\";s:6:\"answer\";s:12:\"每年一次\";s:8:\"isSelect\";i:1;}}","2","C","1","","2","1000","1728549177","","0");
INSERT INTO cmf_answer_question VALUES("27","5","下列哪种剂量计可以将信息保存数年并可重复使用？（　　）","a:4:{i:0;a:3:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:9:\"遮线器\";s:8:\"isSelect\";i:0;}i:1;a:3:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:12:\"胶片徽章\";s:8:\"isSelect\";i:0;}i:2;a:3:{s:5:\"alias\";s:1:\"C\";s:6:\"answer\";s:18:\"热发光剂量计\";s:8:\"isSelect\";i:0;}i:3;a:3:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:15:\"袖珍电离室\";s:8:\"isSelect\";i:0;}}","a:1:{i:0;a:3:{s:5:\"alias\";s:1:\"C\";s:6:\"answer\";s:18:\"热发光剂量计\";s:8:\"isSelect\";i:1;}}","2","C","1","","2","1000","1728549177","","0");
INSERT INTO cmf_answer_question VALUES("28","5","下列关于胶片徽章的描述，正确的是（　　）。","a:4:{i:0;a:3:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:21:\"一种袖珍电离室\";s:8:\"isSelect\";i:0;}i:1;a:3:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:30:\"必须时刻佩戴到衣领上\";s:8:\"isSelect\";i:0;}i:2;a:3:{s:5:\"alias\";s:1:\"C\";s:6:\"answer\";s:45:\"一种监测实际接收辐射量的剂量计\";s:8:\"isSelect\";i:0;}i:3;a:3:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:45:\"应该每周上交一次，确定暴露水平\";s:8:\"isSelect\";i:0;}}","a:1:{i:0;a:3:{s:5:\"alias\";s:1:\"C\";s:6:\"answer\";s:45:\"一种监测实际接收辐射量的剂量计\";s:8:\"isSelect\";i:1;}}","2","C","1","","2","1000","1728549177","","0");
INSERT INTO cmf_answer_question VALUES("29","5","公共场所X射线行李包检查装置的生产、销售活动按（　　）类射线装置管理；对其设备的用户单位实行豁免管理。","a:4:{i:0;a:3:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:3:\"Ⅰ\";s:8:\"isSelect\";i:0;}i:1;a:3:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:3:\"Ⅱ\";s:8:\"isSelect\";i:0;}i:2;a:3:{s:5:\"alias\";s:1:\"C\";s:6:\"answer\";s:3:\"Ⅲ\";s:8:\"isSelect\";i:0;}i:3;a:3:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:3:\"Ⅳ\";s:8:\"isSelect\";i:0;}}","a:1:{i:0;a:3:{s:5:\"alias\";s:1:\"C\";s:6:\"answer\";s:3:\"Ⅲ\";s:8:\"isSelect\";i:1;}}","2","C","1","","2","1000","1728549177","","0");
INSERT INTO cmf_answer_question VALUES("30","5","摆位后进行摄影时，患病动物可能发生移动，放射师为预防运动伪影的发生需要进行（　　）。","a:4:{i:0;a:3:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:33:\"尽可能使用短的曝光时间\";s:8:\"isSelect\";i:0;}i:1;a:3:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:19:\"改变X线的方向\";s:8:\"isSelect\";i:0;}i:2;a:3:{s:5:\"alias\";s:1:\"C\";s:6:\"answer\";s:27:\"使用较长的曝光时间\";s:8:\"isSelect\";i:0;}i:3;a:3:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:36:\"摄影前所有动物都需要镇静\";s:8:\"isSelect\";i:0;}}","a:1:{i:0;a:3:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:33:\"尽可能使用短的曝光时间\";s:8:\"isSelect\";i:1;}}","0","A","1","","2","1000","1728549177","","0");
INSERT INTO cmf_answer_question VALUES("31","5","下列哪种措施可以减少对动物或保定人员的辐射以及散射（　　）。","a:4:{i:0;a:3:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:33:\"尽可能开大的遮线器口径\";s:8:\"isSelect\";i:0;}i:1;a:3:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:39:\"使用铅衣遮盖怀疑病变的区域\";s:8:\"isSelect\";i:0;}i:2;a:3:{s:5:\"alias\";s:1:\"C\";s:6:\"answer\";s:54:\"在控制台上选择全波整流而不用半波整流\";s:8:\"isSelect\";i:0;}i:3;a:3:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:45:\"使用遮线器使投照区域尽可能地小\";s:8:\"isSelect\";i:0;}}","a:1:{i:0;a:3:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:45:\"使用遮线器使投照区域尽可能地小\";s:8:\"isSelect\";i:1;}}","3","D","1","","2","1000","1728549177","","0");
INSERT INTO cmf_answer_question VALUES("32","5","X射线衍射仪属于（　　）类射线装置。","a:4:{i:0;a:3:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:3:\"Ⅰ\";s:8:\"isSelect\";i:0;}i:1;a:3:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:3:\"Ⅱ\";s:8:\"isSelect\";i:0;}i:2;a:3:{s:5:\"alias\";s:1:\"C\";s:6:\"answer\";s:3:\"Ⅲ\";s:8:\"isSelect\";i:0;}i:3;a:3:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:6:\"其他\";s:8:\"isSelect\";i:0;}}","a:1:{i:0;a:3:{s:5:\"alias\";s:1:\"C\";s:6:\"answer\";s:3:\"Ⅲ\";s:8:\"isSelect\";i:1;}}","2","C","1","","2","1000","1728549177","","0");
INSERT INTO cmf_answer_question VALUES("33","5","X射线衍射仪的主要部分包括（　　）。","a:4:{i:0;a:3:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:6:\"光源\";s:8:\"isSelect\";i:0;}i:1;a:3:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:15:\"测角仪光路\";s:8:\"isSelect\";i:0;}i:2;a:3:{s:5:\"alias\";s:1:\"C\";s:6:\"answer\";s:9:\"计数器\";s:8:\"isSelect\";i:0;}i:3;a:3:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:12:\"以上都是\";s:8:\"isSelect\";i:0;}}","a:1:{i:0;a:3:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:12:\"以上都是\";s:8:\"isSelect\";i:1;}}","3","D","1","","2","1000","1728549177","","0");
INSERT INTO cmf_answer_question VALUES("34","5","人体安全检查用X射线装置是利用（　　）技术实现对人体的安全检查。","a:4:{i:0;a:3:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:6:\"反射\";s:8:\"isSelect\";i:0;}i:1;a:3:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:12:\"小孔成像\";s:8:\"isSelect\";i:0;}i:2;a:3:{s:5:\"alias\";s:1:\"C\";s:6:\"answer\";s:6:\"折射\";s:8:\"isSelect\";i:0;}i:3;a:3:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:12:\"辐射成像\";s:8:\"isSelect\";i:0;}}","a:1:{i:0;a:3:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:12:\"辐射成像\";s:8:\"isSelect\";i:1;}}","3","D","1","","2","1000","1728549177","","0");
INSERT INTO cmf_answer_question VALUES("35","5","X射线衍射仪应设有X射线防护装置，衍射仪进行样品测量时，人体的（　　）部位可以进入机壳内部。","a:4:{i:0;a:3:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:6:\"四肢\";s:8:\"isSelect\";i:0;}i:1;a:3:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:6:\"躯干\";s:8:\"isSelect\";i:0;}i:2;a:3:{s:5:\"alias\";s:1:\"C\";s:6:\"answer\";s:6:\"头颈\";s:8:\"isSelect\";i:0;}i:3;a:3:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:12:\"均不可以\";s:8:\"isSelect\";i:0;}}","a:1:{i:0;a:3:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:12:\"均不可以\";s:8:\"isSelect\";i:1;}}","3","D","1","","2","1000","1728549177","","0");
INSERT INTO cmf_answer_question VALUES("36","5","X射线衍射仪在额定功率时，在人体可以达到的距关闭射线束出口管套体外表面5cm的位置，射线的空气比释动能率均不应超过（　　）。","a:4:{i:0;a:3:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:12:\"2.5μGy·h-1\";s:8:\"isSelect\";i:0;}i:1;a:3:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:11:\"25μGy·h-1\";s:8:\"isSelect\";i:0;}i:2;a:3:{s:5:\"alias\";s:1:\"C\";s:6:\"answer\";s:11:\"2.5mGy·h-1\";s:8:\"isSelect\";i:0;}i:3;a:3:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:10:\"25mGy·h-1\";s:8:\"isSelect\";i:0;}}","a:1:{i:0;a:3:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:12:\"2.5μGy·h-1\";s:8:\"isSelect\";i:1;}}","0","A","1","","2","1000","1728549177","","0");
INSERT INTO cmf_answer_question VALUES("37","5","X射线衍射仪在额定功率时，在打开射线束出口时，距离防护罩外表面（　　）的任意位置，射线的空气比释动能率均不应超过25μGy·h-1。","a:4:{i:0;a:3:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:3:\"2cm\";s:8:\"isSelect\";i:0;}i:1;a:3:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:3:\"5cm\";s:8:\"isSelect\";i:0;}i:2;a:3:{s:5:\"alias\";s:1:\"C\";s:6:\"answer\";s:4:\"10cm\";s:8:\"isSelect\";i:0;}i:3;a:3:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:4:\"50cm\";s:8:\"isSelect\";i:0;}}","a:1:{i:0;a:3:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:3:\"5cm\";s:8:\"isSelect\";i:1;}}","1","B","1","","2","1000","1728549177","","0");
INSERT INTO cmf_answer_question VALUES("38","5","关于X射线衍射仪，下列说法中错误的是（　　）。","a:4:{i:0;a:3:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:86:\"X射线衍射仪运行中，若设备屏蔽防护厚度不足，易导致X射线泄漏\";s:8:\"isSelect\";i:0;}i:1;a:3:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:118:\"设有“防护罩-高压”联锁装置，防护罩不关闭不能出束，防护罩强制开启时设备停止出束\";s:8:\"isSelect\";i:0;}i:2;a:3:{s:5:\"alias\";s:1:\"C\";s:6:\"answer\";s:84:\"控制面板设有紧急停止按钮，在设备异常时按下，设备停止出束\";s:8:\"isSelect\";i:0;}i:3;a:3:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:114:\"设备控制台上设置有明显的开、关状态和出束时工作状态指示灯，故无需设置警示语句\";s:8:\"isSelect\";i:0;}}","a:1:{i:0;a:3:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:114:\"设备控制台上设置有明显的开、关状态和出束时工作状态指示灯，故无需设置警示语句\";s:8:\"isSelect\";i:1;}}","3","D","1","","2","1000","1728549177","","0");
INSERT INTO cmf_answer_question VALUES("39","5","放射工作人员在岗期间职业健康检查的周期不得超过（　　）年。","a:4:{i:0;a:3:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:1:\"1\";s:8:\"isSelect\";i:0;}i:1;a:3:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:1:\"2\";s:8:\"isSelect\";i:0;}i:2;a:3:{s:5:\"alias\";s:1:\"C\";s:6:\"answer\";s:1:\"3\";s:8:\"isSelect\";i:0;}i:3;a:3:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:1:\"4\";s:8:\"isSelect\";i:0;}}","a:1:{i:0;a:3:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:1:\"2\";s:8:\"isSelect\";i:1;}}","1","B","1","","2","1000","1728549177","","0");
INSERT INTO cmf_answer_question VALUES("40","5","X射线行李包检查装置系统发生故障而紧急停机后，在未查明原因和维修结束前，操作人员（　　）。","a:4:{i:0;a:3:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:21:\"无需放置警示牌\";s:8:\"isSelect\";i:0;}i:1;a:3:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:40:\"可以通过控制台重新启动X光机\";s:8:\"isSelect\";i:0;}i:2;a:3:{s:5:\"alias\";s:1:\"C\";s:6:\"answer\";s:22:\"需立即重启X光机\";s:8:\"isSelect\";i:0;}i:3;a:3:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:40:\"不得通过控制台重新启动X光机\";s:8:\"isSelect\";i:0;}}","a:1:{i:0;a:3:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:40:\"不得通过控制台重新启动X光机\";s:8:\"isSelect\";i:1;}}","3","D","1","","2","1000","1728549177","","0");
INSERT INTO cmf_answer_question VALUES("41","5","X射线荧光分析仪必须具有哪些出厂证件和资料？（　　）","a:4:{i:0;a:3:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:66:\"产品说明书，其中必须包括标准所规定的技术指标\";s:8:\"isSelect\";i:0;}i:1;a:3:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:30:\"产品放射防护合作证书\";s:8:\"isSelect\";i:0;}i:2;a:3:{s:5:\"alias\";s:1:\"C\";s:6:\"answer\";s:66:\"用户手册，其中必须包括安全操作和放射防护须知\";s:8:\"isSelect\";i:0;}i:3;a:3:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:12:\"以上均是\";s:8:\"isSelect\";i:0;}}","a:1:{i:0;a:3:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:12:\"以上均是\";s:8:\"isSelect\";i:1;}}","3","D","1","","2","1000","1728549177","","0");
INSERT INTO cmf_answer_question VALUES("42","5","（　　）生态环境主管部门应当结合本行政区域的工作实际，配备辐射防护安全监督员。","a:4:{i:0;a:3:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:6:\"县级\";s:8:\"isSelect\";i:0;}i:1;a:3:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:12:\"县级以上\";s:8:\"isSelect\";i:0;}i:2;a:3:{s:5:\"alias\";s:1:\"C\";s:6:\"answer\";s:6:\"省级\";s:8:\"isSelect\";i:0;}i:3;a:3:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:12:\"省级以上\";s:8:\"isSelect\";i:0;}}","a:1:{i:0;a:3:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:12:\"县级以上\";s:8:\"isSelect\";i:1;}}","1","B","1","","2","1000","1728549177","","0");
INSERT INTO cmf_answer_question VALUES("43","5","省级以上人民政府生态环境主管部门可以委托下一级生态环境主管部门颁发辐射安全许可证，对其颁发辐射安全许可证单位的监督检查应当由（　　）进行。","a:4:{i:0;a:3:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:9:\"委托方\";s:8:\"isSelect\";i:0;}i:1;a:3:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:15:\"接受委托方\";s:8:\"isSelect\";i:0;}i:2;a:3:{s:5:\"alias\";s:1:\"C\";s:6:\"answer\";s:12:\"双方共同\";s:8:\"isSelect\";i:0;}i:3;a:3:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:9:\"第三方\";s:8:\"isSelect\";i:0;}}","a:1:{i:0;a:3:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:9:\"委托方\";s:8:\"isSelect\";i:1;}}","0","A","1","","2","1000","1728549177","","0");
INSERT INTO cmf_answer_question VALUES("44","5","生产、销售、使用放射性同位素与射线装置的单位，应当对本单位的放射性同位素与射线装置的辐射安全和防护工作负责，并依法对其造成的（　　）承担责任。","a:4:{i:0;a:3:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:12:\"经济损失\";s:8:\"isSelect\";i:0;}i:1;a:3:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:12:\"名誉损失\";s:8:\"isSelect\";i:0;}i:2;a:3:{s:5:\"alias\";s:1:\"C\";s:6:\"answer\";s:12:\"信用损失\";s:8:\"isSelect\";i:0;}i:3;a:3:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:15:\"放射性危害\";s:8:\"isSelect\";i:0;}}","a:1:{i:0;a:3:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:15:\"放射性危害\";s:8:\"isSelect\";i:1;}}","3","D","1","","2","1000","1728549177","","0");
INSERT INTO cmf_answer_question VALUES("45","5","为了加强放射性同位素与射线装置的安全和防护管理，根据《中华人民共和国放射性污染防治法》和《放射性同位素与射线装置安全和防护条例》，制定（　　）。","a:4:{i:0;a:3:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:51:\"《放射性物品运输安全监督管理办法》\";s:8:\"isSelect\";i:0;}i:1;a:3:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:60:\"《环境保护主管部门实施按日连续处罚办法》\";s:8:\"isSelect\";i:0;}i:2;a:3:{s:5:\"alias\";s:1:\"C\";s:6:\"answer\";s:66:\"《放射性同位素与射线装置安全和防护管理办法》\";s:8:\"isSelect\";i:0;}i:3;a:3:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:36:\"《固体废物进口管理办法》\";s:8:\"isSelect\";i:0;}}","a:1:{i:0;a:3:{s:5:\"alias\";s:1:\"C\";s:6:\"answer\";s:66:\"《放射性同位素与射线装置安全和防护管理办法》\";s:8:\"isSelect\";i:1;}}","2","C","1","","2","1000","1728549177","","0");
INSERT INTO cmf_answer_question VALUES("46","5","为实施《放射性同位素与射线装置安全和防护条例》规定的辐射安全许可制度，制定（　　）。","a:4:{i:0;a:3:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:42:\"《排污许可管理办法（试行）》\";s:8:\"isSelect\";i:0;}i:1;a:3:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:51:\"《放射性物品运输安全许可管理办法》\";s:8:\"isSelect\";i:0;}i:2;a:3:{s:5:\"alias\";s:1:\"C\";s:6:\"answer\";s:63:\"《放射性同位素与射线装置安全许可管理办法》\";s:8:\"isSelect\";i:0;}i:3;a:3:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:60:\"《放射性固体废物贮存和处置许可管理办法》\";s:8:\"isSelect\";i:0;}}","a:1:{i:0;a:3:{s:5:\"alias\";s:1:\"C\";s:6:\"answer\";s:63:\"《放射性同位素与射线装置安全许可管理办法》\";s:8:\"isSelect\";i:1;}}","2","C","1","","2","1000","1728549177","","0");
INSERT INTO cmf_answer_question VALUES("47","5","生产、销售、使用放射性同位素与射线装置的单位，应当按照国家环境监测规范，对相关场所进行辐射监测，并对（　　）的真实性、可靠性负责。","a:4:{i:0;a:3:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:12:\"辐射监测\";s:8:\"isSelect\";i:0;}i:1;a:3:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:15:\"防护与安全\";s:8:\"isSelect\";i:0;}i:2;a:3:{s:5:\"alias\";s:1:\"C\";s:6:\"answer\";s:12:\"监测数据\";s:8:\"isSelect\";i:0;}i:3;a:3:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:18:\"个人剂量测量\";s:8:\"isSelect\";i:0;}}","a:1:{i:0;a:3:{s:5:\"alias\";s:1:\"C\";s:6:\"answer\";s:12:\"监测数据\";s:8:\"isSelect\";i:1;}}","2","C","1","","2","1000","1728549177","","0");
INSERT INTO cmf_answer_question VALUES("48","5","在室外、野外使用放射性同位素与射线装置的，应当按照国家安全和防护标准的要求划出（　　）区域，设置明显的放射性标志，必要时设专人警戒。","a:4:{i:0;a:3:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:12:\"安全防护\";s:8:\"isSelect\";i:0;}i:1;a:3:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:6:\"控制\";s:8:\"isSelect\";i:0;}i:2;a:3:{s:5:\"alias\";s:1:\"C\";s:6:\"answer\";s:6:\"监督\";s:8:\"isSelect\";i:0;}i:3;a:3:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:6:\"无人\";s:8:\"isSelect\";i:0;}}","a:1:{i:0;a:3:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:12:\"安全防护\";s:8:\"isSelect\";i:1;}}","0","A","1","","2","1000","1728549177","","0");
INSERT INTO cmf_answer_question VALUES("49","5","《放射性同位素与射线装置安全和防护管理办法》适用的相关活动，包括生产、销售、使用放射性同位素与射线装置的（　　）的安全和防护。","a:4:{i:0;a:3:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:6:\"场所\";s:8:\"isSelect\";i:0;}i:1;a:3:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:6:\"物品\";s:8:\"isSelect\";i:0;}i:2;a:3:{s:5:\"alias\";s:1:\"C\";s:6:\"answer\";s:6:\"人员\";s:8:\"isSelect\";i:0;}i:3;a:3:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:15:\"场所、人员\";s:8:\"isSelect\";i:0;}}","a:1:{i:0;a:3:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:15:\"场所、人员\";s:8:\"isSelect\";i:1;}}","3","D","1","","2","1000","1728549177","","0");
INSERT INTO cmf_answer_question VALUES("50","5","为了避免发生辐射的确定性效应，并把随机性效应发生率降至可接受的水平，必须对个人剂量加以限制。职业人员所受到的照射剂量限值中，由审管部门决定的连续5年的年平均有效剂量是（　　）。","a:4:{i:0;a:3:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:7:\"15mSv/a\";s:8:\"isSelect\";i:0;}i:1;a:3:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:7:\"50mSv/a\";s:8:\"isSelect\";i:0;}i:2;a:3:{s:5:\"alias\";s:1:\"C\";s:6:\"answer\";s:7:\"20mSv/a\";s:8:\"isSelect\";i:0;}i:3;a:3:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:8:\"500mSv/a\";s:8:\"isSelect\";i:0;}}","a:1:{i:0;a:3:{s:5:\"alias\";s:1:\"C\";s:6:\"answer\";s:7:\"20mSv/a\";s:8:\"isSelect\";i:1;}}","2","C","1","","2","1000","1728549177","","0");
INSERT INTO cmf_answer_question VALUES("51","5","当辐射源为点源时，剂量率与点源距离的关系为（　　），因此控制距离是一种控制外照射的有效方法。","a:4:{i:0;a:3:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:6:\"正比\";s:8:\"isSelect\";i:0;}i:1;a:3:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:6:\"反比\";s:8:\"isSelect\";i:0;}i:2;a:3:{s:5:\"alias\";s:1:\"C\";s:6:\"answer\";s:12:\"平方正比\";s:8:\"isSelect\";i:0;}i:3;a:3:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:12:\"平方反比\";s:8:\"isSelect\";i:0;}}","a:1:{i:0;a:3:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:12:\"平方反比\";s:8:\"isSelect\";i:1;}}","3","D","1","","2","1000","1728549177","","0");
INSERT INTO cmf_answer_question VALUES("52","5","由于光电效应、康普顿效应和电子对效应的反应截面都是随靶物质原子序数的增加而增加，所以屏蔽X或γ射线需要高原子序数的物质如铅、铁或混凝土。对于相同厚度的下列材料，哪种材料对高能X射线的屏蔽效果最好（　　）。","a:4:{i:0;a:3:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:3:\"水\";s:8:\"isSelect\";i:0;}i:1;a:3:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:9:\"聚乙烯\";s:8:\"isSelect\";i:0;}i:2;a:3:{s:5:\"alias\";s:1:\"C\";s:6:\"answer\";s:3:\"铁\";s:8:\"isSelect\";i:0;}i:3;a:3:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:3:\"铅\";s:8:\"isSelect\";i:0;}}","a:1:{i:0;a:3:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:3:\"铅\";s:8:\"isSelect\";i:1;}}","3","D","1","","2","1000","1728549177","","0");
INSERT INTO cmf_answer_question VALUES("53","5","为便于辐射防护管理和职业照射控制，在现行的基本安全标准《电离辐射防护与辐射源安全基本标准》（GB18871-2002）中将辐射工作场所分为控制区和监督区，将需要和可能需要（　　）的区域定为控制区，通常设置为红色。","a:4:{i:0;a:3:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:33:\"专门防护手段或安全措施\";s:8:\"isSelect\";i:0;}i:1;a:3:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:12:\"防护手段\";s:8:\"isSelect\";i:0;}i:2;a:3:{s:5:\"alias\";s:1:\"C\";s:6:\"answer\";s:12:\"安全措施\";s:8:\"isSelect\";i:0;}i:3;a:3:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:12:\"人为控制\";s:8:\"isSelect\";i:0;}}","a:1:{i:0;a:3:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:33:\"专门防护手段或安全措施\";s:8:\"isSelect\";i:1;}}","0","A","1","","2","1000","1728549177","","0");
INSERT INTO cmf_answer_question VALUES("54","5","为便于辐射防护管理和职业照射控制，在现行的基本安全标准《电离辐射防护与辐射源走向安全基本标准》（GB18871-2002）中将辐射工作场所分为控制区和监督区。未定位控制区，但需要对辐射照射条件进行监督和评价的区域定为监督区，通常设置为（），并在入口处的适当地点设置表明监督区的标牌。","a:4:{i:0;a:3:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:6:\"红色\";s:8:\"isSelect\";i:0;}i:1;a:3:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:6:\"橙色\";s:8:\"isSelect\";i:0;}i:2;a:3:{s:5:\"alias\";s:1:\"C\";s:6:\"answer\";s:6:\"黄色\";s:8:\"isSelect\";i:0;}i:3;a:3:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:6:\"绿色\";s:8:\"isSelect\";i:0;}}","a:1:{i:0;a:3:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:6:\"橙色\";s:8:\"isSelect\";i:1;}}","1","B","1","","2","1000","1728549177","","0");
INSERT INTO cmf_answer_question VALUES("55","5","对于控制区，在进出口及其它适当位置处设立（　　）、符合规定的警告标志，并给出相应的辐射污染水平和污染水平的指示。","a:4:{i:0;a:3:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:9:\"橙色的\";s:8:\"isSelect\";i:0;}i:1;a:3:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:9:\"醒目的\";s:8:\"isSelect\";i:0;}i:2;a:3:{s:5:\"alias\";s:1:\"C\";s:6:\"answer\";s:6:\"小的\";s:8:\"isSelect\";i:0;}i:3;a:3:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:6:\"大的\";s:8:\"isSelect\";i:0;}}","a:1:{i:0;a:3:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:9:\"醒目的\";s:8:\"isSelect\";i:1;}}","1","B","1","","2","1000","1728549177","","0");
INSERT INTO cmf_answer_question VALUES("56","5","关于控制区的设置，下列说法错误的是（　　）。","a:4:{i:0;a:3:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:42:\"在进出口设立醒目的警告标志。\";s:8:\"isSelect\";i:0;}i:1;a:3:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:36:\"警告标志通常设置为黄色。\";s:8:\"isSelect\";i:0;}i:2;a:3:{s:5:\"alias\";s:1:\"C\";s:6:\"answer\";s:63:\"控制区通常不需要专门的防护手段或安全措施。\";s:8:\"isSelect\";i:0;}i:3;a:3:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:66:\"控制正常工作条件下的正常照射或防止污染扩散。\";s:8:\"isSelect\";i:0;}}","a:1:{i:0;a:3:{s:5:\"alias\";s:1:\"C\";s:6:\"answer\";s:63:\"控制区通常不需要专门的防护手段或安全措施。\";s:8:\"isSelect\";i:1;}}","2","C","1","","2","1000","1728549177","","0");
INSERT INTO cmf_answer_question VALUES("57","5","关于辐射工作场所的分区，下列说法错误的是（　　）。","a:4:{i:0;a:3:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:33:\"为了便于辐射防护管理。\";s:8:\"isSelect\";i:0;}i:1;a:3:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:78:\"现行的基本安全标准GB18871-2002中将辐射工作场所进行分区。\";s:8:\"isSelect\";i:0;}i:2;a:3:{s:5:\"alias\";s:1:\"C\";s:6:\"answer\";s:51:\"放射性工作场所分为监督区和操作区。\";s:8:\"isSelect\";i:0;}i:3;a:3:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:33:\"为了便于职业照射控制。\";s:8:\"isSelect\";i:0;}}","a:1:{i:0;a:3:{s:5:\"alias\";s:1:\"C\";s:6:\"answer\";s:51:\"放射性工作场所分为监督区和操作区。\";s:8:\"isSelect\";i:1;}}","2","C","1","","2","1000","1728549177","","0");
INSERT INTO cmf_answer_question VALUES("58","5","离子注入机按束流大小分为（　　）。","a:5:{i:0;a:3:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:24:\"小束流离子注入机\";s:8:\"isSelect\";i:0;}i:1;a:3:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:24:\"中束流离子注入机\";s:8:\"isSelect\";i:0;}i:2;a:3:{s:5:\"alias\";s:1:\"C\";s:6:\"answer\";s:21:\"强流离子注入机\";s:8:\"isSelect\";i:0;}i:3;a:3:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:27:\"微小束流离子注入机\";s:8:\"isSelect\";i:0;}i:4;a:3:{s:5:\"alias\";s:1:\"E\";s:6:\"answer\";s:24:\"超强流离子注入机\";s:8:\"isSelect\";i:0;}}","a:4:{i:0;a:3:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:24:\"小束流离子注入机\";s:8:\"isSelect\";i:1;}i:1;a:3:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:24:\"中束流离子注入机\";s:8:\"isSelect\";i:1;}i:2;a:3:{s:5:\"alias\";s:1:\"C\";s:6:\"answer\";s:21:\"强流离子注入机\";s:8:\"isSelect\";i:1;}i:3;a:3:{s:5:\"alias\";s:1:\"E\";s:6:\"answer\";s:24:\"超强流离子注入机\";s:8:\"isSelect\";i:1;}}","0,1,2,4","A,B,C,E","2","","4","1000","1728549177","","0");
INSERT INTO cmf_answer_question VALUES("59","5","X射线行李包检查装置，操作人员应每天检查设备的辐射安全设施状态，主要包括（　　），任何辐射安全设施不能正常工作时，系统不允许出束。","a:5:{i:0;a:3:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:6:\"屏蔽\";s:8:\"isSelect\";i:0;}i:1;a:3:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:12:\"声光报警\";s:8:\"isSelect\";i:0;}i:2;a:3:{s:5:\"alias\";s:1:\"C\";s:6:\"answer\";s:9:\"门联锁\";s:8:\"isSelect\";i:0;}i:3;a:3:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:6:\"急停\";s:8:\"isSelect\";i:0;}i:4;a:3:{s:5:\"alias\";s:1:\"E\";s:6:\"answer\";s:18:\"数据处理软件\";s:8:\"isSelect\";i:0;}}","a:4:{i:0;a:3:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:6:\"屏蔽\";s:8:\"isSelect\";i:1;}i:1;a:3:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:12:\"声光报警\";s:8:\"isSelect\";i:1;}i:2;a:3:{s:5:\"alias\";s:1:\"C\";s:6:\"answer\";s:9:\"门联锁\";s:8:\"isSelect\";i:1;}i:3;a:3:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:6:\"急停\";s:8:\"isSelect\";i:1;}}","0,1,2,3","A,B,C,D","2","","4","1000","1728549177","","0");
INSERT INTO cmf_answer_question VALUES("60","5","《电离辐射防护与辐射源安全基本标准》规定的豁免水平是:正常运行操作条件下，任何可达表面0.1m处所引起的周围剂量当量率或定向剂量当量率不超过1μSv/h或所产生辐射的最大能量不大于5keV。根据环境保护部、国家卫生和计划生育委员会《关于发布<射线装置分类>的公告》（公告2017年第66号），下列射线装置中，对其设备的用户单位实行豁免管理的有（　　）。","a:5:{i:0;a:3:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:28:\"X射线行李包检查装置\";s:8:\"isSelect\";i:0;}i:1;a:3:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:24:\"工业探伤用加速器\";s:8:\"isSelect\";i:0;}i:2;a:3:{s:5:\"alias\";s:1:\"C\";s:6:\"answer\";s:15:\"电子束焊机\";s:8:\"isSelect\";i:0;}i:3;a:3:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:24:\"工业辐照用加速器\";s:8:\"isSelect\";i:0;}i:4;a:3:{s:5:\"alias\";s:1:\"E\";s:6:\"answer\";s:28:\"车辆检查用X射线装置\";s:8:\"isSelect\";i:0;}}","a:2:{i:0;a:3:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:28:\"X射线行李包检查装置\";s:8:\"isSelect\";i:1;}i:1;a:3:{s:5:\"alias\";s:1:\"E\";s:6:\"answer\";s:28:\"车辆检查用X射线装置\";s:8:\"isSelect\";i:1;}}","0,4","A,E","2","","4","1000","1728549177","","0");
INSERT INTO cmf_answer_question VALUES("61","5","X射线行李包检查装置的安全操作要求正确的有（　　）。","a:5:{i:0;a:3:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:90:\"每次出束前，操作人员负责巡查确保系统辐射防护区内无人员滞留。\";s:8:\"isSelect\";i:0;}i:1;a:3:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:114:\"系统扫描工作过程中，当发现有人员误入辐射防护区时，操作员应立即停止系统出束。\";s:8:\"isSelect\";i:0;}i:2;a:3:{s:5:\"alias\";s:1:\"C\";s:6:\"answer\";s:64:\"X光机上电期间，禁止任何人员进入扫描通道内。\";s:8:\"isSelect\";i:0;}i:3;a:3:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:64:\"X光机上电期间，操作人员可以进入扫描通道内。\";s:8:\"isSelect\";i:0;}i:4;a:3:{s:5:\"alias\";s:1:\"E\";s:6:\"answer\";s:105:\"系统停止工作后，负责人应妥善保管好安全联锁钥匙，以防止未经许可的使用。\";s:8:\"isSelect\";i:0;}}","a:4:{i:0;a:3:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:90:\"每次出束前，操作人员负责巡查确保系统辐射防护区内无人员滞留。\";s:8:\"isSelect\";i:1;}i:1;a:3:{s:5:\"alias\";b:0;s:6:\"answer\";s:144:\"系统扫描工作过程中，当发现有人员误入辐射防护区的人员误入辐射防护区时，操作员应立即停止系统出束。\";s:8:\"isSelect\";i:1;}i:2;a:3:{s:5:\"alias\";s:1:\"C\";s:6:\"answer\";s:64:\"X光机上电期间，禁止任何人员进入扫描通道内。\";s:8:\"isSelect\";i:1;}i:3;a:3:{s:5:\"alias\";s:1:\"E\";s:6:\"answer\";s:105:\"系统停止工作后，负责人应妥善保管好安全联锁钥匙，以防止未经许可的使用。\";s:8:\"isSelect\";i:1;}}","0,,2,4","A,,C,E","2","","4","1000","1728549177","","0");
INSERT INTO cmf_answer_question VALUES("62","5","X射线行李包检查装置的部件有（　　）。","a:5:{i:0;a:3:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:9:\"探测器\";s:8:\"isSelect\";i:0;}i:1;a:3:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:12:\"传送装置\";s:8:\"isSelect\";i:0;}i:2;a:3:{s:5:\"alias\";s:1:\"C\";s:6:\"answer\";s:28:\"一体化的X射线发生器\";s:8:\"isSelect\";i:0;}i:3;a:3:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:18:\"辐射安全系统\";s:8:\"isSelect\";i:0;}i:4;a:3:{s:5:\"alias\";s:1:\"E\";s:6:\"answer\";s:18:\"数据处理软件\";s:8:\"isSelect\";i:0;}}","a:5:{i:0;a:3:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:9:\"探测器\";s:8:\"isSelect\";i:1;}i:1;a:3:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:12:\"传送装置\";s:8:\"isSelect\";i:1;}i:2;a:3:{s:5:\"alias\";s:1:\"C\";s:6:\"answer\";s:28:\"一体化的X射线发生器\";s:8:\"isSelect\";i:1;}i:3;a:3:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:18:\"辐射安全系统\";s:8:\"isSelect\";i:1;}i:4;a:3:{s:5:\"alias\";s:1:\"E\";s:6:\"answer\";s:18:\"数据处理软件\";s:8:\"isSelect\";i:1;}}","0,1,2,3,4","A,B,C,D,E","2","","4","1000","1728549177","","0");
INSERT INTO cmf_answer_question VALUES("63","5","以下属于核子秤优点的是（　　）。","a:5:{i:0;a:3:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:42:\"不受物料的物理化学性质的影响\";s:8:\"isSelect\";i:0;}i:1;a:3:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:51:\"动态测量精度高，性能稳定，工作可靠\";s:8:\"isSelect\";i:0;}i:2;a:3:{s:5:\"alias\";s:1:\"C\";s:6:\"answer\";s:12:\"结构简单\";s:8:\"isSelect\";i:0;}i:3;a:3:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:30:\"可在恶劣的环境下工作\";s:8:\"isSelect\";i:0;}i:4;a:3:{s:5:\"alias\";s:1:\"E\";s:6:\"answer\";s:27:\"可显示多种监测参数\";s:8:\"isSelect\";i:0;}}","a:4:{i:0;a:3:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:51:\"动态测量精度高，性能稳定，工作可靠\";s:8:\"isSelect\";i:1;}i:1;a:3:{s:5:\"alias\";s:1:\"C\";s:6:\"answer\";s:12:\"结构简单\";s:8:\"isSelect\";i:1;}i:2;a:3:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:30:\"可在恶劣的环境下工作\";s:8:\"isSelect\";i:1;}i:3;a:3:{s:5:\"alias\";s:1:\"E\";s:6:\"answer\";s:27:\"可显示多种监测参数\";s:8:\"isSelect\";i:1;}}","1,2,3,4","B,C,D,E","2","","4","1000","1728549177","","0");
INSERT INTO cmf_answer_question VALUES("64","5","下列单位中应当按照《放射性同位素与射线装置安全和防护条例》规定取得辐射安全许可证的是（　　）。","a:5:{i:0;a:3:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:24:\"销售放射源的企业\";s:8:\"isSelect\";i:0;}i:1;a:3:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:33:\"使用Ⅲ类射线装置的单位\";s:8:\"isSelect\";i:0;}i:2;a:3:{s:5:\"alias\";s:1:\"C\";s:6:\"answer\";s:30:\"使用放射源的探伤企业\";s:8:\"isSelect\";i:0;}i:3;a:3:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:63:\"具有丙级非密封放射性物质使用场所的科研机构\";s:8:\"isSelect\";i:0;}i:4;a:3:{s:5:\"alias\";s:1:\"E\";s:6:\"answer\";s:48:\"仅使用豁免水平标准物质的科研单位\";s:8:\"isSelect\";i:0;}}","a:4:{i:0;a:3:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:24:\"销售放射源的企业\";s:8:\"isSelect\";i:1;}i:1;a:3:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:33:\"使用Ⅲ类射线装置的单位\";s:8:\"isSelect\";i:1;}i:2;a:3:{s:5:\"alias\";s:1:\"C\";s:6:\"answer\";s:30:\"使用放射源的探伤企业\";s:8:\"isSelect\";i:1;}i:3;a:3:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:63:\"具有丙级非密封放射性物质使用场所的科研机构\";s:8:\"isSelect\";i:1;}}","0,1,2,3","A,B,C,D","2","","4","1000","1728549177","","0");
INSERT INTO cmf_answer_question VALUES("65","5","辐射安全许可证内容包括以下哪些信息？（　　）","a:5:{i:0;a:3:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:12:\"单位名称\";s:8:\"isSelect\";i:0;}i:1;a:3:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:12:\"经营范围\";s:8:\"isSelect\";i:0;}i:2;a:3:{s:5:\"alias\";s:1:\"C\";s:6:\"answer\";s:12:\"注册资本\";s:8:\"isSelect\";i:0;}i:3;a:3:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:33:\"所从事活动的种类和范围\";s:8:\"isSelect\";i:0;}i:4;a:3:{s:5:\"alias\";s:1:\"E\";s:6:\"answer\";s:12:\"有效期限\";s:8:\"isSelect\";i:0;}}","a:3:{i:0;a:3:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:12:\"单位名称\";s:8:\"isSelect\";i:1;}i:1;a:3:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:33:\"所从事活动的种类和范围\";s:8:\"isSelect\";i:1;}i:2;a:3:{s:5:\"alias\";s:1:\"E\";s:6:\"answer\";s:12:\"有效期限\";s:8:\"isSelect\";i:1;}}","0,3,4","A,D,E","2","","4","1000","1728549177","","0");
INSERT INTO cmf_answer_question VALUES("66","5","环境监测的目的包含（　　）。","a:5:{i:0;a:3:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:90:\"检验监测对象是否和国家、地方、行业或审管部门的有关规定相符合\";s:8:\"isSelect\";i:0;}i:1;a:3:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:24:\"监视设施运行状态\";s:8:\"isSelect\";i:0;}i:2;a:3:{s:5:\"alias\";s:1:\"C\";s:6:\"answer\";s:66:\"及时发现环境中放射性水平的变化趋势和异常情况\";s:8:\"isSelect\";i:0;}i:3;a:3:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:60:\"在事故工况下，为事故应急工作提供决策依据\";s:8:\"isSelect\";i:0;}i:4;a:3:{s:5:\"alias\";s:1:\"E\";s:6:\"answer\";s:81:\"监测结果既是环境影响评价的基础，也可以用于验证评价模式\";s:8:\"isSelect\";i:0;}}","a:5:{i:0;a:3:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:90:\"检验监测对象是否和国家、地方、行业或审管部门的有关规定相符合\";s:8:\"isSelect\";i:1;}i:1;a:3:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:24:\"监视设施运行状态\";s:8:\"isSelect\";i:1;}i:2;a:3:{s:5:\"alias\";s:1:\"C\";s:6:\"answer\";s:66:\"及时发现环境中放射性水平的变化趋势和异常情况\";s:8:\"isSelect\";i:1;}i:3;a:3:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:60:\"在事故工况下，为事故应急工作提供决策依据\";s:8:\"isSelect\";i:1;}i:4;a:3:{s:5:\"alias\";s:1:\"E\";s:6:\"answer\";s:81:\"监测结果既是环境影响评价的基础，也可以用于验证评价模式\";s:8:\"isSelect\";i:1;}}","0,1,2,3,4","A,B,C,D,E","2","","4","1000","1728549177","","0");
INSERT INTO cmf_answer_question VALUES("67","5","辐射防护要解决的是辐射应用与辐射危害之间的矛盾，下列关于辐射防护基本任务说法正确的是（　　）。","a:5:{i:0;a:4:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:42:\"辐射防护的任务之一是保护环境\";s:5:\"image\";s:81:\"https://oss.ausite.cn/dzkf382/admin/20241014/9df39c445de50f215cda041e3b1de188.png\";s:8:\"isSelect\";i:0;}i:1;a:4:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:87:\"保障从事放射性工作的人员和公众的健康和安全，保护他们的后代\";s:5:\"image\";s:81:\"https://oss.ausite.cn/dzkf382/admin/20241014/9df39c445de50f215cda041e3b1de188.png\";s:8:\"isSelect\";i:0;}i:2;a:4:{s:5:\"alias\";s:1:\"C\";s:6:\"answer\";s:30:\"促进原子能事业的发展\";s:5:\"image\";s:81:\"https://oss.ausite.cn/dzkf382/admin/20241014/9df39c445de50f215cda041e3b1de188.png\";s:8:\"isSelect\";i:0;}i:3;a:4:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:30:\"促进核武器事业的发展\";s:5:\"image\";s:81:\"https://oss.ausite.cn/dzkf382/admin/20241014/9df39c445de50f215cda041e3b1de188.png\";s:8:\"isSelect\";i:0;}i:4;a:4:{s:5:\"alias\";s:1:\"E\";s:6:\"answer\";s:45:\"尽一切手段将辐射降低到最低水平\";s:5:\"image\";s:81:\"https://oss.ausite.cn/dzkf382/admin/20241014/9df39c445de50f215cda041e3b1de188.png\";s:8:\"isSelect\";i:0;}}","a:3:{i:0;a:4:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:42:\"辐射防护的任务之一是保护环境\";s:5:\"image\";s:81:\"https://oss.ausite.cn/dzkf382/admin/20241014/9df39c445de50f215cda041e3b1de188.png\";s:8:\"isSelect\";i:1;}i:1;a:4:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:87:\"保障从事放射性工作的人员和公众的健康和安全，保护他们的后代\";s:5:\"image\";s:81:\"https://oss.ausite.cn/dzkf382/admin/20241014/9df39c445de50f215cda041e3b1de188.png\";s:8:\"isSelect\";i:1;}i:2;a:4:{s:5:\"alias\";s:1:\"C\";s:6:\"answer\";s:30:\"促进原子能事业的发展\";s:5:\"image\";s:81:\"https://oss.ausite.cn/dzkf382/admin/20241014/9df39c445de50f215cda041e3b1de188.png\";s:8:\"isSelect\";i:1;}}","0,1,2","A,B,C","2","解析解析解析解析解析解析解析解析解析解析解析解析解析","4","1000","1728549177","1729059506","0");
INSERT INTO cmf_answer_question VALUES("68","6","测试","a:4:{i:0;a:4:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:7:\"选项1\";s:5:\"image\";N;s:8:\"isSelect\";i:0;}i:1;a:4:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:7:\"选项2\";s:5:\"image\";N;s:8:\"isSelect\";i:0;}i:2;a:4:{s:5:\"alias\";s:1:\"C\";s:6:\"answer\";s:7:\"选项3\";s:5:\"image\";N;s:8:\"isSelect\";i:0;}i:3;a:4:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:7:\"选项4\";s:5:\"image\";N;s:8:\"isSelect\";i:0;}}","a:2:{i:0;a:4:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:7:\"选项1\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}i:1;a:4:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:7:\"选项2\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}}","0,1","A,B","2","1010101111111111","10","1000","1728962181","1729561798","0");



DROP TABLE cmf_answer_result;

CREATE TABLE `cmf_answer_result` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `exam_id` int(11) DEFAULT NULL COMMENT '题库',
  `name` varchar(255) DEFAULT NULL COMMENT '名称',
  `user_answer` text COMMENT '用户答题记录',
  `question` text COMMENT '题目列表',
  `score` varchar(255) DEFAULT NULL COMMENT '得分',
  `time` varchar(255) DEFAULT NULL COMMENT '答题时长',
  `true_number` int(11) DEFAULT NULL COMMENT '答对题目',
  `false_number` int(11) DEFAULT NULL COMMENT '打错题目',
  `create_time` bigint(20) DEFAULT NULL COMMENT '创建时间',
  `update_time` bigint(20) DEFAULT NULL COMMENT '更新时间',
  `delete_time` bigint(20) DEFAULT '0' COMMENT '删除时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8mb4 COMMENT='答题结果';

INSERT INTO cmf_answer_result VALUES("27","2","6","第二部分：核技术利用辐射安全法律法规","a:3:{i:0;a:2:{s:2:\"id\";s:2:\"10\";s:6:\"answer\";s:1:\"A\";}i:1;a:2:{s:2:\"id\";s:2:\"68\";s:6:\"answer\";a:2:{i:0;s:1:\"A\";i:1;s:1:\"B\";}}i:2;a:2:{s:2:\"id\";s:2:\"11\";s:6:\"answer\";a:2:{i:0;s:1:\"A\";i:1;s:1:\"D\";}}}","a:3:{i:0;a:15:{s:2:\"id\";i:10;s:3:\"pid\";i:6;s:4:\"name\";s:14:\"第二部分01\";s:6:\"option\";a:2:{i:0;a:4:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:1:\"a\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}i:1;a:4:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:1:\"b\";s:5:\"image\";N;s:8:\"isSelect\";i:0;}}s:6:\"answer\";a:1:{i:0;a:4:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:1:\"b\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}}s:10:\"answer_key\";s:1:\"1\";s:13:\"answer_letter\";a:1:{i:0;s:1:\"B\";}s:11:\"option_type\";i:1;s:8:\"analysis\";N;s:5:\"score\";s:1:\"1\";s:10:\"list_order\";i:1000;s:11:\"create_time\";i:1728374193;s:11:\"update_time\";N;s:16:\"option_type_name\";s:6:\"单选\";s:10:\"is_correct\";b:0;}i:1;a:15:{s:2:\"id\";i:68;s:3:\"pid\";i:6;s:4:\"name\";s:6:\"测试\";s:6:\"option\";a:4:{i:0;a:4:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:7:\"选项1\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}i:1;a:4:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:7:\"选项2\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}i:2;a:4:{s:5:\"alias\";s:1:\"C\";s:6:\"answer\";s:7:\"选项3\";s:5:\"image\";N;s:8:\"isSelect\";i:0;}i:3;a:4:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:7:\"选项4\";s:5:\"image\";N;s:8:\"isSelect\";i:0;}}s:6:\"answer\";a:2:{i:0;a:4:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:7:\"选项1\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}i:1;a:4:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:7:\"选项2\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}}s:10:\"answer_key\";s:3:\"0,1\";s:13:\"answer_letter\";a:2:{i:0;s:1:\"A\";i:1;s:1:\"B\";}s:11:\"option_type\";i:2;s:8:\"analysis\";N;s:5:\"score\";s:1:\"5\";s:10:\"list_order\";i:1000;s:11:\"create_time\";i:1728962181;s:11:\"update_time\";N;s:16:\"option_type_name\";s:6:\"多选\";s:10:\"is_correct\";b:1;}i:2;a:15:{s:2:\"id\";i:11;s:3:\"pid\";i:6;s:4:\"name\";s:14:\"第二部分02\";s:6:\"option\";a:4:{i:0;a:4:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:1:\"a\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}i:1;a:4:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:1:\"b\";s:5:\"image\";N;s:8:\"isSelect\";i:0;}i:2;a:4:{s:5:\"alias\";s:1:\"C\";s:6:\"answer\";s:1:\"c\";s:5:\"image\";N;s:8:\"isSelect\";i:0;}i:3;a:4:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:1:\"d\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}}s:6:\"answer\";a:2:{i:0;a:4:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:1:\"b\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}i:1;a:4:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:1:\"d\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}}s:10:\"answer_key\";s:3:\"1,3\";s:13:\"answer_letter\";a:2:{i:0;s:1:\"B\";i:1;s:1:\"D\";}s:11:\"option_type\";i:2;s:8:\"analysis\";N;s:5:\"score\";s:1:\"5\";s:10:\"list_order\";i:1000;s:11:\"create_time\";i:1728374211;s:11:\"update_time\";N;s:16:\"option_type_name\";s:6:\"多选\";s:10:\"is_correct\";b:0;}}","5","80","1","2","1729222098","","0");
INSERT INTO cmf_answer_result VALUES("28","2","6","第二部分：核技术利用辐射安全法律法规","a:3:{i:0;a:2:{s:2:\"id\";s:2:\"10\";s:6:\"answer\";s:1:\"B\";}i:1;a:2:{s:2:\"id\";s:2:\"11\";s:6:\"answer\";a:2:{i:0;s:1:\"A\";i:1;s:1:\"B\";}}i:2;a:2:{s:2:\"id\";s:2:\"68\";s:6:\"answer\";a:2:{i:0;s:1:\"A\";i:1;s:1:\"B\";}}}","a:3:{i:0;a:15:{s:2:\"id\";i:10;s:3:\"pid\";i:6;s:4:\"name\";s:14:\"第二部分01\";s:6:\"option\";a:2:{i:0;a:4:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:1:\"a\";s:5:\"image\";N;s:8:\"isSelect\";i:0;}i:1;a:4:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:1:\"b\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}}s:6:\"answer\";a:1:{i:0;a:4:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:1:\"b\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}}s:10:\"answer_key\";s:1:\"1\";s:13:\"answer_letter\";a:1:{i:0;s:1:\"B\";}s:11:\"option_type\";i:1;s:8:\"analysis\";N;s:5:\"score\";s:1:\"1\";s:10:\"list_order\";i:1000;s:11:\"create_time\";i:1728374193;s:11:\"update_time\";N;s:16:\"option_type_name\";s:6:\"单选\";s:10:\"is_correct\";b:1;}i:1;a:15:{s:2:\"id\";i:11;s:3:\"pid\";i:6;s:4:\"name\";s:14:\"第二部分02\";s:6:\"option\";a:4:{i:0;a:4:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:1:\"a\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}i:1;a:4:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:1:\"b\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}i:2;a:4:{s:5:\"alias\";s:1:\"C\";s:6:\"answer\";s:1:\"c\";s:5:\"image\";N;s:8:\"isSelect\";i:0;}i:3;a:4:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:1:\"d\";s:5:\"image\";N;s:8:\"isSelect\";i:0;}}s:6:\"answer\";a:2:{i:0;a:4:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:1:\"b\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}i:1;a:4:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:1:\"d\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}}s:10:\"answer_key\";s:3:\"1,3\";s:13:\"answer_letter\";a:2:{i:0;s:1:\"B\";i:1;s:1:\"D\";}s:11:\"option_type\";i:2;s:8:\"analysis\";N;s:5:\"score\";s:1:\"5\";s:10:\"list_order\";i:1000;s:11:\"create_time\";i:1728374211;s:11:\"update_time\";N;s:16:\"option_type_name\";s:6:\"多选\";s:10:\"is_correct\";b:0;}i:2;a:15:{s:2:\"id\";i:68;s:3:\"pid\";i:6;s:4:\"name\";s:6:\"测试\";s:6:\"option\";a:4:{i:0;a:4:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:7:\"选项1\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}i:1;a:4:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:7:\"选项2\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}i:2;a:4:{s:5:\"alias\";s:1:\"C\";s:6:\"answer\";s:7:\"选项3\";s:5:\"image\";N;s:8:\"isSelect\";i:0;}i:3;a:4:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:7:\"选项4\";s:5:\"image\";N;s:8:\"isSelect\";i:0;}}s:6:\"answer\";a:2:{i:0;a:4:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:7:\"选项1\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}i:1;a:4:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:7:\"选项2\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}}s:10:\"answer_key\";s:3:\"0,1\";s:13:\"answer_letter\";a:2:{i:0;s:1:\"A\";i:1;s:1:\"B\";}s:11:\"option_type\";i:2;s:8:\"analysis\";N;s:5:\"score\";s:1:\"5\";s:10:\"list_order\";i:1000;s:11:\"create_time\";i:1728962181;s:11:\"update_time\";N;s:16:\"option_type_name\";s:6:\"多选\";s:10:\"is_correct\";b:1;}}","6","80","2","1","1729302237","","0");
INSERT INTO cmf_answer_result VALUES("29","3","7","第三部分：专业实务","a:2:{i:0;a:2:{s:2:\"id\";s:2:\"12\";s:6:\"answer\";s:1:\"A\";}i:1;a:2:{s:2:\"id\";s:2:\"13\";s:6:\"answer\";a:2:{i:0;s:1:\"A\";i:1;s:1:\"B\";}}}","a:2:{i:0;a:15:{s:2:\"id\";i:12;s:3:\"pid\";i:7;s:4:\"name\";s:14:\"第三部分01\";s:6:\"option\";a:2:{i:0;a:4:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:1:\"a\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}i:1;a:4:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:1:\"b\";s:5:\"image\";N;s:8:\"isSelect\";i:0;}}s:6:\"answer\";a:1:{i:0;a:4:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:1:\"a\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}}s:10:\"answer_key\";s:1:\"0\";s:13:\"answer_letter\";a:1:{i:0;s:1:\"A\";}s:11:\"option_type\";i:1;s:8:\"analysis\";N;s:5:\"score\";s:1:\"8\";s:10:\"list_order\";i:1000;s:11:\"create_time\";i:1728374239;s:11:\"update_time\";N;s:16:\"option_type_name\";s:6:\"单选\";s:10:\"is_correct\";b:1;}i:1;a:15:{s:2:\"id\";i:13;s:3:\"pid\";i:7;s:4:\"name\";s:14:\"第三部分02\";s:6:\"option\";a:4:{i:0;a:4:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:1:\"a\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}i:1;a:4:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:1:\"b\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}i:2;a:4:{s:5:\"alias\";s:1:\"C\";s:6:\"answer\";s:1:\"c\";s:5:\"image\";N;s:8:\"isSelect\";i:0;}i:3;a:4:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:1:\"d\";s:5:\"image\";N;s:8:\"isSelect\";i:0;}}s:6:\"answer\";a:2:{i:0;a:4:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:1:\"a\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}i:1;a:4:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:1:\"d\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}}s:10:\"answer_key\";s:3:\"0,3\";s:13:\"answer_letter\";a:2:{i:0;s:1:\"A\";i:1;s:1:\"D\";}s:11:\"option_type\";i:2;s:8:\"analysis\";N;s:5:\"score\";s:1:\"5\";s:10:\"list_order\";i:1000;s:11:\"create_time\";i:1728374259;s:11:\"update_time\";N;s:16:\"option_type_name\";s:6:\"多选\";s:10:\"is_correct\";b:0;}}","8","119","1","1","1729560072","","0");
INSERT INTO cmf_answer_result VALUES("30","3","6","第二部分：核技术利用辐射安全法律法规","a:3:{i:0;a:2:{s:2:\"id\";s:2:\"10\";s:6:\"answer\";s:1:\"A\";}i:1;a:2:{s:2:\"id\";s:2:\"68\";s:6:\"answer\";a:2:{i:0;s:1:\"A\";i:1;s:1:\"C\";}}i:2;a:1:{s:2:\"id\";s:2:\"11\";}}","a:3:{i:0;a:15:{s:2:\"id\";i:10;s:3:\"pid\";i:6;s:4:\"name\";s:14:\"第二部分01\";s:6:\"option\";a:2:{i:0;a:4:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:1:\"a\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}i:1;a:4:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:1:\"b\";s:5:\"image\";N;s:8:\"isSelect\";i:0;}}s:6:\"answer\";a:1:{i:0;a:4:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:1:\"b\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}}s:10:\"answer_key\";s:1:\"1\";s:13:\"answer_letter\";a:1:{i:0;s:1:\"B\";}s:11:\"option_type\";i:1;s:8:\"analysis\";s:59:\"11111111111111111111111111111111111222222222222222222222222\";s:5:\"score\";s:2:\"10\";s:10:\"list_order\";i:1000;s:11:\"create_time\";i:1728374193;s:11:\"update_time\";i:1729561775;s:16:\"option_type_name\";s:6:\"单选\";s:10:\"is_correct\";b:0;}i:1;a:15:{s:2:\"id\";i:68;s:3:\"pid\";i:6;s:4:\"name\";s:6:\"测试\";s:6:\"option\";a:4:{i:0;a:4:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:7:\"选项1\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}i:1;a:4:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:7:\"选项2\";s:5:\"image\";N;s:8:\"isSelect\";i:0;}i:2;a:4:{s:5:\"alias\";s:1:\"C\";s:6:\"answer\";s:7:\"选项3\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}i:3;a:4:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:7:\"选项4\";s:5:\"image\";N;s:8:\"isSelect\";i:0;}}s:6:\"answer\";a:2:{i:0;a:4:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:7:\"选项1\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}i:1;a:4:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:7:\"选项2\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}}s:10:\"answer_key\";s:3:\"0,1\";s:13:\"answer_letter\";a:2:{i:0;s:1:\"A\";i:1;s:1:\"B\";}s:11:\"option_type\";i:2;s:8:\"analysis\";s:16:\"1010101111111111\";s:5:\"score\";s:2:\"10\";s:10:\"list_order\";i:1000;s:11:\"create_time\";i:1728962181;s:11:\"update_time\";i:1729561798;s:16:\"option_type_name\";s:6:\"多选\";s:10:\"is_correct\";b:0;}i:2;a:15:{s:2:\"id\";i:11;s:3:\"pid\";i:6;s:4:\"name\";s:14:\"第二部分02\";s:6:\"option\";a:4:{i:0;a:4:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:1:\"a\";s:5:\"image\";N;s:8:\"isSelect\";i:0;}i:1;a:4:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:1:\"b\";s:5:\"image\";N;s:8:\"isSelect\";i:0;}i:2;a:4:{s:5:\"alias\";s:1:\"C\";s:6:\"answer\";s:1:\"c\";s:5:\"image\";N;s:8:\"isSelect\";i:0;}i:3;a:4:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:1:\"d\";s:5:\"image\";N;s:8:\"isSelect\";i:0;}}s:6:\"answer\";a:2:{i:0;a:4:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:1:\"b\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}i:1;a:4:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:1:\"d\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}}s:10:\"answer_key\";s:3:\"1,3\";s:13:\"answer_letter\";a:2:{i:0;s:1:\"B\";i:1;s:1:\"D\";}s:11:\"option_type\";i:2;s:8:\"analysis\";s:8:\"10101010\";s:5:\"score\";s:2:\"10\";s:10:\"list_order\";i:1000;s:11:\"create_time\";i:1728374211;s:11:\"update_time\";i:1729561787;s:16:\"option_type_name\";s:6:\"多选\";s:10:\"is_correct\";b:0;}}","0","79","0","3","1729561865","","0");
INSERT INTO cmf_answer_result VALUES("31","3","6","第二部分：核技术利用辐射安全法律法规","a:3:{i:0;a:2:{s:2:\"id\";s:2:\"10\";s:6:\"answer\";s:1:\"B\";}i:1;a:2:{s:2:\"id\";s:2:\"11\";s:6:\"answer\";a:2:{i:0;s:1:\"A\";i:1;s:1:\"B\";}}i:2;a:2:{s:2:\"id\";s:2:\"68\";s:6:\"answer\";a:1:{i:0;s:1:\"A\";}}}","a:3:{i:0;a:15:{s:2:\"id\";i:10;s:3:\"pid\";i:6;s:4:\"name\";s:14:\"第二部分01\";s:6:\"option\";a:2:{i:0;a:4:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:1:\"a\";s:5:\"image\";N;s:8:\"isSelect\";i:0;}i:1;a:4:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:1:\"b\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}}s:6:\"answer\";a:1:{i:0;a:4:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:1:\"b\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}}s:10:\"answer_key\";s:1:\"1\";s:13:\"answer_letter\";a:1:{i:0;s:1:\"B\";}s:11:\"option_type\";i:1;s:8:\"analysis\";s:59:\"11111111111111111111111111111111111222222222222222222222222\";s:5:\"score\";s:2:\"10\";s:10:\"list_order\";i:1000;s:11:\"create_time\";i:1728374193;s:11:\"update_time\";i:1729561775;s:16:\"option_type_name\";s:6:\"单选\";s:10:\"is_correct\";b:1;}i:1;a:15:{s:2:\"id\";i:11;s:3:\"pid\";i:6;s:4:\"name\";s:14:\"第二部分02\";s:6:\"option\";a:4:{i:0;a:4:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:1:\"a\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}i:1;a:4:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:1:\"b\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}i:2;a:4:{s:5:\"alias\";s:1:\"C\";s:6:\"answer\";s:1:\"c\";s:5:\"image\";N;s:8:\"isSelect\";i:0;}i:3;a:4:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:1:\"d\";s:5:\"image\";N;s:8:\"isSelect\";i:0;}}s:6:\"answer\";a:2:{i:0;a:4:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:1:\"b\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}i:1;a:4:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:1:\"d\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}}s:10:\"answer_key\";s:3:\"1,3\";s:13:\"answer_letter\";a:2:{i:0;s:1:\"B\";i:1;s:1:\"D\";}s:11:\"option_type\";i:2;s:8:\"analysis\";s:8:\"10101010\";s:5:\"score\";s:2:\"10\";s:10:\"list_order\";i:1000;s:11:\"create_time\";i:1728374211;s:11:\"update_time\";i:1729561787;s:16:\"option_type_name\";s:6:\"多选\";s:10:\"is_correct\";b:0;}i:2;a:15:{s:2:\"id\";i:68;s:3:\"pid\";i:6;s:4:\"name\";s:6:\"测试\";s:6:\"option\";a:4:{i:0;a:4:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:7:\"选项1\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}i:1;a:4:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:7:\"选项2\";s:5:\"image\";N;s:8:\"isSelect\";i:0;}i:2;a:4:{s:5:\"alias\";s:1:\"C\";s:6:\"answer\";s:7:\"选项3\";s:5:\"image\";N;s:8:\"isSelect\";i:0;}i:3;a:4:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:7:\"选项4\";s:5:\"image\";N;s:8:\"isSelect\";i:0;}}s:6:\"answer\";a:2:{i:0;a:4:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:7:\"选项1\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}i:1;a:4:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:7:\"选项2\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}}s:10:\"answer_key\";s:3:\"0,1\";s:13:\"answer_letter\";a:2:{i:0;s:1:\"A\";i:1;s:1:\"B\";}s:11:\"option_type\";i:2;s:8:\"analysis\";s:16:\"1010101111111111\";s:5:\"score\";s:2:\"10\";s:10:\"list_order\";i:1000;s:11:\"create_time\";i:1728962181;s:11:\"update_time\";i:1729561798;s:16:\"option_type_name\";s:6:\"多选\";s:10:\"is_correct\";b:0;}}","10","80","1","2","1729561921","","0");
INSERT INTO cmf_answer_result VALUES("32","2","7","第三部分：专业实务","a:2:{i:0;a:2:{s:2:\"id\";s:2:\"12\";s:6:\"answer\";s:1:\"A\";}i:1;a:2:{s:2:\"id\";s:2:\"13\";s:6:\"answer\";a:2:{i:0;s:1:\"A\";i:1;s:1:\"B\";}}}","a:2:{i:0;a:15:{s:2:\"id\";i:12;s:3:\"pid\";i:7;s:4:\"name\";s:14:\"第三部分01\";s:6:\"option\";a:2:{i:0;a:4:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:1:\"a\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}i:1;a:4:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:1:\"b\";s:5:\"image\";N;s:8:\"isSelect\";i:0;}}s:6:\"answer\";a:1:{i:0;a:4:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:1:\"a\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}}s:10:\"answer_key\";s:1:\"0\";s:13:\"answer_letter\";a:1:{i:0;s:1:\"A\";}s:11:\"option_type\";i:1;s:8:\"analysis\";N;s:5:\"score\";s:1:\"8\";s:10:\"list_order\";i:1000;s:11:\"create_time\";i:1728374239;s:11:\"update_time\";N;s:16:\"option_type_name\";s:6:\"单选\";s:10:\"is_correct\";b:1;}i:1;a:15:{s:2:\"id\";i:13;s:3:\"pid\";i:7;s:4:\"name\";s:14:\"第三部分02\";s:6:\"option\";a:4:{i:0;a:4:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:1:\"a\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}i:1;a:4:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:1:\"b\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}i:2;a:4:{s:5:\"alias\";s:1:\"C\";s:6:\"answer\";s:1:\"c\";s:5:\"image\";N;s:8:\"isSelect\";i:0;}i:3;a:4:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:1:\"d\";s:5:\"image\";N;s:8:\"isSelect\";i:0;}}s:6:\"answer\";a:2:{i:0;a:4:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:1:\"a\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}i:1;a:4:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:1:\"d\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}}s:10:\"answer_key\";s:3:\"0,3\";s:13:\"answer_letter\";a:2:{i:0;s:1:\"A\";i:1;s:1:\"D\";}s:11:\"option_type\";i:2;s:8:\"analysis\";N;s:5:\"score\";s:1:\"5\";s:10:\"list_order\";i:1000;s:11:\"create_time\";i:1728374259;s:11:\"update_time\";N;s:16:\"option_type_name\";s:6:\"多选\";s:10:\"is_correct\";b:0;}}","8","119","1","1","1729579027","","0");
INSERT INTO cmf_answer_result VALUES("33","2","7","第三部分：专业实务","a:2:{i:0;a:2:{s:2:\"id\";s:2:\"12\";s:6:\"answer\";s:1:\"A\";}i:1;a:2:{s:2:\"id\";s:2:\"13\";s:6:\"answer\";a:2:{i:0;s:1:\"A\";i:1;s:1:\"B\";}}}","a:2:{i:0;a:15:{s:2:\"id\";i:12;s:3:\"pid\";i:7;s:4:\"name\";s:14:\"第三部分01\";s:6:\"option\";a:2:{i:0;a:4:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:1:\"a\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}i:1;a:4:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:1:\"b\";s:5:\"image\";N;s:8:\"isSelect\";i:0;}}s:6:\"answer\";a:1:{i:0;a:4:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:1:\"a\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}}s:10:\"answer_key\";s:1:\"0\";s:13:\"answer_letter\";a:1:{i:0;s:1:\"A\";}s:11:\"option_type\";i:1;s:8:\"analysis\";N;s:5:\"score\";s:1:\"8\";s:10:\"list_order\";i:1000;s:11:\"create_time\";i:1728374239;s:11:\"update_time\";N;s:16:\"option_type_name\";s:6:\"单选\";s:10:\"is_correct\";b:1;}i:1;a:15:{s:2:\"id\";i:13;s:3:\"pid\";i:7;s:4:\"name\";s:14:\"第三部分02\";s:6:\"option\";a:4:{i:0;a:4:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:1:\"a\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}i:1;a:4:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:1:\"b\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}i:2;a:4:{s:5:\"alias\";s:1:\"C\";s:6:\"answer\";s:1:\"c\";s:5:\"image\";N;s:8:\"isSelect\";i:0;}i:3;a:4:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:1:\"d\";s:5:\"image\";N;s:8:\"isSelect\";i:0;}}s:6:\"answer\";a:2:{i:0;a:4:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:1:\"a\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}i:1;a:4:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:1:\"d\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}}s:10:\"answer_key\";s:3:\"0,3\";s:13:\"answer_letter\";a:2:{i:0;s:1:\"A\";i:1;s:1:\"D\";}s:11:\"option_type\";i:2;s:8:\"analysis\";N;s:5:\"score\";s:1:\"5\";s:10:\"list_order\";i:1000;s:11:\"create_time\";i:1728374259;s:11:\"update_time\";N;s:16:\"option_type_name\";s:6:\"多选\";s:10:\"is_correct\";b:0;}}","8","119","1","1","1729579163","","0");
INSERT INTO cmf_answer_result VALUES("34","2","7","第三部分：专业实务","a:2:{i:0;a:2:{s:2:\"id\";s:2:\"12\";s:6:\"answer\";s:1:\"A\";}i:1;a:2:{s:2:\"id\";s:2:\"13\";s:6:\"answer\";a:2:{i:0;s:1:\"A\";i:1;s:1:\"B\";}}}","a:2:{i:0;a:15:{s:2:\"id\";i:12;s:3:\"pid\";i:7;s:4:\"name\";s:14:\"第三部分01\";s:6:\"option\";a:2:{i:0;a:4:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:1:\"a\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}i:1;a:4:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:1:\"b\";s:5:\"image\";N;s:8:\"isSelect\";i:0;}}s:6:\"answer\";a:1:{i:0;a:4:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:1:\"a\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}}s:10:\"answer_key\";s:1:\"0\";s:13:\"answer_letter\";a:1:{i:0;s:1:\"A\";}s:11:\"option_type\";i:1;s:8:\"analysis\";N;s:5:\"score\";s:1:\"8\";s:10:\"list_order\";i:1000;s:11:\"create_time\";i:1728374239;s:11:\"update_time\";N;s:16:\"option_type_name\";s:6:\"单选\";s:10:\"is_correct\";b:1;}i:1;a:15:{s:2:\"id\";i:13;s:3:\"pid\";i:7;s:4:\"name\";s:14:\"第三部分02\";s:6:\"option\";a:4:{i:0;a:4:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:1:\"a\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}i:1;a:4:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:1:\"b\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}i:2;a:4:{s:5:\"alias\";s:1:\"C\";s:6:\"answer\";s:1:\"c\";s:5:\"image\";N;s:8:\"isSelect\";i:0;}i:3;a:4:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:1:\"d\";s:5:\"image\";N;s:8:\"isSelect\";i:0;}}s:6:\"answer\";a:2:{i:0;a:4:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:1:\"a\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}i:1;a:4:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:1:\"d\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}}s:10:\"answer_key\";s:3:\"0,3\";s:13:\"answer_letter\";a:2:{i:0;s:1:\"A\";i:1;s:1:\"D\";}s:11:\"option_type\";i:2;s:8:\"analysis\";N;s:5:\"score\";s:1:\"5\";s:10:\"list_order\";i:1000;s:11:\"create_time\";i:1728374259;s:11:\"update_time\";N;s:16:\"option_type_name\";s:6:\"多选\";s:10:\"is_correct\";b:0;}}","8","120","1","1","1729580215","","0");
INSERT INTO cmf_answer_result VALUES("35","3","6","第二部分：核技术利用辐射安全法律法规","a:3:{i:0;a:2:{s:2:\"id\";s:2:\"10\";s:6:\"answer\";a:2:{i:0;s:1:\"C\";i:1;s:1:\"A\";}}i:1;a:1:{s:2:\"id\";s:2:\"11\";}i:2;a:1:{s:2:\"id\";s:2:\"68\";}}","a:3:{i:0;a:15:{s:2:\"id\";i:10;s:3:\"pid\";i:6;s:4:\"name\";s:14:\"第二部分01\";s:6:\"option\";a:2:{i:0;a:4:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:1:\"a\";s:5:\"image\";N;s:8:\"isSelect\";i:0;}i:1;a:4:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:1:\"b\";s:5:\"image\";N;s:8:\"isSelect\";i:0;}}s:6:\"answer\";a:1:{i:0;a:4:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:1:\"b\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}}s:10:\"answer_key\";s:1:\"1\";s:13:\"answer_letter\";a:1:{i:0;s:1:\"B\";}s:11:\"option_type\";i:1;s:8:\"analysis\";s:59:\"11111111111111111111111111111111111222222222222222222222222\";s:5:\"score\";s:2:\"10\";s:10:\"list_order\";i:1000;s:11:\"create_time\";i:1728374193;s:11:\"update_time\";i:1729561775;s:16:\"option_type_name\";s:6:\"单选\";s:10:\"is_correct\";b:0;}i:1;a:15:{s:2:\"id\";i:11;s:3:\"pid\";i:6;s:4:\"name\";s:14:\"第二部分02\";s:6:\"option\";a:4:{i:0;a:4:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:1:\"a\";s:5:\"image\";N;s:8:\"isSelect\";i:0;}i:1;a:4:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:1:\"b\";s:5:\"image\";N;s:8:\"isSelect\";i:0;}i:2;a:4:{s:5:\"alias\";s:1:\"C\";s:6:\"answer\";s:1:\"c\";s:5:\"image\";N;s:8:\"isSelect\";i:0;}i:3;a:4:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:1:\"d\";s:5:\"image\";N;s:8:\"isSelect\";i:0;}}s:6:\"answer\";a:2:{i:0;a:4:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:1:\"b\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}i:1;a:4:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:1:\"d\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}}s:10:\"answer_key\";s:3:\"1,3\";s:13:\"answer_letter\";a:2:{i:0;s:1:\"B\";i:1;s:1:\"D\";}s:11:\"option_type\";i:2;s:8:\"analysis\";s:8:\"10101010\";s:5:\"score\";s:2:\"10\";s:10:\"list_order\";i:1000;s:11:\"create_time\";i:1728374211;s:11:\"update_time\";i:1729561787;s:16:\"option_type_name\";s:6:\"多选\";s:10:\"is_correct\";b:0;}i:2;a:15:{s:2:\"id\";i:68;s:3:\"pid\";i:6;s:4:\"name\";s:6:\"测试\";s:6:\"option\";a:4:{i:0;a:4:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:7:\"选项1\";s:5:\"image\";N;s:8:\"isSelect\";i:0;}i:1;a:4:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:7:\"选项2\";s:5:\"image\";N;s:8:\"isSelect\";i:0;}i:2;a:4:{s:5:\"alias\";s:1:\"C\";s:6:\"answer\";s:7:\"选项3\";s:5:\"image\";N;s:8:\"isSelect\";i:0;}i:3;a:4:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:7:\"选项4\";s:5:\"image\";N;s:8:\"isSelect\";i:0;}}s:6:\"answer\";a:2:{i:0;a:4:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:7:\"选项1\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}i:1;a:4:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:7:\"选项2\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}}s:10:\"answer_key\";s:3:\"0,1\";s:13:\"answer_letter\";a:2:{i:0;s:1:\"A\";i:1;s:1:\"B\";}s:11:\"option_type\";i:2;s:8:\"analysis\";s:16:\"1010101111111111\";s:5:\"score\";s:2:\"10\";s:10:\"list_order\";i:1000;s:11:\"create_time\";i:1728962181;s:11:\"update_time\";i:1729561798;s:16:\"option_type_name\";s:6:\"多选\";s:10:\"is_correct\";b:0;}}","0","5","0","3","1729740189","","0");
INSERT INTO cmf_answer_result VALUES("36","3","7","第三部分：专业实务","a:2:{i:0;a:2:{s:2:\"id\";s:2:\"12\";s:6:\"answer\";s:1:\"A\";}i:1;a:2:{s:2:\"id\";s:2:\"13\";s:6:\"answer\";a:1:{i:0;s:1:\"A\";}}}","a:2:{i:0;a:15:{s:2:\"id\";i:12;s:3:\"pid\";i:7;s:4:\"name\";s:14:\"第三部分01\";s:6:\"option\";a:2:{i:0;a:4:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:1:\"a\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}i:1;a:4:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:1:\"b\";s:5:\"image\";N;s:8:\"isSelect\";i:0;}}s:6:\"answer\";a:1:{i:0;a:4:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:1:\"a\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}}s:10:\"answer_key\";s:1:\"0\";s:13:\"answer_letter\";a:1:{i:0;s:1:\"A\";}s:11:\"option_type\";i:1;s:8:\"analysis\";N;s:5:\"score\";s:1:\"8\";s:10:\"list_order\";i:1000;s:11:\"create_time\";i:1728374239;s:11:\"update_time\";N;s:16:\"option_type_name\";s:6:\"单选\";s:10:\"is_correct\";b:1;}i:1;a:15:{s:2:\"id\";i:13;s:3:\"pid\";i:7;s:4:\"name\";s:14:\"第三部分02\";s:6:\"option\";a:4:{i:0;a:4:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:1:\"a\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}i:1;a:4:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:1:\"b\";s:5:\"image\";N;s:8:\"isSelect\";i:0;}i:2;a:4:{s:5:\"alias\";s:1:\"C\";s:6:\"answer\";s:1:\"c\";s:5:\"image\";N;s:8:\"isSelect\";i:0;}i:3;a:4:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:1:\"d\";s:5:\"image\";N;s:8:\"isSelect\";i:0;}}s:6:\"answer\";a:2:{i:0;a:4:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:1:\"a\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}i:1;a:4:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:1:\"d\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}}s:10:\"answer_key\";s:3:\"0,3\";s:13:\"answer_letter\";a:2:{i:0;s:1:\"A\";i:1;s:1:\"D\";}s:11:\"option_type\";i:2;s:8:\"analysis\";N;s:5:\"score\";s:1:\"5\";s:10:\"list_order\";i:1000;s:11:\"create_time\";i:1728374259;s:11:\"update_time\";N;s:16:\"option_type_name\";s:6:\"多选\";s:10:\"is_correct\";b:0;}}","8","10","1","1","1729740866","","0");
INSERT INTO cmf_answer_result VALUES("37","3","7","第三部分：专业实务","a:2:{i:0;a:2:{s:2:\"id\";s:2:\"12\";s:6:\"answer\";s:1:\"B\";}i:1;a:2:{s:2:\"id\";s:2:\"13\";s:6:\"answer\";a:1:{i:0;s:1:\"A\";}}}","a:2:{i:0;a:15:{s:2:\"id\";i:12;s:3:\"pid\";i:7;s:4:\"name\";s:14:\"第三部分01\";s:6:\"option\";a:2:{i:0;a:4:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:1:\"a\";s:5:\"image\";N;s:8:\"isSelect\";i:0;}i:1;a:4:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:1:\"b\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}}s:6:\"answer\";a:1:{i:0;a:4:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:1:\"a\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}}s:10:\"answer_key\";s:1:\"0\";s:13:\"answer_letter\";a:1:{i:0;s:1:\"A\";}s:11:\"option_type\";i:1;s:8:\"analysis\";N;s:5:\"score\";s:1:\"8\";s:10:\"list_order\";i:1000;s:11:\"create_time\";i:1728374239;s:11:\"update_time\";N;s:16:\"option_type_name\";s:6:\"单选\";s:10:\"is_correct\";b:0;}i:1;a:15:{s:2:\"id\";i:13;s:3:\"pid\";i:7;s:4:\"name\";s:14:\"第三部分02\";s:6:\"option\";a:4:{i:0;a:4:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:1:\"a\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}i:1;a:4:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:1:\"b\";s:5:\"image\";N;s:8:\"isSelect\";i:0;}i:2;a:4:{s:5:\"alias\";s:1:\"C\";s:6:\"answer\";s:1:\"c\";s:5:\"image\";N;s:8:\"isSelect\";i:0;}i:3;a:4:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:1:\"d\";s:5:\"image\";N;s:8:\"isSelect\";i:0;}}s:6:\"answer\";a:2:{i:0;a:4:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:1:\"a\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}i:1;a:4:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:1:\"d\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}}s:10:\"answer_key\";s:3:\"0,3\";s:13:\"answer_letter\";a:2:{i:0;s:1:\"A\";i:1;s:1:\"D\";}s:11:\"option_type\";i:2;s:8:\"analysis\";N;s:5:\"score\";s:1:\"5\";s:10:\"list_order\";i:1000;s:11:\"create_time\";i:1728374259;s:11:\"update_time\";N;s:16:\"option_type_name\";s:6:\"多选\";s:10:\"is_correct\";b:0;}}","0","600","0","2","1729740936","","0");



DROP TABLE cmf_answer_title;

CREATE TABLE `cmf_answer_title` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) DEFAULT NULL COMMENT '题类型',
  `name` varchar(255) DEFAULT NULL COMMENT '名称',
  `total_score` varchar(255) DEFAULT NULL COMMENT '总分',
  `pass_score` varchar(255) DEFAULT NULL COMMENT '及格分',
  `minute` varchar(255) DEFAULT NULL COMMENT '答题分钟数',
  `number` varchar(255) DEFAULT NULL COMMENT '题数量',
  `is_all` tinyint(4) DEFAULT '2' COMMENT '汇总:1是,2否',
  `is_random` tinyint(4) DEFAULT '2' COMMENT '乱序:1是,2否',
  `list_order` int(11) DEFAULT '1000',
  `create_time` bigint(20) DEFAULT NULL COMMENT '创建时间',
  `update_time` bigint(20) DEFAULT NULL COMMENT '更新时间',
  `delete_time` bigint(20) DEFAULT '0' COMMENT '删除时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COMMENT='标题管理';

INSERT INTO cmf_answer_title VALUES("1","","Ⅲ类试题","","","","","2","2","1000","1728034031","","0");
INSERT INTO cmf_answer_title VALUES("2","","Ⅱ类试题","","","","","2","2","1000","1728034038","","0");
INSERT INTO cmf_answer_title VALUES("3","2","医用类试题","100","60","100","","2","2","1000","1728034631","1728373052","0");
INSERT INTO cmf_answer_title VALUES("4","2","非医用类试题","120","60","120","","2","2","1000","1728034640","1728373042","0");
INSERT INTO cmf_answer_title VALUES("5","5","第一部分：电离辐射安全与防护基础","120","70","120","","2","1","100","1728374038","1728379399","0");
INSERT INTO cmf_answer_title VALUES("6","5","第二部分：核技术利用辐射安全法律法规","30","10","10","","2","1","200","1728374061","1729561739","0");
INSERT INTO cmf_answer_title VALUES("7","5","第三部分：专业实务","13","5","10","","2","1","300","1728374073","1729740913","0");
INSERT INTO cmf_answer_title VALUES("8","5","综合性测试题","100","80","120","","1","2","400","1728374092","1728380702","0");
INSERT INTO cmf_answer_title VALUES("9","8","第一部分：电离辐射安全与防护基础","120","60","80","","2","2","1000","1729220239","","0");



DROP TABLE cmf_answer_wrong;

CREATE TABLE `cmf_answer_wrong` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `answer_id` int(11) DEFAULT NULL COMMENT '一级',
  `class_id` int(11) DEFAULT NULL COMMENT '二级',
  `exam_id` int(11) DEFAULT NULL COMMENT '题库,三级',
  `name` varchar(255) DEFAULT NULL COMMENT '名称',
  `question` text COMMENT '题目列表',
  `create_time` bigint(20) DEFAULT NULL COMMENT '创建时间',
  `update_time` bigint(20) DEFAULT NULL COMMENT '更新时间',
  `delete_time` bigint(20) DEFAULT '0' COMMENT '删除时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=77 DEFAULT CHARSET=utf8mb4 COMMENT='错题记录';

INSERT INTO cmf_answer_wrong VALUES("59","2","2","5","6","第二部分：核技术利用辐射安全法律法规","a:15:{s:2:\"id\";i:10;s:3:\"pid\";i:6;s:4:\"name\";s:14:\"第二部分01\";s:6:\"option\";a:2:{i:0;a:4:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:1:\"a\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}i:1;a:4:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:1:\"b\";s:5:\"image\";N;s:8:\"isSelect\";i:0;}}s:6:\"answer\";a:1:{i:0;a:4:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:1:\"b\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}}s:10:\"answer_key\";s:1:\"1\";s:13:\"answer_letter\";a:1:{i:0;s:1:\"B\";}s:11:\"option_type\";i:1;s:8:\"analysis\";N;s:5:\"score\";s:1:\"1\";s:10:\"list_order\";i:1000;s:11:\"create_time\";i:1728374193;s:11:\"update_time\";N;s:16:\"option_type_name\";s:6:\"单选\";s:10:\"is_correct\";b:0;}","1729222098","","0");
INSERT INTO cmf_answer_wrong VALUES("60","2","2","5","6","第二部分：核技术利用辐射安全法律法规","a:15:{s:2:\"id\";i:11;s:3:\"pid\";i:6;s:4:\"name\";s:14:\"第二部分02\";s:6:\"option\";a:4:{i:0;a:4:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:1:\"a\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}i:1;a:4:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:1:\"b\";s:5:\"image\";N;s:8:\"isSelect\";i:0;}i:2;a:4:{s:5:\"alias\";s:1:\"C\";s:6:\"answer\";s:1:\"c\";s:5:\"image\";N;s:8:\"isSelect\";i:0;}i:3;a:4:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:1:\"d\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}}s:6:\"answer\";a:2:{i:0;a:4:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:1:\"b\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}i:1;a:4:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:1:\"d\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}}s:10:\"answer_key\";s:3:\"1,3\";s:13:\"answer_letter\";a:2:{i:0;s:1:\"B\";i:1;s:1:\"D\";}s:11:\"option_type\";i:2;s:8:\"analysis\";N;s:5:\"score\";s:1:\"5\";s:10:\"list_order\";i:1000;s:11:\"create_time\";i:1728374211;s:11:\"update_time\";N;s:16:\"option_type_name\";s:6:\"多选\";s:10:\"is_correct\";b:0;}","1729222098","","0");
INSERT INTO cmf_answer_wrong VALUES("61","2","2","5","6","第二部分：核技术利用辐射安全法律法规","a:15:{s:2:\"id\";i:11;s:3:\"pid\";i:6;s:4:\"name\";s:14:\"第二部分02\";s:6:\"option\";a:4:{i:0;a:4:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:1:\"a\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}i:1;a:4:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:1:\"b\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}i:2;a:4:{s:5:\"alias\";s:1:\"C\";s:6:\"answer\";s:1:\"c\";s:5:\"image\";N;s:8:\"isSelect\";i:0;}i:3;a:4:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:1:\"d\";s:5:\"image\";N;s:8:\"isSelect\";i:0;}}s:6:\"answer\";a:2:{i:0;a:4:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:1:\"b\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}i:1;a:4:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:1:\"d\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}}s:10:\"answer_key\";s:3:\"1,3\";s:13:\"answer_letter\";a:2:{i:0;s:1:\"B\";i:1;s:1:\"D\";}s:11:\"option_type\";i:2;s:8:\"analysis\";N;s:5:\"score\";s:1:\"5\";s:10:\"list_order\";i:1000;s:11:\"create_time\";i:1728374211;s:11:\"update_time\";N;s:16:\"option_type_name\";s:6:\"多选\";s:10:\"is_correct\";b:0;}","1729302237","","0");
INSERT INTO cmf_answer_wrong VALUES("62","3","2","5","7","第三部分：专业实务","a:15:{s:2:\"id\";i:13;s:3:\"pid\";i:7;s:4:\"name\";s:14:\"第三部分02\";s:6:\"option\";a:4:{i:0;a:4:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:1:\"a\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}i:1;a:4:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:1:\"b\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}i:2;a:4:{s:5:\"alias\";s:1:\"C\";s:6:\"answer\";s:1:\"c\";s:5:\"image\";N;s:8:\"isSelect\";i:0;}i:3;a:4:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:1:\"d\";s:5:\"image\";N;s:8:\"isSelect\";i:0;}}s:6:\"answer\";a:2:{i:0;a:4:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:1:\"a\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}i:1;a:4:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:1:\"d\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}}s:10:\"answer_key\";s:3:\"0,3\";s:13:\"answer_letter\";a:2:{i:0;s:1:\"A\";i:1;s:1:\"D\";}s:11:\"option_type\";i:2;s:8:\"analysis\";N;s:5:\"score\";s:1:\"5\";s:10:\"list_order\";i:1000;s:11:\"create_time\";i:1728374259;s:11:\"update_time\";N;s:16:\"option_type_name\";s:6:\"多选\";s:10:\"is_correct\";b:0;}","1729560072","","0");
INSERT INTO cmf_answer_wrong VALUES("63","3","2","5","6","第二部分：核技术利用辐射安全法律法规","a:15:{s:2:\"id\";i:10;s:3:\"pid\";i:6;s:4:\"name\";s:14:\"第二部分01\";s:6:\"option\";a:2:{i:0;a:4:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:1:\"a\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}i:1;a:4:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:1:\"b\";s:5:\"image\";N;s:8:\"isSelect\";i:0;}}s:6:\"answer\";a:1:{i:0;a:4:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:1:\"b\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}}s:10:\"answer_key\";s:1:\"1\";s:13:\"answer_letter\";a:1:{i:0;s:1:\"B\";}s:11:\"option_type\";i:1;s:8:\"analysis\";s:59:\"11111111111111111111111111111111111222222222222222222222222\";s:5:\"score\";s:2:\"10\";s:10:\"list_order\";i:1000;s:11:\"create_time\";i:1728374193;s:11:\"update_time\";i:1729561775;s:16:\"option_type_name\";s:6:\"单选\";s:10:\"is_correct\";b:0;}","1729561865","","0");
INSERT INTO cmf_answer_wrong VALUES("64","3","2","5","6","第二部分：核技术利用辐射安全法律法规","a:15:{s:2:\"id\";i:68;s:3:\"pid\";i:6;s:4:\"name\";s:6:\"测试\";s:6:\"option\";a:4:{i:0;a:4:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:7:\"选项1\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}i:1;a:4:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:7:\"选项2\";s:5:\"image\";N;s:8:\"isSelect\";i:0;}i:2;a:4:{s:5:\"alias\";s:1:\"C\";s:6:\"answer\";s:7:\"选项3\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}i:3;a:4:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:7:\"选项4\";s:5:\"image\";N;s:8:\"isSelect\";i:0;}}s:6:\"answer\";a:2:{i:0;a:4:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:7:\"选项1\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}i:1;a:4:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:7:\"选项2\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}}s:10:\"answer_key\";s:3:\"0,1\";s:13:\"answer_letter\";a:2:{i:0;s:1:\"A\";i:1;s:1:\"B\";}s:11:\"option_type\";i:2;s:8:\"analysis\";s:16:\"1010101111111111\";s:5:\"score\";s:2:\"10\";s:10:\"list_order\";i:1000;s:11:\"create_time\";i:1728962181;s:11:\"update_time\";i:1729561798;s:16:\"option_type_name\";s:6:\"多选\";s:10:\"is_correct\";b:0;}","1729561865","","0");
INSERT INTO cmf_answer_wrong VALUES("65","3","2","5","6","第二部分：核技术利用辐射安全法律法规","a:15:{s:2:\"id\";i:11;s:3:\"pid\";i:6;s:4:\"name\";s:14:\"第二部分02\";s:6:\"option\";a:4:{i:0;a:4:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:1:\"a\";s:5:\"image\";N;s:8:\"isSelect\";i:0;}i:1;a:4:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:1:\"b\";s:5:\"image\";N;s:8:\"isSelect\";i:0;}i:2;a:4:{s:5:\"alias\";s:1:\"C\";s:6:\"answer\";s:1:\"c\";s:5:\"image\";N;s:8:\"isSelect\";i:0;}i:3;a:4:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:1:\"d\";s:5:\"image\";N;s:8:\"isSelect\";i:0;}}s:6:\"answer\";a:2:{i:0;a:4:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:1:\"b\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}i:1;a:4:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:1:\"d\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}}s:10:\"answer_key\";s:3:\"1,3\";s:13:\"answer_letter\";a:2:{i:0;s:1:\"B\";i:1;s:1:\"D\";}s:11:\"option_type\";i:2;s:8:\"analysis\";s:8:\"10101010\";s:5:\"score\";s:2:\"10\";s:10:\"list_order\";i:1000;s:11:\"create_time\";i:1728374211;s:11:\"update_time\";i:1729561787;s:16:\"option_type_name\";s:6:\"多选\";s:10:\"is_correct\";b:0;}","1729561865","","0");
INSERT INTO cmf_answer_wrong VALUES("66","3","2","5","6","第二部分：核技术利用辐射安全法律法规","a:15:{s:2:\"id\";i:11;s:3:\"pid\";i:6;s:4:\"name\";s:14:\"第二部分02\";s:6:\"option\";a:4:{i:0;a:4:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:1:\"a\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}i:1;a:4:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:1:\"b\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}i:2;a:4:{s:5:\"alias\";s:1:\"C\";s:6:\"answer\";s:1:\"c\";s:5:\"image\";N;s:8:\"isSelect\";i:0;}i:3;a:4:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:1:\"d\";s:5:\"image\";N;s:8:\"isSelect\";i:0;}}s:6:\"answer\";a:2:{i:0;a:4:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:1:\"b\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}i:1;a:4:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:1:\"d\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}}s:10:\"answer_key\";s:3:\"1,3\";s:13:\"answer_letter\";a:2:{i:0;s:1:\"B\";i:1;s:1:\"D\";}s:11:\"option_type\";i:2;s:8:\"analysis\";s:8:\"10101010\";s:5:\"score\";s:2:\"10\";s:10:\"list_order\";i:1000;s:11:\"create_time\";i:1728374211;s:11:\"update_time\";i:1729561787;s:16:\"option_type_name\";s:6:\"多选\";s:10:\"is_correct\";b:0;}","1729561921","","0");
INSERT INTO cmf_answer_wrong VALUES("67","3","2","5","6","第二部分：核技术利用辐射安全法律法规","a:15:{s:2:\"id\";i:68;s:3:\"pid\";i:6;s:4:\"name\";s:6:\"测试\";s:6:\"option\";a:4:{i:0;a:4:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:7:\"选项1\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}i:1;a:4:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:7:\"选项2\";s:5:\"image\";N;s:8:\"isSelect\";i:0;}i:2;a:4:{s:5:\"alias\";s:1:\"C\";s:6:\"answer\";s:7:\"选项3\";s:5:\"image\";N;s:8:\"isSelect\";i:0;}i:3;a:4:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:7:\"选项4\";s:5:\"image\";N;s:8:\"isSelect\";i:0;}}s:6:\"answer\";a:2:{i:0;a:4:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:7:\"选项1\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}i:1;a:4:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:7:\"选项2\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}}s:10:\"answer_key\";s:3:\"0,1\";s:13:\"answer_letter\";a:2:{i:0;s:1:\"A\";i:1;s:1:\"B\";}s:11:\"option_type\";i:2;s:8:\"analysis\";s:16:\"1010101111111111\";s:5:\"score\";s:2:\"10\";s:10:\"list_order\";i:1000;s:11:\"create_time\";i:1728962181;s:11:\"update_time\";i:1729561798;s:16:\"option_type_name\";s:6:\"多选\";s:10:\"is_correct\";b:0;}","1729561921","","0");
INSERT INTO cmf_answer_wrong VALUES("68","2","2","5","7","第三部分：专业实务","a:15:{s:2:\"id\";i:13;s:3:\"pid\";i:7;s:4:\"name\";s:14:\"第三部分02\";s:6:\"option\";a:4:{i:0;a:4:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:1:\"a\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}i:1;a:4:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:1:\"b\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}i:2;a:4:{s:5:\"alias\";s:1:\"C\";s:6:\"answer\";s:1:\"c\";s:5:\"image\";N;s:8:\"isSelect\";i:0;}i:3;a:4:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:1:\"d\";s:5:\"image\";N;s:8:\"isSelect\";i:0;}}s:6:\"answer\";a:2:{i:0;a:4:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:1:\"a\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}i:1;a:4:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:1:\"d\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}}s:10:\"answer_key\";s:3:\"0,3\";s:13:\"answer_letter\";a:2:{i:0;s:1:\"A\";i:1;s:1:\"D\";}s:11:\"option_type\";i:2;s:8:\"analysis\";N;s:5:\"score\";s:1:\"5\";s:10:\"list_order\";i:1000;s:11:\"create_time\";i:1728374259;s:11:\"update_time\";N;s:16:\"option_type_name\";s:6:\"多选\";s:10:\"is_correct\";b:0;}","1729579027","","0");
INSERT INTO cmf_answer_wrong VALUES("69","2","2","5","7","第三部分：专业实务","a:15:{s:2:\"id\";i:13;s:3:\"pid\";i:7;s:4:\"name\";s:14:\"第三部分02\";s:6:\"option\";a:4:{i:0;a:4:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:1:\"a\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}i:1;a:4:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:1:\"b\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}i:2;a:4:{s:5:\"alias\";s:1:\"C\";s:6:\"answer\";s:1:\"c\";s:5:\"image\";N;s:8:\"isSelect\";i:0;}i:3;a:4:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:1:\"d\";s:5:\"image\";N;s:8:\"isSelect\";i:0;}}s:6:\"answer\";a:2:{i:0;a:4:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:1:\"a\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}i:1;a:4:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:1:\"d\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}}s:10:\"answer_key\";s:3:\"0,3\";s:13:\"answer_letter\";a:2:{i:0;s:1:\"A\";i:1;s:1:\"D\";}s:11:\"option_type\";i:2;s:8:\"analysis\";N;s:5:\"score\";s:1:\"5\";s:10:\"list_order\";i:1000;s:11:\"create_time\";i:1728374259;s:11:\"update_time\";N;s:16:\"option_type_name\";s:6:\"多选\";s:10:\"is_correct\";b:0;}","1729579163","","0");
INSERT INTO cmf_answer_wrong VALUES("70","2","2","5","7","第三部分：专业实务","a:15:{s:2:\"id\";i:13;s:3:\"pid\";i:7;s:4:\"name\";s:14:\"第三部分02\";s:6:\"option\";a:4:{i:0;a:4:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:1:\"a\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}i:1;a:4:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:1:\"b\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}i:2;a:4:{s:5:\"alias\";s:1:\"C\";s:6:\"answer\";s:1:\"c\";s:5:\"image\";N;s:8:\"isSelect\";i:0;}i:3;a:4:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:1:\"d\";s:5:\"image\";N;s:8:\"isSelect\";i:0;}}s:6:\"answer\";a:2:{i:0;a:4:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:1:\"a\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}i:1;a:4:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:1:\"d\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}}s:10:\"answer_key\";s:3:\"0,3\";s:13:\"answer_letter\";a:2:{i:0;s:1:\"A\";i:1;s:1:\"D\";}s:11:\"option_type\";i:2;s:8:\"analysis\";N;s:5:\"score\";s:1:\"5\";s:10:\"list_order\";i:1000;s:11:\"create_time\";i:1728374259;s:11:\"update_time\";N;s:16:\"option_type_name\";s:6:\"多选\";s:10:\"is_correct\";b:0;}","1729580215","","0");
INSERT INTO cmf_answer_wrong VALUES("71","3","2","5","6","第二部分：核技术利用辐射安全法律法规","a:15:{s:2:\"id\";i:10;s:3:\"pid\";i:6;s:4:\"name\";s:14:\"第二部分01\";s:6:\"option\";a:2:{i:0;a:4:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:1:\"a\";s:5:\"image\";N;s:8:\"isSelect\";i:0;}i:1;a:4:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:1:\"b\";s:5:\"image\";N;s:8:\"isSelect\";i:0;}}s:6:\"answer\";a:1:{i:0;a:4:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:1:\"b\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}}s:10:\"answer_key\";s:1:\"1\";s:13:\"answer_letter\";a:1:{i:0;s:1:\"B\";}s:11:\"option_type\";i:1;s:8:\"analysis\";s:59:\"11111111111111111111111111111111111222222222222222222222222\";s:5:\"score\";s:2:\"10\";s:10:\"list_order\";i:1000;s:11:\"create_time\";i:1728374193;s:11:\"update_time\";i:1729561775;s:16:\"option_type_name\";s:6:\"单选\";s:10:\"is_correct\";b:0;}","1729740189","","0");
INSERT INTO cmf_answer_wrong VALUES("72","3","2","5","6","第二部分：核技术利用辐射安全法律法规","a:15:{s:2:\"id\";i:11;s:3:\"pid\";i:6;s:4:\"name\";s:14:\"第二部分02\";s:6:\"option\";a:4:{i:0;a:4:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:1:\"a\";s:5:\"image\";N;s:8:\"isSelect\";i:0;}i:1;a:4:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:1:\"b\";s:5:\"image\";N;s:8:\"isSelect\";i:0;}i:2;a:4:{s:5:\"alias\";s:1:\"C\";s:6:\"answer\";s:1:\"c\";s:5:\"image\";N;s:8:\"isSelect\";i:0;}i:3;a:4:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:1:\"d\";s:5:\"image\";N;s:8:\"isSelect\";i:0;}}s:6:\"answer\";a:2:{i:0;a:4:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:1:\"b\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}i:1;a:4:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:1:\"d\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}}s:10:\"answer_key\";s:3:\"1,3\";s:13:\"answer_letter\";a:2:{i:0;s:1:\"B\";i:1;s:1:\"D\";}s:11:\"option_type\";i:2;s:8:\"analysis\";s:8:\"10101010\";s:5:\"score\";s:2:\"10\";s:10:\"list_order\";i:1000;s:11:\"create_time\";i:1728374211;s:11:\"update_time\";i:1729561787;s:16:\"option_type_name\";s:6:\"多选\";s:10:\"is_correct\";b:0;}","1729740189","","0");
INSERT INTO cmf_answer_wrong VALUES("73","3","2","5","6","第二部分：核技术利用辐射安全法律法规","a:15:{s:2:\"id\";i:68;s:3:\"pid\";i:6;s:4:\"name\";s:6:\"测试\";s:6:\"option\";a:4:{i:0;a:4:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:7:\"选项1\";s:5:\"image\";N;s:8:\"isSelect\";i:0;}i:1;a:4:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:7:\"选项2\";s:5:\"image\";N;s:8:\"isSelect\";i:0;}i:2;a:4:{s:5:\"alias\";s:1:\"C\";s:6:\"answer\";s:7:\"选项3\";s:5:\"image\";N;s:8:\"isSelect\";i:0;}i:3;a:4:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:7:\"选项4\";s:5:\"image\";N;s:8:\"isSelect\";i:0;}}s:6:\"answer\";a:2:{i:0;a:4:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:7:\"选项1\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}i:1;a:4:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:7:\"选项2\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}}s:10:\"answer_key\";s:3:\"0,1\";s:13:\"answer_letter\";a:2:{i:0;s:1:\"A\";i:1;s:1:\"B\";}s:11:\"option_type\";i:2;s:8:\"analysis\";s:16:\"1010101111111111\";s:5:\"score\";s:2:\"10\";s:10:\"list_order\";i:1000;s:11:\"create_time\";i:1728962181;s:11:\"update_time\";i:1729561798;s:16:\"option_type_name\";s:6:\"多选\";s:10:\"is_correct\";b:0;}","1729740189","","0");
INSERT INTO cmf_answer_wrong VALUES("74","3","2","5","7","第三部分：专业实务","a:15:{s:2:\"id\";i:13;s:3:\"pid\";i:7;s:4:\"name\";s:14:\"第三部分02\";s:6:\"option\";a:4:{i:0;a:4:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:1:\"a\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}i:1;a:4:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:1:\"b\";s:5:\"image\";N;s:8:\"isSelect\";i:0;}i:2;a:4:{s:5:\"alias\";s:1:\"C\";s:6:\"answer\";s:1:\"c\";s:5:\"image\";N;s:8:\"isSelect\";i:0;}i:3;a:4:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:1:\"d\";s:5:\"image\";N;s:8:\"isSelect\";i:0;}}s:6:\"answer\";a:2:{i:0;a:4:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:1:\"a\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}i:1;a:4:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:1:\"d\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}}s:10:\"answer_key\";s:3:\"0,3\";s:13:\"answer_letter\";a:2:{i:0;s:1:\"A\";i:1;s:1:\"D\";}s:11:\"option_type\";i:2;s:8:\"analysis\";N;s:5:\"score\";s:1:\"5\";s:10:\"list_order\";i:1000;s:11:\"create_time\";i:1728374259;s:11:\"update_time\";N;s:16:\"option_type_name\";s:6:\"多选\";s:10:\"is_correct\";b:0;}","1729740866","","0");
INSERT INTO cmf_answer_wrong VALUES("75","3","2","5","7","第三部分：专业实务","a:15:{s:2:\"id\";i:12;s:3:\"pid\";i:7;s:4:\"name\";s:14:\"第三部分01\";s:6:\"option\";a:2:{i:0;a:4:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:1:\"a\";s:5:\"image\";N;s:8:\"isSelect\";i:0;}i:1;a:4:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:1:\"b\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}}s:6:\"answer\";a:1:{i:0;a:4:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:1:\"a\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}}s:10:\"answer_key\";s:1:\"0\";s:13:\"answer_letter\";a:1:{i:0;s:1:\"A\";}s:11:\"option_type\";i:1;s:8:\"analysis\";N;s:5:\"score\";s:1:\"8\";s:10:\"list_order\";i:1000;s:11:\"create_time\";i:1728374239;s:11:\"update_time\";N;s:16:\"option_type_name\";s:6:\"单选\";s:10:\"is_correct\";b:0;}","1729740936","","0");
INSERT INTO cmf_answer_wrong VALUES("76","3","2","5","7","第三部分：专业实务","a:15:{s:2:\"id\";i:13;s:3:\"pid\";i:7;s:4:\"name\";s:14:\"第三部分02\";s:6:\"option\";a:4:{i:0;a:4:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:1:\"a\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}i:1;a:4:{s:5:\"alias\";s:1:\"B\";s:6:\"answer\";s:1:\"b\";s:5:\"image\";N;s:8:\"isSelect\";i:0;}i:2;a:4:{s:5:\"alias\";s:1:\"C\";s:6:\"answer\";s:1:\"c\";s:5:\"image\";N;s:8:\"isSelect\";i:0;}i:3;a:4:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:1:\"d\";s:5:\"image\";N;s:8:\"isSelect\";i:0;}}s:6:\"answer\";a:2:{i:0;a:4:{s:5:\"alias\";s:1:\"A\";s:6:\"answer\";s:1:\"a\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}i:1;a:4:{s:5:\"alias\";s:1:\"D\";s:6:\"answer\";s:1:\"d\";s:5:\"image\";N;s:8:\"isSelect\";i:1;}}s:10:\"answer_key\";s:3:\"0,3\";s:13:\"answer_letter\";a:2:{i:0;s:1:\"A\";i:1;s:1:\"D\";}s:11:\"option_type\";i:2;s:8:\"analysis\";N;s:5:\"score\";s:1:\"5\";s:10:\"list_order\";i:1000;s:11:\"create_time\";i:1728374259;s:11:\"update_time\";N;s:16:\"option_type_name\";s:6:\"多选\";s:10:\"is_correct\";b:0;}","1729740936","","0");



CREATE TABLE `cmf_asset` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '用户id',
  `file_size` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '文件大小,单位B',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '上传时间',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '状态;1:可用,0:不可用',
  `download_times` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '下载次数',
  `file_key` varchar(64) CHARACTER SET utf8 NOT NULL DEFAULT '' COMMENT '文件惟一码',
  `filename` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '文件名',
  `file_path` varchar(100) NOT NULL DEFAULT '' COMMENT '文件路径,相对于upload目录,可以为url',
  `file_md5` varchar(32) NOT NULL DEFAULT '' COMMENT '文件md5值',
  `file_sha1` varchar(40) NOT NULL DEFAULT '',
  `suffix` varchar(10) NOT NULL DEFAULT '' COMMENT '文件后缀名,不包括点',
  `more` text COMMENT '其它详细信息,JSON格式',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COMMENT='资源表';

DROP TABLE cmf_auth_access;

CREATE TABLE `cmf_auth_access` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `role_id` int(10) unsigned NOT NULL COMMENT '角色',
  `rule_name` varchar(100) NOT NULL DEFAULT '' COMMENT '规则唯一英文标识,全小写',
  `type` varchar(30) NOT NULL DEFAULT '' COMMENT '权限规则分类,请加应用前缀,如admin_',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `role_id` (`role_id`) USING BTREE,
  KEY `rule_name` (`rule_name`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=151 DEFAULT CHARSET=utf8 COMMENT='权限授权表';

INSERT INTO cmf_auth_access VALUES("135","2","admin/member/default","admin_url");
INSERT INTO cmf_auth_access VALUES("136","2","admin/member/index","admin_url");
INSERT INTO cmf_auth_access VALUES("137","2","admin/plugin/default","admin_url");
INSERT INTO cmf_auth_access VALUES("138","2","admin/hook/index","admin_url");
INSERT INTO cmf_auth_access VALUES("139","2","admin/hook/plugins","admin_url");
INSERT INTO cmf_auth_access VALUES("140","2","admin/hook/pluginlistorder","admin_url");
INSERT INTO cmf_auth_access VALUES("141","2","admin/hook/sync","admin_url");
INSERT INTO cmf_auth_access VALUES("142","2","admin/plugin/index","admin_url");
INSERT INTO cmf_auth_access VALUES("143","2","admin/plugin/toggle","admin_url");
INSERT INTO cmf_auth_access VALUES("144","2","admin/plugin/setting","admin_url");
INSERT INTO cmf_auth_access VALUES("145","2","admin/plugin/settingpost","admin_url");
INSERT INTO cmf_auth_access VALUES("146","2","admin/plugin/install","admin_url");
INSERT INTO cmf_auth_access VALUES("147","2","admin/plugin/update","admin_url");
INSERT INTO cmf_auth_access VALUES("148","2","admin/plugin/uninstall","admin_url");
INSERT INTO cmf_auth_access VALUES("149","2","plugin/swagger/adminindex/index","admin_url");
INSERT INTO cmf_auth_access VALUES("150","2","/plugin/form/adminindex/setting","admin_url");



DROP TABLE cmf_auth_rule;

CREATE TABLE `cmf_auth_rule` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '规则id,自增主键',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '是否有效(0:无效,1:有效)',
  `app` varchar(40) NOT NULL DEFAULT '' COMMENT '规则所属app',
  `type` varchar(30) NOT NULL DEFAULT '' COMMENT '权限规则分类，请加应用前缀,如admin_',
  `name` varchar(100) NOT NULL DEFAULT '' COMMENT '规则唯一英文标识,全小写',
  `param` varchar(100) NOT NULL DEFAULT '' COMMENT '额外url参数',
  `title` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '规则描述',
  `condition` varchar(200) NOT NULL DEFAULT '' COMMENT '规则附加条件',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `name` (`name`) USING BTREE,
  KEY `module` (`app`,`status`,`type`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=205 DEFAULT CHARSET=utf8mb4 COMMENT='权限规则表';

INSERT INTO cmf_auth_rule VALUES("1","1","admin","admin_url","admin/Hook/index","","钩子管理","");
INSERT INTO cmf_auth_rule VALUES("2","1","admin","admin_url","admin/Hook/plugins","","钩子插件管理","");
INSERT INTO cmf_auth_rule VALUES("3","1","admin","admin_url","admin/Hook/pluginListOrder","","钩子插件排序","");
INSERT INTO cmf_auth_rule VALUES("4","1","admin","admin_url","admin/Hook/sync","","同步钩子","");
INSERT INTO cmf_auth_rule VALUES("5","1","admin","admin_url","admin/Link/index","","友情链接","");
INSERT INTO cmf_auth_rule VALUES("6","1","admin","admin_url","admin/Link/add","","添加友情链接","");
INSERT INTO cmf_auth_rule VALUES("7","1","admin","admin_url","admin/Link/addPost","","添加友情链接提交保存","");
INSERT INTO cmf_auth_rule VALUES("8","1","admin","admin_url","admin/Link/edit","","编辑友情链接","");
INSERT INTO cmf_auth_rule VALUES("9","1","admin","admin_url","admin/Link/editPost","","编辑友情链接提交保存","");
INSERT INTO cmf_auth_rule VALUES("10","1","admin","admin_url","admin/Link/delete","","删除友情链接","");
INSERT INTO cmf_auth_rule VALUES("11","1","admin","admin_url","admin/Link/listOrder","","友情链接排序","");
INSERT INTO cmf_auth_rule VALUES("12","1","admin","admin_url","admin/Link/toggle","","友情链接显示隐藏","");
INSERT INTO cmf_auth_rule VALUES("13","1","admin","admin_url","admin/Mailer/index","","邮箱配置","");
INSERT INTO cmf_auth_rule VALUES("14","1","admin","admin_url","admin/Mailer/indexPost","","邮箱配置提交保存","");
INSERT INTO cmf_auth_rule VALUES("15","1","admin","admin_url","admin/Mailer/template","","邮件模板","");
INSERT INTO cmf_auth_rule VALUES("16","1","admin","admin_url","admin/Mailer/templatePost","","邮件模板提交","");
INSERT INTO cmf_auth_rule VALUES("17","1","admin","admin_url","admin/Mailer/test","","邮件发送测试","");
INSERT INTO cmf_auth_rule VALUES("18","1","admin","admin_url","admin/Menu/index","","后台菜单","");
INSERT INTO cmf_auth_rule VALUES("19","1","admin","admin_url","admin/Menu/lists","","所有菜单","");
INSERT INTO cmf_auth_rule VALUES("20","1","admin","admin_url","admin/Menu/add","","后台菜单添加","");
INSERT INTO cmf_auth_rule VALUES("21","1","admin","admin_url","admin/Menu/addPost","","后台菜单添加提交保存","");
INSERT INTO cmf_auth_rule VALUES("22","1","admin","admin_url","admin/Menu/edit","","后台菜单编辑","");
INSERT INTO cmf_auth_rule VALUES("23","1","admin","admin_url","admin/Menu/editPost","","后台菜单编辑提交保存","");
INSERT INTO cmf_auth_rule VALUES("24","1","admin","admin_url","admin/Menu/delete","","后台菜单删除","");
INSERT INTO cmf_auth_rule VALUES("25","1","admin","admin_url","admin/Menu/listOrder","","后台菜单排序","");
INSERT INTO cmf_auth_rule VALUES("26","1","admin","admin_url","admin/Menu/getActions","","导入新后台菜单","");
INSERT INTO cmf_auth_rule VALUES("27","1","admin","admin_url","admin/Nav/index","","导航管理","");
INSERT INTO cmf_auth_rule VALUES("28","1","admin","admin_url","admin/Nav/add","","添加导航","");
INSERT INTO cmf_auth_rule VALUES("29","1","admin","admin_url","admin/Nav/addPost","","添加导航提交保存","");
INSERT INTO cmf_auth_rule VALUES("30","1","admin","admin_url","admin/Nav/edit","","编辑导航","");
INSERT INTO cmf_auth_rule VALUES("31","1","admin","admin_url","admin/Nav/editPost","","编辑导航提交保存","");
INSERT INTO cmf_auth_rule VALUES("32","1","admin","admin_url","admin/Nav/delete","","删除导航","");
INSERT INTO cmf_auth_rule VALUES("33","1","admin","admin_url","admin/NavMenu/index","","导航菜单","");
INSERT INTO cmf_auth_rule VALUES("34","1","admin","admin_url","admin/NavMenu/add","","添加导航菜单","");
INSERT INTO cmf_auth_rule VALUES("35","1","admin","admin_url","admin/NavMenu/addPost","","添加导航菜单提交保存","");
INSERT INTO cmf_auth_rule VALUES("36","1","admin","admin_url","admin/NavMenu/edit","","编辑导航菜单","");
INSERT INTO cmf_auth_rule VALUES("37","1","admin","admin_url","admin/NavMenu/editPost","","编辑导航菜单提交保存","");
INSERT INTO cmf_auth_rule VALUES("38","1","admin","admin_url","admin/NavMenu/delete","","删除导航菜单","");
INSERT INTO cmf_auth_rule VALUES("39","1","admin","admin_url","admin/NavMenu/listOrder","","导航菜单排序","");
INSERT INTO cmf_auth_rule VALUES("40","1","admin","admin_url","admin/Plugin/default","","插件中心","");
INSERT INTO cmf_auth_rule VALUES("41","1","admin","admin_url","admin/Plugin/index","","插件列表","");
INSERT INTO cmf_auth_rule VALUES("42","1","admin","admin_url","admin/Plugin/toggle","","插件启用禁用","");
INSERT INTO cmf_auth_rule VALUES("43","1","admin","admin_url","admin/Plugin/setting","","插件设置","");
INSERT INTO cmf_auth_rule VALUES("44","1","admin","admin_url","admin/Plugin/settingPost","","插件设置提交","");
INSERT INTO cmf_auth_rule VALUES("45","1","admin","admin_url","admin/Plugin/install","","插件安装","");
INSERT INTO cmf_auth_rule VALUES("46","1","admin","admin_url","admin/Plugin/update","","插件更新","");
INSERT INTO cmf_auth_rule VALUES("47","1","admin","admin_url","admin/Plugin/uninstall","","卸载插件","");
INSERT INTO cmf_auth_rule VALUES("48","1","admin","admin_url","admin/Rbac/index","","角色管理","");
INSERT INTO cmf_auth_rule VALUES("49","1","admin","admin_url","admin/Rbac/roleAdd","","添加角色","");
INSERT INTO cmf_auth_rule VALUES("50","1","admin","admin_url","admin/Rbac/roleAddPost","","添加角色提交","");
INSERT INTO cmf_auth_rule VALUES("51","1","admin","admin_url","admin/Rbac/roleEdit","","编辑角色","");
INSERT INTO cmf_auth_rule VALUES("52","1","admin","admin_url","admin/Rbac/roleEditPost","","编辑角色提交","");
INSERT INTO cmf_auth_rule VALUES("53","1","admin","admin_url","admin/Rbac/roleDelete","","删除角色","");
INSERT INTO cmf_auth_rule VALUES("54","1","admin","admin_url","admin/Rbac/authorize","","设置角色权限","");
INSERT INTO cmf_auth_rule VALUES("55","1","admin","admin_url","admin/Rbac/authorizePost","","角色授权提交","");
INSERT INTO cmf_auth_rule VALUES("56","1","admin","admin_url","admin/RecycleBin/index","","回收站","");
INSERT INTO cmf_auth_rule VALUES("57","1","admin","admin_url","admin/RecycleBin/restore","","回收站还原","");
INSERT INTO cmf_auth_rule VALUES("58","1","admin","admin_url","admin/RecycleBin/delete","","回收站彻底删除","");
INSERT INTO cmf_auth_rule VALUES("59","1","admin","admin_url","admin/Route/index","","URL美化","");
INSERT INTO cmf_auth_rule VALUES("60","1","admin","admin_url","admin/Route/add","","添加路由规则","");
INSERT INTO cmf_auth_rule VALUES("61","1","admin","admin_url","admin/Route/addPost","","添加路由规则提交","");
INSERT INTO cmf_auth_rule VALUES("62","1","admin","admin_url","admin/Route/edit","","路由规则编辑","");
INSERT INTO cmf_auth_rule VALUES("63","1","admin","admin_url","admin/Route/editPost","","路由规则编辑提交","");
INSERT INTO cmf_auth_rule VALUES("64","1","admin","admin_url","admin/Route/delete","","路由规则删除","");
INSERT INTO cmf_auth_rule VALUES("65","1","admin","admin_url","admin/Route/ban","","路由规则禁用","");
INSERT INTO cmf_auth_rule VALUES("66","1","admin","admin_url","admin/Route/open","","路由规则启用","");
INSERT INTO cmf_auth_rule VALUES("67","1","admin","admin_url","admin/Route/listOrder","","路由规则排序","");
INSERT INTO cmf_auth_rule VALUES("68","1","admin","admin_url","admin/Route/select","","选择URL","");
INSERT INTO cmf_auth_rule VALUES("69","1","admin","admin_url","admin/Setting/default","","设置","");
INSERT INTO cmf_auth_rule VALUES("70","1","admin","admin_url","admin/Setting/site","","网站信息","");
INSERT INTO cmf_auth_rule VALUES("71","1","admin","admin_url","admin/Setting/sitePost","","网站信息设置提交","");
INSERT INTO cmf_auth_rule VALUES("72","1","admin","admin_url","admin/Setting/password","","密码修改","");
INSERT INTO cmf_auth_rule VALUES("73","1","admin","admin_url","admin/Setting/passwordPost","","密码修改提交","");
INSERT INTO cmf_auth_rule VALUES("74","1","admin","admin_url","admin/Setting/upload","","上传设置","");
INSERT INTO cmf_auth_rule VALUES("75","1","admin","admin_url","admin/Setting/uploadPost","","上传设置提交","");
INSERT INTO cmf_auth_rule VALUES("76","1","admin","admin_url","admin/Setting/clearCache","","清除缓存","");
INSERT INTO cmf_auth_rule VALUES("77","1","admin","admin_url","admin/Slide/index","","幻灯片管理","");
INSERT INTO cmf_auth_rule VALUES("78","1","admin","admin_url","admin/Slide/add","","添加幻灯片","");
INSERT INTO cmf_auth_rule VALUES("79","1","admin","admin_url","admin/Slide/addPost","","添加幻灯片提交","");
INSERT INTO cmf_auth_rule VALUES("80","1","admin","admin_url","admin/Slide/edit","","编辑幻灯片","");
INSERT INTO cmf_auth_rule VALUES("81","1","admin","admin_url","admin/Slide/editPost","","编辑幻灯片提交","");
INSERT INTO cmf_auth_rule VALUES("82","1","admin","admin_url","admin/Slide/delete","","删除幻灯片","");
INSERT INTO cmf_auth_rule VALUES("83","1","admin","admin_url","admin/SlideItem/index","","幻灯片页面列表","");
INSERT INTO cmf_auth_rule VALUES("84","1","admin","admin_url","admin/SlideItem/add","","幻灯片页面添加","");
INSERT INTO cmf_auth_rule VALUES("85","1","admin","admin_url","admin/SlideItem/addPost","","幻灯片页面添加提交","");
INSERT INTO cmf_auth_rule VALUES("86","1","admin","admin_url","admin/SlideItem/edit","","幻灯片页面编辑","");
INSERT INTO cmf_auth_rule VALUES("87","1","admin","admin_url","admin/SlideItem/editPost","","幻灯片页面编辑提交","");
INSERT INTO cmf_auth_rule VALUES("88","1","admin","admin_url","admin/SlideItem/delete","","幻灯片页面删除","");
INSERT INTO cmf_auth_rule VALUES("89","1","admin","admin_url","admin/SlideItem/ban","","幻灯片页面隐藏","");
INSERT INTO cmf_auth_rule VALUES("90","1","admin","admin_url","admin/SlideItem/cancelBan","","幻灯片页面显示","");
INSERT INTO cmf_auth_rule VALUES("91","1","admin","admin_url","admin/SlideItem/listOrder","","幻灯片页面排序","");
INSERT INTO cmf_auth_rule VALUES("92","1","admin","admin_url","admin/Storage/index","","文件存储","");
INSERT INTO cmf_auth_rule VALUES("93","1","admin","admin_url","admin/Storage/settingPost","","文件存储设置提交","");
INSERT INTO cmf_auth_rule VALUES("94","1","admin","admin_url","admin/Theme/index","","模板管理","");
INSERT INTO cmf_auth_rule VALUES("95","1","admin","admin_url","admin/Theme/install","","安装模板","");
INSERT INTO cmf_auth_rule VALUES("96","1","admin","admin_url","admin/Theme/uninstall","","卸载模板","");
INSERT INTO cmf_auth_rule VALUES("97","1","admin","admin_url","admin/Theme/installTheme","","模板安装","");
INSERT INTO cmf_auth_rule VALUES("98","1","admin","admin_url","admin/Theme/update","","模板更新","");
INSERT INTO cmf_auth_rule VALUES("99","1","admin","admin_url","admin/Theme/active","","启用模板","");
INSERT INTO cmf_auth_rule VALUES("100","1","admin","admin_url","admin/Theme/files","","模板文件列表","");
INSERT INTO cmf_auth_rule VALUES("101","1","admin","admin_url","admin/Theme/fileSetting","","模板文件设置","");
INSERT INTO cmf_auth_rule VALUES("102","1","admin","admin_url","admin/Theme/fileArrayData","","模板文件数组数据列表","");
INSERT INTO cmf_auth_rule VALUES("103","1","admin","admin_url","admin/Theme/fileArrayDataEdit","","模板文件数组数据添加编辑","");
INSERT INTO cmf_auth_rule VALUES("104","1","admin","admin_url","admin/Theme/fileArrayDataEditPost","","模板文件数组数据添加编辑提交保存","");
INSERT INTO cmf_auth_rule VALUES("105","1","admin","admin_url","admin/Theme/fileArrayDataDelete","","模板文件数组数据删除","");
INSERT INTO cmf_auth_rule VALUES("106","1","admin","admin_url","admin/Theme/settingPost","","模板文件编辑提交保存","");
INSERT INTO cmf_auth_rule VALUES("107","1","admin","admin_url","admin/Theme/dataSource","","模板文件设置数据源","");
INSERT INTO cmf_auth_rule VALUES("108","1","admin","admin_url","admin/Theme/design","","模板设计","");
INSERT INTO cmf_auth_rule VALUES("109","1","admin","admin_url","admin/User/default","","管理组","");
INSERT INTO cmf_auth_rule VALUES("110","1","admin","admin_url","admin/User/index","","管理员","");
INSERT INTO cmf_auth_rule VALUES("111","1","admin","admin_url","admin/User/add","","管理员添加","");
INSERT INTO cmf_auth_rule VALUES("112","1","admin","admin_url","admin/User/addPost","","管理员添加提交","");
INSERT INTO cmf_auth_rule VALUES("113","1","admin","admin_url","admin/User/edit","","管理员编辑","");
INSERT INTO cmf_auth_rule VALUES("114","1","admin","admin_url","admin/User/editPost","","管理员编辑提交","");
INSERT INTO cmf_auth_rule VALUES("115","1","admin","admin_url","admin/User/userInfo","","个人信息","");
INSERT INTO cmf_auth_rule VALUES("116","1","admin","admin_url","admin/User/userInfoPost","","管理员个人信息修改提交","");
INSERT INTO cmf_auth_rule VALUES("117","1","admin","admin_url","admin/User/delete","","管理员删除","");
INSERT INTO cmf_auth_rule VALUES("118","1","admin","admin_url","admin/User/ban","","停用管理员","");
INSERT INTO cmf_auth_rule VALUES("119","1","admin","admin_url","admin/User/cancelBan","","启用管理员","");
INSERT INTO cmf_auth_rule VALUES("120","1","user","admin_url","user/AdminAsset/index","","资源管理","");
INSERT INTO cmf_auth_rule VALUES("121","1","user","admin_url","user/AdminAsset/delete","","删除文件","");
INSERT INTO cmf_auth_rule VALUES("122","1","user","admin_url","user/AdminIndex/default","","管理员","");
INSERT INTO cmf_auth_rule VALUES("123","1","user","admin_url","user/AdminIndex/default1","","用户组","");
INSERT INTO cmf_auth_rule VALUES("124","1","user","admin_url","user/AdminIndex/index","","本站用户","");
INSERT INTO cmf_auth_rule VALUES("125","1","user","admin_url","user/AdminIndex/ban","","本站用户拉黑","");
INSERT INTO cmf_auth_rule VALUES("126","1","user","admin_url","user/AdminIndex/cancelBan","","本站用户启用","");
INSERT INTO cmf_auth_rule VALUES("127","1","user","admin_url","user/AdminOauth/index","","第三方用户","");
INSERT INTO cmf_auth_rule VALUES("128","1","user","admin_url","user/AdminOauth/delete","","删除第三方用户绑定","");
INSERT INTO cmf_auth_rule VALUES("129","1","user","admin_url","user/AdminUserAction/index","","用户操作管理","");
INSERT INTO cmf_auth_rule VALUES("130","1","user","admin_url","user/AdminUserAction/edit","","编辑用户操作","");
INSERT INTO cmf_auth_rule VALUES("131","1","user","admin_url","user/AdminUserAction/editPost","","编辑用户操作提交","");
INSERT INTO cmf_auth_rule VALUES("132","1","user","admin_url","user/AdminUserAction/sync","","同步用户操作","");
INSERT INTO cmf_auth_rule VALUES("133","1","admin","admin_url","admin/AppInfo/index","","应用设置","");
INSERT INTO cmf_auth_rule VALUES("162","1","admin","admin_url","admin/RecycleBin/clear","","清空回收站","");
INSERT INTO cmf_auth_rule VALUES("163","1","plugin/Swagger","plugin_url","plugin/Swagger/AdminIndex/index","","Swagger","");
INSERT INTO cmf_auth_rule VALUES("164","1","plugin/Configs","plugin_url","plugin/Configs/AdminIndex/index","","系统参数设置","");
INSERT INTO cmf_auth_rule VALUES("166","1","plugin/AdminJournal","admin_url","plugin/AdminJournal/AdminIndex/index","","操作日志","");
INSERT INTO cmf_auth_rule VALUES("167","1","admin","admin_url","admin/member/default","","用户管理","");
INSERT INTO cmf_auth_rule VALUES("168","1","admin","admin_url","admin/member/index","","用户管理","");
INSERT INTO cmf_auth_rule VALUES("169","1","/plugin/form","admin_url","/plugin/form/AdminIndex/setting","","生成CURD","");
INSERT INTO cmf_auth_rule VALUES("177","1","admin","admin_url","admin/dingdan/index","","订单管理","");
INSERT INTO cmf_auth_rule VALUES("178","1","admin","admin_url","admin/shop_order/index","","订单管理","");
INSERT INTO cmf_auth_rule VALUES("179","1","admin","admin_url","admin/Shop/index","","店铺管理","");
INSERT INTO cmf_auth_rule VALUES("180","1","admin","admin_url","admin/Shop/edit","","店铺管理-编辑","");
INSERT INTO cmf_auth_rule VALUES("181","1","admin","admin_url","admin/Shop/add","","店铺管理-添加","");
INSERT INTO cmf_auth_rule VALUES("182","1","admin","admin_url","admin/Shop/find","","店铺管理-查看","");
INSERT INTO cmf_auth_rule VALUES("183","1","admin","admin_url","admin/Shop/delete","","店铺管理-删除","");
INSERT INTO cmf_auth_rule VALUES("184","1","admin","admin_url","admin/FormTest/index","","测试生成crud","");
INSERT INTO cmf_auth_rule VALUES("185","1","admin","admin_url","admin/FormTest/edit","","测试生成crud-编辑","");
INSERT INTO cmf_auth_rule VALUES("186","1","admin","admin_url","admin/FormTest/add","","测试生成crud-添加","");
INSERT INTO cmf_auth_rule VALUES("187","1","admin","admin_url","admin/FormTest/find","","测试生成crud-查看","");
INSERT INTO cmf_auth_rule VALUES("188","1","admin","admin_url","admin/FormTest/delete","","测试生成crud-删除","");
INSERT INTO cmf_auth_rule VALUES("189","1","admin","admin_url","admin/FormTest/recommend_post","","测试生成crud-推荐","");
INSERT INTO cmf_auth_rule VALUES("190","1","admin","admin_url","admin/FormTest/list_order_post","","测试生成crud-排序","");
INSERT INTO cmf_auth_rule VALUES("191","1","admin","admin_url","admin/test/index","","测试","");
INSERT INTO cmf_auth_rule VALUES("192","1","plugin/weipay","admin_url","plugin/weipay/admin_index/index","","小程序设置","");
INSERT INTO cmf_auth_rule VALUES("193","1","admin","admin_url","admin/moren/index","","子权限","");
INSERT INTO cmf_auth_rule VALUES("194","1","admin","admin_url","admin/tiku/index","","题库管理","");
INSERT INTO cmf_auth_rule VALUES("195","1","admin","admin_url","admin/Answer/index","","答题类型","");
INSERT INTO cmf_auth_rule VALUES("196","1","admin","admin_url","admin/Answer/edit","","答题类型-编辑","");
INSERT INTO cmf_auth_rule VALUES("197","1","admin","admin_url","admin/Answer/add","","答题类型-添加","");
INSERT INTO cmf_auth_rule VALUES("198","1","admin","admin_url","admin/Answer/find","","答题类型-查看","");
INSERT INTO cmf_auth_rule VALUES("199","1","admin","admin_url","admin/Answer/delete","","答题类型-删除","");
INSERT INTO cmf_auth_rule VALUES("200","1","admin","admin_url","admin/jilu/index","","答题记录","");
INSERT INTO cmf_auth_rule VALUES("201","1","admin","admin_url","admin/AnswerResult/index","","答题结果","");
INSERT INTO cmf_auth_rule VALUES("202","1","admin","admin_url","admin/AnswerResult/find","","答题结果-查看","");
INSERT INTO cmf_auth_rule VALUES("203","1","admin","admin_url","admin/AnswerWrong/index","","错题记录","");
INSERT INTO cmf_auth_rule VALUES("204","1","admin","admin_url","admin/AnswerWrong/find","","错题记录-查看","");



CREATE TABLE `cmf_base_admin_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` tinyint(2) DEFAULT '1' COMMENT '1后台  2前端',
  `log` longtext COMMENT '操作地址参数',
  `admin_id` int(11) DEFAULT NULL COMMENT '登录人',
  `admin_name` varchar(200) DEFAULT NULL COMMENT '昵称',
  `openid` varchar(255) DEFAULT NULL COMMENT '登录标识',
  `ip` varchar(200) DEFAULT NULL COMMENT 'IP地址',
  `menu_name` varchar(250) DEFAULT NULL COMMENT '地址栏',
  `param` longtext COMMENT '参数值',
  `create_time` bigint(20) DEFAULT NULL COMMENT '创建时间',
  `date` varchar(200) DEFAULT NULL COMMENT '日期',
  `visit_url` text COMMENT '域名+参数',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2435 DEFAULT CHARSET=utf8mb4 COMMENT='管理员日志';

DROP TABLE cmf_base_balance;

CREATE TABLE `cmf_base_balance` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `identity_type` varchar(255) DEFAULT 'member' COMMENT '身份类型',
  `type` tinyint(6) DEFAULT NULL COMMENT '类型:1=收入,2=支出',
  `price` decimal(10,2) DEFAULT NULL COMMENT '变动金额',
  `before` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '变更前',
  `after` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '变更后',
  `content` varchar(50) DEFAULT NULL COMMENT '变动说明',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注',
  `order_type` int(11) DEFAULT '0' COMMENT '订单类型 ',
  `order_num` varchar(100) DEFAULT NULL COMMENT '订单单号',
  `order_id` int(11) DEFAULT '0' COMMENT '订单ID',
  `create_time` bigint(20) DEFAULT NULL COMMENT '创建时间',
  `update_time` bigint(20) DEFAULT NULL COMMENT '更新时间',
  `delete_time` bigint(20) DEFAULT '0' COMMENT '删除时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `uid` (`user_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COMMENT='会员账户余额变动记录';

INSERT INTO cmf_base_balance VALUES("1","1","member","1","100.00","0.00","100.00","测试","操作人[1-admin];操作说明[测试];操作类型[增加用户余额];","100","2409041895172655509721","0","1725418951","","0");
INSERT INTO cmf_base_balance VALUES("2","1","member","2","50.00","100.00","50.00","测试-50","操作人[1-admin];操作说明[测试-50];操作类型[扣除用户余额];","100","2409041897425820447319","0","1725418974","","0");
INSERT INTO cmf_base_balance VALUES("3","1","member","1","10.00","50.00","60.00","测试10","操作人[1-admin];操作说明[测试10];操作类型[增加用户余额];","100","2409042034114985307431","0","1725420341","","0");
INSERT INTO cmf_base_balance VALUES("4","1","member","2","10.00","60.00","50.00","测试-10","操作人[1-admin];操作说明[测试-10];操作类型[扣除用户余额];","100","2409042034923178072236","0","1725420349","","0");



DROP TABLE cmf_base_config;

CREATE TABLE `cmf_base_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'group_id只',
  `is_menu` tinyint(4) DEFAULT '2' COMMENT '是否菜单1:线上显示,本地都显示,2所有不显示,3本地显示,线上不显示',
  `menu_name` varchar(255) DEFAULT NULL COMMENT '菜单名字',
  `key` bigint(20) DEFAULT NULL COMMENT 'group_id值',
  `group_id` bigint(20) DEFAULT NULL COMMENT '分组ID',
  `name` varchar(100) DEFAULT NULL COMMENT '参数名',
  `value` text COMMENT '参数值,序列化数据',
  `label` varchar(100) DEFAULT NULL COMMENT '参数说明',
  `uridata` varchar(100) DEFAULT NULL COMMENT '附加数据',
  `data` varchar(2555) DEFAULT NULL COMMENT '数据源',
  `type` varchar(100) DEFAULT 'text' COMMENT '设置类型 ',
  `about` varchar(100) DEFAULT NULL COMMENT '备注注释',
  `list_order` bigint(20) DEFAULT NULL COMMENT '排序',
  `status` tinyint(100) DEFAULT '1' COMMENT '0不显示',
  `scatter` varchar(100) DEFAULT NULL COMMENT '隔断,打散数据 /',
  `data_type` varchar(50) DEFAULT NULL COMMENT '数据类型',
  `is_label` tinyint(4) DEFAULT '0' COMMENT '组件数据格式:0否,1是',
  `is_edit` tinyint(4) DEFAULT '0' COMMENT '禁止编辑:0否,1是',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=139 DEFAULT CHARSET=utf8mb4 COMMENT='系统配置';

INSERT INTO cmf_base_config VALUES("1","1","系统配置","100","0","system_configuration","","系统配置","","s:0:\"\";","text","","100","1","","","0","0");
INSERT INTO cmf_base_config VALUES("2","3","私有配置","999999","0","private_configuration","","私有配置","","s:0:\"\";","text","","999999","1","","","0","0");
INSERT INTO cmf_base_config VALUES("100","2","","0","100","app_logo","s:61:\"dzkf382/default/20241008/d993653cf8d15bb29c6ddfe078f41a59.png\";","应用LOGO","","s:0:\"\";","img","","1","1","","string","0","0");
INSERT INTO cmf_base_config VALUES("101","2","","0","100","app_name","s:12:\"渝辐科技\";","应用名称","","s:0:\"\";","","","2","1","","string","0","0");
INSERT INTO cmf_base_config VALUES("102","2","","0","999999","domain_name","s:26:\"https://dzkf382.aejust.com\";","域名","","s:0:\"\";","text","","100","1","","string","0","0");
INSERT INTO cmf_base_config VALUES("103","2","","0","999999","app_expiration_time","s:0:\"\";","应用到期时间","","s:0:\"\";","date","开发应用到期时间","300","1","","","0","0");
INSERT INTO cmf_base_config VALUES("104","2","","0","999999","project_name","s:15:\"管题公众号\";","项目名字","","s:0:\"\";","","本地项目名","300","1","","","0","0");
INSERT INTO cmf_base_config VALUES("105","2","","0","999999","copyright","s:42:\"技术支持：微巨宝科技有限公司\";","版权","","s:0:\"\";","","登录页版权","400","1","","","0","0");
INSERT INTO cmf_base_config VALUES("106","2","","0","999999","local_domain_name","s:18:\"http://answer.ikun\";","本地域名","","s:0:\"\";","","","200","1","","","0","0");
INSERT INTO cmf_base_config VALUES("107","2","","0","999999","log_file_days","s:2:\"10\";","日志文件保留天数","","s:0:\"\";","number","日志文件保留天数","500","1","","","0","0");
INSERT INTO cmf_base_config VALUES("136","3","程序配置","200","0","program_configuration","","程序配置","","s:0:\"\";","","","200","1","","","0","0");
INSERT INTO cmf_base_config VALUES("137","2","","0","200","program_information","s:26:\"答题公众号-xww1989129\";","程序信息","","s:0:\"\";","","","100","1","","","0","0");
INSERT INTO cmf_base_config VALUES("138","2","","0","200","program_code","s:61:\"dzkf382/default/20241016/10b72558bbf1d6ae0739b0ef4bf0bc1b.jpg\";","程序码","","s:0:\"\";","img","","200","1","","","0","0");



DROP TABLE cmf_base_express;

CREATE TABLE `cmf_base_express` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(12) DEFAULT NULL COMMENT '快递名称',
  `abbr` varchar(10) DEFAULT NULL COMMENT '微信快递code',
  `kd_hundred_code` varchar(255) DEFAULT NULL COMMENT '快递100code',
  `kd_bird_code` varchar(255) DEFAULT NULL COMMENT '快递鸟code',
  `status` tinyint(4) DEFAULT '1' COMMENT '2删除',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COMMENT='快递表';

INSERT INTO cmf_base_express VALUES("1","安能物流","ANE","annengwuliu","ANE","1");
INSERT INTO cmf_base_express VALUES("2","百世快递","BEST","huitongkuaidi","HTKY","1");
INSERT INTO cmf_base_express VALUES("3","德邦快递","DB","debangkuaidi","DBL","1");
INSERT INTO cmf_base_express VALUES("4","中国邮政速递物流","EMS","youzhengguonei","YZPY","1");
INSERT INTO cmf_base_express VALUES("6","京东快递","JDL","jd","JD","1");
INSERT INTO cmf_base_express VALUES("7","极兔快递","JTSD","jtexpress","JTSD","1");
INSERT INTO cmf_base_express VALUES("9","顺丰速运","SF","shunfeng","SF","1");
INSERT INTO cmf_base_express VALUES("10","申通快递","STO","shentong","STO","1");
INSERT INTO cmf_base_express VALUES("12","圆通速递","YTO","yuantong","YTO","1");
INSERT INTO cmf_base_express VALUES("13","韵达快递","YUNDA","yunda","YD","1");
INSERT INTO cmf_base_express VALUES("14","中通快递","ZTO","zhongtong","ZTO","1");



DROP TABLE cmf_base_form_model;

CREATE TABLE `cmf_base_form_model` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `json_params` text COLLATE utf8_unicode_ci,
  `type` tinyint(2) DEFAULT '1' COMMENT '1提交数据  2访问域名',
  `remark` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=40 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='生成curt';

INSERT INTO cmf_base_form_model VALUES("1","a:33:{s:10:\"table_name\";s:9:\"form_test\";s:10:\"model_name\";s:8:\"FormTest\";s:4:\"tags\";s:16:\"测试生成crud\";s:7:\"keyword\";a:8:{s:9:\"order_num\";s:2:\"on\";s:4:\"type\";s:2:\"on\";s:7:\"b_image\";s:2:\"on\";s:8:\"b_images\";s:2:\"on\";s:9:\"a_content\";s:2:\"on\";s:9:\"b_content\";s:2:\"on\";s:6:\"status\";s:2:\"on\";s:12:\"is_recommend\";s:2:\"on\";}s:14:\"api_controller\";s:2:\"on\";s:12:\"api_paginate\";s:2:\"on\";s:13:\"api_checkAuth\";s:2:\"on\";s:10:\"api_openid\";s:6:\"openid\";s:16:\"admin_controller\";s:2:\"on\";s:14:\"admin_paginate\";s:2:\"on\";s:10:\"admin_view\";s:2:\"on\";s:10:\"admin_menu\";s:2:\"on\";s:9:\"index_add\";s:2:\"on\";s:10:\"index_edit\";s:2:\"on\";s:10:\"index_find\";s:2:\"on\";s:12:\"index_delete\";s:2:\"on\";s:14:\"index_delete_s\";s:2:\"on\";s:15:\"index_recommend\";s:2:\"on\";s:16:\"index_list_order\";s:2:\"on\";s:11:\"index_enter\";s:2:\"on\";s:9:\"index_out\";s:2:\"on\";s:9:\"parent_id\";s:0:\"\";s:4:\"name\";s:16:\"测试生成crud\";s:3:\"app\";s:5:\"admin\";s:6:\"action\";s:5:\"index\";s:5:\"param\";s:0:\"\";s:4:\"icon\";s:0:\"\";s:6:\"remark\";s:0:\"\";s:6:\"status\";s:1:\"1\";s:4:\"type\";s:1:\"1\";s:7:\"_plugin\";s:4:\"form\";s:11:\"_controller\";s:10:\"AdminIndex\";s:7:\"_action\";s:11:\"settingPost\";}","1","");
INSERT INTO cmf_base_form_model VALUES("2","http://w.site/plugin/form/AdminIndex/settingPost","2","表名:form_test  -------  控制器(tags):测试生成crud");
INSERT INTO cmf_base_form_model VALUES("3","https://lscs001.jscxkf.net/plugin/form/AdminIndex/settingPost","2","表名:form_test  -------  控制器(tags):测试生成crud");
INSERT INTO cmf_base_form_model VALUES("4","https://lscs001.jscxkf.net/plugin/form/AdminIndex/settingPost","2","表名:form_test  -------  控制器(tags):测试生成crud");
INSERT INTO cmf_base_form_model VALUES("5","a:26:{s:10:\"table_name\";s:17:\"shop_order_detail\";s:10:\"model_name\";s:15:\"ShopOrderDetail\";s:4:\"tags\";s:12:\"订单详情\";s:7:\"keyword\";a:6:{s:8:\"goods_id\";s:2:\"on\";s:6:\"sku_id\";s:2:\"on\";s:10:\"goods_name\";s:2:\"on\";s:8:\"sku_name\";s:2:\"on\";s:5:\"count\";s:2:\"on\";s:11:\"goods_price\";s:2:\"on\";}s:14:\"api_controller\";s:2:\"on\";s:12:\"api_paginate\";s:2:\"on\";s:10:\"api_openid\";s:6:\"openid\";s:16:\"admin_controller\";s:2:\"on\";s:14:\"admin_paginate\";s:2:\"on\";s:10:\"admin_view\";s:2:\"on\";s:9:\"index_add\";s:2:\"on\";s:10:\"index_edit\";s:2:\"on\";s:10:\"index_find\";s:2:\"on\";s:12:\"index_delete\";s:2:\"on\";s:9:\"parent_id\";s:0:\"\";s:4:\"name\";s:12:\"订单详情\";s:3:\"app\";s:5:\"admin\";s:6:\"action\";s:5:\"index\";s:5:\"param\";s:0:\"\";s:4:\"icon\";s:0:\"\";s:6:\"remark\";s:0:\"\";s:6:\"status\";s:1:\"1\";s:4:\"type\";s:1:\"1\";s:7:\"_plugin\";s:4:\"form\";s:11:\"_controller\";s:10:\"AdminIndex\";s:7:\"_action\";s:11:\"settingPost\";}","1","");
INSERT INTO cmf_base_form_model VALUES("6","http://w.site/plugin/form/AdminIndex/settingPost","2","表名:shop_order_detail  -------  控制器(tags):订单详情");
INSERT INTO cmf_base_form_model VALUES("7","https://lscs001.jscxkf.net/plugin/form/AdminIndex/settingPost","2","表名:shop_order_detail  -------  控制器(tags):订单详情");
INSERT INTO cmf_base_form_model VALUES("8","a:32:{s:10:\"table_name\";s:4:\"test\";s:10:\"model_name\";s:4:\"Test\";s:4:\"tags\";s:4:\"test\";s:7:\"keyword\";a:1:{s:4:\"name\";s:2:\"on\";}s:14:\"api_controller\";s:2:\"on\";s:12:\"api_paginate\";s:2:\"on\";s:10:\"api_openid\";s:6:\"openid\";s:16:\"admin_controller\";s:2:\"on\";s:14:\"admin_paginate\";s:2:\"on\";s:10:\"admin_view\";s:2:\"on\";s:10:\"admin_menu\";s:2:\"on\";s:9:\"index_add\";s:2:\"on\";s:10:\"index_edit\";s:2:\"on\";s:10:\"index_find\";s:2:\"on\";s:12:\"index_delete\";s:2:\"on\";s:14:\"index_delete_s\";s:2:\"on\";s:15:\"index_recommend\";s:2:\"on\";s:16:\"index_list_order\";s:2:\"on\";s:11:\"index_enter\";s:2:\"on\";s:9:\"index_out\";s:2:\"on\";s:9:\"parent_id\";s:0:\"\";s:4:\"name\";s:0:\"\";s:3:\"app\";s:5:\"admin\";s:6:\"action\";s:5:\"index\";s:5:\"param\";s:0:\"\";s:4:\"icon\";s:0:\"\";s:6:\"remark\";s:0:\"\";s:6:\"status\";s:1:\"1\";s:4:\"type\";s:1:\"1\";s:7:\"_plugin\";s:4:\"form\";s:11:\"_controller\";s:10:\"AdminIndex\";s:7:\"_action\";s:11:\"settingPost\";}","1","");
INSERT INTO cmf_base_form_model VALUES("9","http://w.site/plugin/form/AdminIndex/settingPost","2","表名:test  -------  控制器(tags):test");
INSERT INTO cmf_base_form_model VALUES("10","https://lscs001.jscxkf.net/plugin/form/AdminIndex/settingPost","2","表名:test  -------  控制器(tags):test");
INSERT INTO cmf_base_form_model VALUES("11","https://lscs001.jscxkf.net/plugin/form/AdminIndex/settingPost","2","表名:test  -------  控制器(tags):test");
INSERT INTO cmf_base_form_model VALUES("12","a:26:{s:10:\"table_name\";s:4:\"test\";s:10:\"model_name\";s:4:\"Test\";s:4:\"tags\";s:4:\"test\";s:14:\"api_controller\";s:2:\"on\";s:12:\"api_paginate\";s:2:\"on\";s:10:\"api_openid\";s:5:\"token\";s:16:\"admin_controller\";s:2:\"on\";s:14:\"admin_paginate\";s:2:\"on\";s:10:\"admin_view\";s:2:\"on\";s:10:\"admin_menu\";s:2:\"on\";s:9:\"index_add\";s:2:\"on\";s:10:\"index_edit\";s:2:\"on\";s:10:\"index_find\";s:2:\"on\";s:12:\"index_delete\";s:2:\"on\";s:9:\"parent_id\";s:0:\"\";s:4:\"name\";s:0:\"\";s:3:\"app\";s:5:\"admin\";s:6:\"action\";s:5:\"index\";s:5:\"param\";s:0:\"\";s:4:\"icon\";s:0:\"\";s:6:\"remark\";s:0:\"\";s:6:\"status\";s:1:\"1\";s:4:\"type\";s:1:\"1\";s:7:\"_plugin\";s:4:\"form\";s:11:\"_controller\";s:10:\"AdminIndex\";s:7:\"_action\";s:11:\"settingPost\";}","1","");
INSERT INTO cmf_base_form_model VALUES("13","http://w.site/plugin/form/AdminIndex/settingPost","2","表名:test  -------  控制器(tags):test");
INSERT INTO cmf_base_form_model VALUES("14","https://lscs001.jscxkf.net/plugin/form/AdminIndex/settingPost","2","表名:test  -------  控制器(tags):test");
INSERT INTO cmf_base_form_model VALUES("15","a:30:{s:10:\"table_name\";s:4:\"test\";s:10:\"model_name\";s:4:\"Test\";s:4:\"tags\";s:4:\"test\";s:14:\"api_controller\";s:2:\"on\";s:12:\"api_paginate\";s:2:\"on\";s:10:\"api_openid\";s:5:\"token\";s:16:\"admin_controller\";s:2:\"on\";s:14:\"admin_paginate\";s:2:\"on\";s:10:\"admin_view\";s:2:\"on\";s:9:\"index_add\";s:2:\"on\";s:10:\"index_edit\";s:2:\"on\";s:10:\"index_find\";s:2:\"on\";s:12:\"index_delete\";s:2:\"on\";s:14:\"index_delete_s\";s:2:\"on\";s:15:\"index_recommend\";s:2:\"on\";s:16:\"index_list_order\";s:2:\"on\";s:11:\"index_enter\";s:2:\"on\";s:9:\"index_out\";s:2:\"on\";s:9:\"parent_id\";s:0:\"\";s:4:\"name\";s:0:\"\";s:3:\"app\";s:5:\"admin\";s:6:\"action\";s:5:\"index\";s:5:\"param\";s:0:\"\";s:4:\"icon\";s:0:\"\";s:6:\"remark\";s:0:\"\";s:6:\"status\";s:1:\"1\";s:4:\"type\";s:1:\"1\";s:7:\"_plugin\";s:4:\"form\";s:11:\"_controller\";s:10:\"AdminIndex\";s:7:\"_action\";s:11:\"settingPost\";}","1","");
INSERT INTO cmf_base_form_model VALUES("16","http://w.site/plugin/form/AdminIndex/settingPost","2","表名:test  -------  控制器(tags):test");
INSERT INTO cmf_base_form_model VALUES("17","https://lscs001.jscxkf.net/plugin/form/AdminIndex/settingPost","2","表名:test  -------  控制器(tags):test");
INSERT INTO cmf_base_form_model VALUES("18","https://lscs001.jscxkf.net/plugin/form/AdminIndex/settingPost","2","表名:test  -------  控制器(tags):test");
INSERT INTO cmf_base_form_model VALUES("19","https://lscs001.jscxkf.net/plugin/form/AdminIndex/settingPost","2","表名:test  -------  控制器(tags):test");
INSERT INTO cmf_base_form_model VALUES("20","a:23:{s:10:\"table_name\";s:6:\"answer\";s:10:\"model_name\";s:6:\"Answer\";s:4:\"tags\";s:12:\"题库管理\";s:7:\"keyword\";a:1:{s:4:\"name\";s:2:\"on\";}s:14:\"api_controller\";s:2:\"on\";s:12:\"api_paginate\";s:2:\"on\";s:10:\"api_openid\";s:6:\"openid\";s:16:\"admin_controller\";s:2:\"on\";s:14:\"admin_paginate\";s:2:\"on\";s:10:\"admin_view\";s:2:\"on\";s:10:\"index_find\";s:2:\"on\";s:9:\"parent_id\";s:3:\"200\";s:4:\"name\";s:12:\"题库管理\";s:3:\"app\";s:5:\"admin\";s:6:\"action\";s:5:\"index\";s:5:\"param\";s:0:\"\";s:4:\"icon\";s:0:\"\";s:6:\"remark\";s:0:\"\";s:6:\"status\";s:1:\"1\";s:4:\"type\";s:1:\"1\";s:7:\"_plugin\";s:4:\"form\";s:11:\"_controller\";s:10:\"AdminIndex\";s:7:\"_action\";s:11:\"settingPost\";}","1","");
INSERT INTO cmf_base_form_model VALUES("21","http://answer.ikun/plugin/form/AdminIndex/settingPost","2","表名:answer  -------  控制器(tags):题库管理");
INSERT INTO cmf_base_form_model VALUES("22","https://dzkf382.aejust.com/plugin/form/AdminIndex/settingPost","2","表名:answer  -------  控制器(tags):题库管理");
INSERT INTO cmf_base_form_model VALUES("23","a:26:{s:10:\"table_name\";s:6:\"answer\";s:10:\"model_name\";s:6:\"Answer\";s:4:\"tags\";s:12:\"答题类型\";s:14:\"api_controller\";s:2:\"on\";s:12:\"api_paginate\";s:2:\"on\";s:10:\"api_openid\";s:6:\"openid\";s:16:\"admin_controller\";s:2:\"on\";s:14:\"admin_paginate\";s:2:\"on\";s:10:\"admin_view\";s:2:\"on\";s:10:\"admin_menu\";s:2:\"on\";s:9:\"index_add\";s:2:\"on\";s:10:\"index_edit\";s:2:\"on\";s:10:\"index_find\";s:2:\"on\";s:12:\"index_delete\";s:2:\"on\";s:9:\"parent_id\";s:3:\"200\";s:4:\"name\";s:12:\"答题类型\";s:3:\"app\";s:5:\"admin\";s:6:\"action\";s:5:\"index\";s:5:\"param\";s:0:\"\";s:4:\"icon\";s:0:\"\";s:6:\"remark\";s:0:\"\";s:6:\"status\";s:1:\"1\";s:4:\"type\";s:1:\"1\";s:7:\"_plugin\";s:4:\"form\";s:11:\"_controller\";s:10:\"AdminIndex\";s:7:\"_action\";s:11:\"settingPost\";}","1","");
INSERT INTO cmf_base_form_model VALUES("24","http://answer.ikun/plugin/form/AdminIndex/settingPost","2","表名:answer  -------  控制器(tags):答题类型");
INSERT INTO cmf_base_form_model VALUES("25","a:26:{s:10:\"table_name\";s:12:\"answer_title\";s:10:\"model_name\";s:11:\"AnswerTitle\";s:4:\"tags\";s:12:\"标题管理\";s:7:\"keyword\";a:1:{s:4:\"name\";s:2:\"on\";}s:14:\"api_controller\";s:2:\"on\";s:12:\"api_paginate\";s:2:\"on\";s:10:\"api_openid\";s:6:\"openid\";s:16:\"admin_controller\";s:2:\"on\";s:14:\"admin_paginate\";s:2:\"on\";s:10:\"admin_view\";s:2:\"on\";s:9:\"index_add\";s:2:\"on\";s:10:\"index_edit\";s:2:\"on\";s:12:\"index_delete\";s:2:\"on\";s:16:\"index_list_order\";s:2:\"on\";s:9:\"parent_id\";s:0:\"\";s:4:\"name\";s:12:\"标题管理\";s:3:\"app\";s:5:\"admin\";s:6:\"action\";s:5:\"index\";s:5:\"param\";s:0:\"\";s:4:\"icon\";s:0:\"\";s:6:\"remark\";s:0:\"\";s:6:\"status\";s:1:\"1\";s:4:\"type\";s:1:\"1\";s:7:\"_plugin\";s:4:\"form\";s:11:\"_controller\";s:10:\"AdminIndex\";s:7:\"_action\";s:11:\"settingPost\";}","1","");
INSERT INTO cmf_base_form_model VALUES("26","http://answer.ikun/plugin/form/AdminIndex/settingPost","2","表名:answer_title  -------  控制器(tags):标题管理");
INSERT INTO cmf_base_form_model VALUES("27","https://dzkf382.aejust.com/plugin/form/AdminIndex/settingPost","2","表名:answer_title  -------  控制器(tags):标题管理");
INSERT INTO cmf_base_form_model VALUES("28","a:26:{s:10:\"table_name\";s:15:\"answer_question\";s:10:\"model_name\";s:14:\"AnswerQuestion\";s:4:\"tags\";s:12:\"题库管理\";s:7:\"keyword\";a:1:{s:4:\"name\";s:2:\"on\";}s:14:\"api_controller\";s:2:\"on\";s:12:\"api_paginate\";s:2:\"on\";s:10:\"api_openid\";s:6:\"openid\";s:16:\"admin_controller\";s:2:\"on\";s:14:\"admin_paginate\";s:2:\"on\";s:10:\"admin_view\";s:2:\"on\";s:9:\"index_add\";s:2:\"on\";s:10:\"index_edit\";s:2:\"on\";s:12:\"index_delete\";s:2:\"on\";s:16:\"index_list_order\";s:2:\"on\";s:9:\"parent_id\";s:0:\"\";s:4:\"name\";s:12:\"题库管理\";s:3:\"app\";s:5:\"admin\";s:6:\"action\";s:5:\"index\";s:5:\"param\";s:0:\"\";s:4:\"icon\";s:0:\"\";s:6:\"remark\";s:0:\"\";s:6:\"status\";s:1:\"1\";s:4:\"type\";s:1:\"1\";s:7:\"_plugin\";s:4:\"form\";s:11:\"_controller\";s:10:\"AdminIndex\";s:7:\"_action\";s:11:\"settingPost\";}","1","");
INSERT INTO cmf_base_form_model VALUES("29","http://answer.ikun/plugin/form/AdminIndex/settingPost","2","表名:answer_question  -------  控制器(tags):题库管理");
INSERT INTO cmf_base_form_model VALUES("30","https://dzkf382.aejust.com/plugin/form/AdminIndex/settingPost","2","表名:answer_question  -------  控制器(tags):题库管理");
INSERT INTO cmf_base_form_model VALUES("31","a:26:{s:10:\"table_name\";s:12:\"answer_class\";s:10:\"model_name\";s:11:\"AnswerClass\";s:4:\"tags\";s:12:\"类型管理\";s:7:\"keyword\";a:1:{s:4:\"name\";s:2:\"on\";}s:14:\"api_controller\";s:2:\"on\";s:12:\"api_paginate\";s:2:\"on\";s:10:\"api_openid\";s:6:\"openid\";s:16:\"admin_controller\";s:2:\"on\";s:14:\"admin_paginate\";s:2:\"on\";s:10:\"admin_view\";s:2:\"on\";s:9:\"index_add\";s:2:\"on\";s:10:\"index_edit\";s:2:\"on\";s:12:\"index_delete\";s:2:\"on\";s:16:\"index_list_order\";s:2:\"on\";s:9:\"parent_id\";s:0:\"\";s:4:\"name\";s:12:\"类型管理\";s:3:\"app\";s:5:\"admin\";s:6:\"action\";s:5:\"index\";s:5:\"param\";s:0:\"\";s:4:\"icon\";s:0:\"\";s:6:\"remark\";s:0:\"\";s:6:\"status\";s:1:\"1\";s:4:\"type\";s:1:\"1\";s:7:\"_plugin\";s:4:\"form\";s:11:\"_controller\";s:10:\"AdminIndex\";s:7:\"_action\";s:11:\"settingPost\";}","1","");
INSERT INTO cmf_base_form_model VALUES("32","http://answer.ikun/plugin/form/AdminIndex/settingPost","2","表名:answer_class  -------  控制器(tags):类型管理");
INSERT INTO cmf_base_form_model VALUES("33","https://dzkf382.aejust.com/plugin/form/AdminIndex/settingPost","2","表名:answer_class  -------  控制器(tags):类型管理");
INSERT INTO cmf_base_form_model VALUES("34","a:24:{s:10:\"table_name\";s:13:\"answer_result\";s:10:\"model_name\";s:12:\"AnswerResult\";s:4:\"tags\";s:12:\"答题结果\";s:7:\"keyword\";a:1:{s:4:\"name\";s:2:\"on\";}s:14:\"api_controller\";s:2:\"on\";s:12:\"api_paginate\";s:2:\"on\";s:10:\"api_openid\";s:6:\"openid\";s:16:\"admin_controller\";s:2:\"on\";s:14:\"admin_paginate\";s:2:\"on\";s:10:\"admin_view\";s:2:\"on\";s:10:\"admin_menu\";s:2:\"on\";s:10:\"index_find\";s:2:\"on\";s:9:\"parent_id\";s:3:\"206\";s:4:\"name\";s:12:\"答题结果\";s:3:\"app\";s:5:\"admin\";s:6:\"action\";s:5:\"index\";s:5:\"param\";s:0:\"\";s:4:\"icon\";s:0:\"\";s:6:\"remark\";s:0:\"\";s:6:\"status\";s:1:\"1\";s:4:\"type\";s:1:\"1\";s:7:\"_plugin\";s:4:\"form\";s:11:\"_controller\";s:10:\"AdminIndex\";s:7:\"_action\";s:11:\"settingPost\";}","1","");
INSERT INTO cmf_base_form_model VALUES("35","http://answer.ikun/plugin/form/AdminIndex/settingPost","2","表名:answer_result  -------  控制器(tags):答题结果");
INSERT INTO cmf_base_form_model VALUES("36","https://dzkf382.aejust.com/plugin/form/AdminIndex/settingPost","2","表名:answer_result  -------  控制器(tags):答题结果");
INSERT INTO cmf_base_form_model VALUES("37","a:24:{s:10:\"table_name\";s:12:\"answer_wrong\";s:10:\"model_name\";s:11:\"AnswerWrong\";s:4:\"tags\";s:12:\"错题记录\";s:7:\"keyword\";a:1:{s:4:\"name\";s:2:\"on\";}s:14:\"api_controller\";s:2:\"on\";s:12:\"api_paginate\";s:2:\"on\";s:10:\"api_openid\";s:6:\"openid\";s:16:\"admin_controller\";s:2:\"on\";s:14:\"admin_paginate\";s:2:\"on\";s:10:\"admin_view\";s:2:\"on\";s:10:\"admin_menu\";s:2:\"on\";s:10:\"index_find\";s:2:\"on\";s:9:\"parent_id\";s:3:\"206\";s:4:\"name\";s:12:\"错题记录\";s:3:\"app\";s:5:\"admin\";s:6:\"action\";s:5:\"index\";s:5:\"param\";s:0:\"\";s:4:\"icon\";s:0:\"\";s:6:\"remark\";s:0:\"\";s:6:\"status\";s:1:\"1\";s:4:\"type\";s:1:\"1\";s:7:\"_plugin\";s:4:\"form\";s:11:\"_controller\";s:10:\"AdminIndex\";s:7:\"_action\";s:11:\"settingPost\";}","1","");
INSERT INTO cmf_base_form_model VALUES("38","http://answer.ikun/plugin/form/AdminIndex/settingPost","2","表名:answer_wrong  -------  控制器(tags):错题记录");
INSERT INTO cmf_base_form_model VALUES("39","https://dzkf382.aejust.com/plugin/form/AdminIndex/settingPost","2","表名:answer_wrong  -------  控制器(tags):错题记录");



DROP TABLE cmf_base_leave;

CREATE TABLE `cmf_base_leave` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL COMMENT '用户',
  `username` varchar(255) DEFAULT NULL COMMENT '联系人',
  `phone` varchar(255) DEFAULT NULL COMMENT '手机号',
  `title` varchar(255) DEFAULT NULL COMMENT '标题',
  `content` varchar(2555) DEFAULT NULL COMMENT '留言内容',
  `images` text COMMENT '图集',
  `reply_content` varchar(255) DEFAULT NULL COMMENT '回复内容',
  `reply_time` bigint(20) DEFAULT NULL COMMENT '回复时间',
  `create_time` bigint(20) DEFAULT '0' COMMENT '创建时间',
  `update_time` bigint(20) DEFAULT NULL COMMENT '更新时间',
  `delete_time` bigint(20) DEFAULT '0' COMMENT '删除时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='投诉建议';




DROP TABLE cmf_base_order_pay;

CREATE TABLE `cmf_base_order_pay` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `openid` varchar(255) DEFAULT NULL COMMENT 'openid',
  `order_type` int(5) DEFAULT '1' COMMENT '订单类型:',
  `pay_type` tinyint(4) DEFAULT '1' COMMENT '支付类型:1微信支付,2余额支付,3积分支付,4支付宝支付',
  `order_num` varchar(255) DEFAULT NULL COMMENT '关联订单号',
  `pay_num` varchar(255) DEFAULT NULL COMMENT '发起支付单号',
  `trade_num` varchar(255) DEFAULT NULL COMMENT '第三方返回单号',
  `amount` decimal(10,2) DEFAULT NULL COMMENT '支付金额',
  `notify` text COMMENT '回调信息',
  `status` int(2) DEFAULT '1' COMMENT '支付状态:1未支付,2已支付',
  `pay_time` bigint(20) DEFAULT NULL COMMENT '支付时间',
  `create_time` bigint(20) DEFAULT NULL COMMENT '创建时间',
  `update_time` bigint(20) DEFAULT NULL COMMENT '更新时间',
  `delete_time` bigint(20) DEFAULT '0' COMMENT '删除时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8 COMMENT='支付管理';

INSERT INTO cmf_base_order_pay VALUES("1","","1","0","240508609700658392","31024050860970112603927","","0.00","","1","0","1715160970","0","0");
INSERT INTO cmf_base_order_pay VALUES("2","","1","1","2407039409479192025407","31024070394094793940704","","0.01","","1","","1719994094","","0");
INSERT INTO cmf_base_order_pay VALUES("3","","1","1","2407039412127888334409","31024070394121280912055","","0.01","","1","","1719994121","","0");
INSERT INTO cmf_base_order_pay VALUES("4","","1","1","2407039412239917041783","31024070394122401004018","","0.01","","1","","1719994122","","0");
INSERT INTO cmf_base_order_pay VALUES("5","","1","1","2407039412325082355093","31024070394123252743316","","0.01","","1","","1719994123","","0");
INSERT INTO cmf_base_order_pay VALUES("6","","1","1","2407039412396916192002","31024070394123971140129","","0.01","","1","","1719994123","","0");
INSERT INTO cmf_base_order_pay VALUES("7","","1","1","2407039412725289652572","31024070394127254981746","","0.01","","1","","1719994127","","0");
INSERT INTO cmf_base_order_pay VALUES("8","","1","1","2407039414803170067535","31024070394148033586767","","0.01","","1","","1719994148","","0");
INSERT INTO cmf_base_order_pay VALUES("9","","1","1","2407039414897335091781","31024070394148975378756","","0.01","","1","","1719994148","","0");
INSERT INTO cmf_base_order_pay VALUES("10","","1","1","2407039455164451848133","31024070394551646483109","","0.01","","1","","1719994551","","0");
INSERT INTO cmf_base_order_pay VALUES("11","","1","1","2407039455406511393314","31024070394554067017298","","0.01","","1","","1719994554","","0");
INSERT INTO cmf_base_order_pay VALUES("12","","1","1","2407039470629075443774","31024070394706292689417","","0.01","","1","","1719994706","","0");
INSERT INTO cmf_base_order_pay VALUES("13","","1","1","2407039509023785184582","31024070395090239837236","","0.01","","1","","1719995090","","0");
INSERT INTO cmf_base_order_pay VALUES("14","","1","1","2407039509961503896333","31024070395099616995084","","0.01","","1","","1719995099","","0");
INSERT INTO cmf_base_order_pay VALUES("15","","1","1","2407039510746982854494","31024070395107471836687","","0.01","","1","","1719995107","","0");
INSERT INTO cmf_base_order_pay VALUES("16","","1","1","2407039514252680384637","31024070395142528799141","","0.01","","1","","1719995142","","0");
INSERT INTO cmf_base_order_pay VALUES("17","","1","1","2407039514414642945026","31024070395144148467143","","0.01","","1","","1719995144","","0");
INSERT INTO cmf_base_order_pay VALUES("18","","1","1","2407039515611068350519","31024070395156112602058","","0.01","","1","","1719995156","","0");
INSERT INTO cmf_base_order_pay VALUES("19","","1","1","2407039519030014244300","31024070395190302155660","","0.01","","1","","1719995190","","0");
INSERT INTO cmf_base_order_pay VALUES("20","","1","1","2407039519199700883809","31024070395191999007047","","0.01","","1","","1719995191","","0");
INSERT INTO cmf_base_order_pay VALUES("21","","1","1","2407039520505382242462","31024070395205055849654","","0.01","","1","","1719995205","","0");
INSERT INTO cmf_base_order_pay VALUES("22","","1","1","2407039521206280708856","31024070395212064740245","","0.01","","1","","1719995212","","0");
INSERT INTO cmf_base_order_pay VALUES("23","","1","1","2407039521902201205117","31024070395219024136783","","0.01","","1","","1719995219","","0");
INSERT INTO cmf_base_order_pay VALUES("24","","1","1","2407039530673552089695","31024070395306737521595","","0.01","","1","","1719995306","","0");
INSERT INTO cmf_base_order_pay VALUES("25","","1","1","2407039531463830132279","31024070395314640201390","","0.01","","1","","1719995314","","0");
INSERT INTO cmf_base_order_pay VALUES("26","","1","1","2407039547694793644178","31024070395476949865386","","0.01","","1","","1719995476","","0");
INSERT INTO cmf_base_order_pay VALUES("27","","1","1","2407039549721031216111","31024070395497212263976","","0.01","","1","","1719995497","","0");
INSERT INTO cmf_base_order_pay VALUES("28","","1","1","2407039550432606957428","31024070395504327926136","","0.01","","1","","1719995504","","0");
INSERT INTO cmf_base_order_pay VALUES("29","","1","1","2407039555828692941317","31024070395558288970794","","0.01","","1","","1719995558","","0");
INSERT INTO cmf_base_order_pay VALUES("30","","1","1","2407039556342573069662","31024070395563427709367","","0.01","","1","","1719995563","","0");
INSERT INTO cmf_base_order_pay VALUES("31","","1","1","2407039556765905672834","31024070395567661180788","","0.01","","1","","1719995567","","0");
INSERT INTO cmf_base_order_pay VALUES("32","","1","1","2407039556905436149503","31024070395569056423300","","0.01","","1","","1719995569","","0");
INSERT INTO cmf_base_order_pay VALUES("33","","1","1","2407039577459313796364","31024070395774595062620","","0.01","","1","","1719995774","","0");



DROP TABLE cmf_base_point;

CREATE TABLE `cmf_base_point` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `identity_type` varchar(255) DEFAULT 'member' COMMENT '身份类型',
  `type` tinyint(6) DEFAULT NULL COMMENT '类型:1=收入,2=支出',
  `price` decimal(10,2) DEFAULT NULL COMMENT '变动金额',
  `before` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '变更前',
  `after` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '变更后',
  `content` varchar(50) DEFAULT NULL COMMENT '变动说明',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注',
  `order_type` int(11) DEFAULT '0' COMMENT '订单类型 ',
  `order_num` varchar(100) DEFAULT NULL COMMENT '订单单号',
  `order_id` int(11) DEFAULT '0' COMMENT '订单ID',
  `create_time` bigint(20) DEFAULT NULL COMMENT '创建时间',
  `update_time` bigint(20) DEFAULT NULL COMMENT '更新时间',
  `delete_time` bigint(20) DEFAULT '0' COMMENT '删除时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COMMENT='会员—积分';

INSERT INTO cmf_base_point VALUES("1","1","member","1","100.00","0.00","100.00","测试100","操作人[1-admin];操作说明[测试100];操作类型[增加用户积分];","100","2409041896418828807996","0","1725418964","","0");
INSERT INTO cmf_base_point VALUES("2","1","member","2","50.00","100.00","50.00","测试-50","操作人[1-admin];操作说明[测试-50];操作类型[扣除用户积分];","100","2409041898488034189434","0","1725418984","","0");
INSERT INTO cmf_base_point VALUES("3","1","member","1","10.00","50.00","60.00","测试10","操作人[1-admin];操作说明[测试10];操作类型[增加用户积分];","100","2409042040452325101999","0","1725420404","","0");
INSERT INTO cmf_base_point VALUES("4","1","member","2","10.00","60.00","50.00","测试-10","操作人[1-admin];操作说明[测试-10];操作类型[扣除用户积分];","100","2409042041623647613974","0","1725420416","","0");



CREATE TABLE `cmf_base_test` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `a_image` varchar(255) DEFAULT NULL,
  `images` text,
  `a_images` text,
  `file` varchar(255) DEFAULT NULL,
  `a_file` varchar(255) DEFAULT NULL,
  `video` varchar(255) DEFAULT NULL,
  `a_video` varchar(255) DEFAULT NULL,
  `is_index` tinyint(4) DEFAULT '1' COMMENT '首页推荐:1是,2否',
  `type` tinyint(4) DEFAULT '1' COMMENT '类型:1普通商品,2抢购商品,3拼团商品',
  `is_pay` tinyint(4) DEFAULT '1' COMMENT '支付:1是,2否',
  `content` text,
  `introduce` varchar(255) DEFAULT NULL COMMENT '介绍',
  `pay_type` tinyint(4) DEFAULT '1' COMMENT '支付类型:1微信,2余额,3支付宝',
  `status` tinyint(4) DEFAULT '1' COMMENT '状态:1审核中,2已通过,3已拒绝',
  `refuse` varchar(255) DEFAULT NULL COMMENT '拒绝理由',
  `cancel_time` bigint(20) DEFAULT NULL COMMENT '取消时间',
  `pass_time` bigint(20) DEFAULT NULL COMMENT '通过时间',
  `refuse_time` bigint(20) DEFAULT NULL COMMENT '拒绝时间',
  `reply` varchar(255) DEFAULT NULL COMMENT '回复内容',
  `reply_time` bigint(20) DEFAULT NULL COMMENT '回复时间',
  `create_time` bigint(20) DEFAULT NULL COMMENT '创建时间',
  `update_time` bigint(20) DEFAULT NULL COMMENT '更新时间',
  `delete_time` bigint(20) DEFAULT '0' COMMENT '删除时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;

DROP TABLE cmf_base_withdrawal;

CREATE TABLE `cmf_base_withdrawal` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL COMMENT '用户信息',
  `identity_type` varchar(255) DEFAULT 'member' COMMENT '身份类型',
  `type` tinyint(2) DEFAULT '1' COMMENT '提现类型:1支付宝,2微信',
  `openid` varchar(120) DEFAULT NULL COMMENT 'openid',
  `price` decimal(10,2) DEFAULT NULL COMMENT '提现金额',
  `status` tinyint(2) DEFAULT '1' COMMENT '状态:1待审核,2已审核,3已拒绝',
  `refuse` varchar(50) DEFAULT '' COMMENT '拒绝原因',
  `charges` decimal(10,2) DEFAULT '0.00' COMMENT '手续费',
  `ali_username` varchar(25) DEFAULT NULL COMMENT '支付宝用户名字',
  `ali_account` varchar(25) DEFAULT NULL COMMENT '支付宝账号',
  `order_num` varchar(100) DEFAULT NULL COMMENT '订单号',
  `create_time` bigint(20) DEFAULT NULL COMMENT '创建时间',
  `update_time` bigint(20) DEFAULT NULL COMMENT '更新时间',
  `delete_time` bigint(20) DEFAULT '0' COMMENT '删除时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='会员提现申请';




DROP TABLE cmf_comment;

CREATE TABLE `cmf_comment` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '被回复的评论id',
  `user_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '发表评论的用户id',
  `to_user_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '被评论的用户id',
  `object_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '评论内容 id',
  `like_count` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '点赞数',
  `dislike_count` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '不喜欢数',
  `floor` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '楼层数',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '评论时间',
  `delete_time` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '删除时间',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '状态,1:已审核,0:未审核',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '评论类型；1实名评论',
  `table_name` varchar(64) NOT NULL DEFAULT '' COMMENT '评论内容所在表，不带表前缀',
  `full_name` varchar(50) NOT NULL DEFAULT '' COMMENT '评论者昵称',
  `email` varchar(255) NOT NULL DEFAULT '' COMMENT '评论者邮箱',
  `path` varchar(255) NOT NULL DEFAULT '' COMMENT '层级关系',
  `url` text COMMENT '原文地址',
  `content` text CHARACTER SET utf8mb4 COMMENT '评论内容',
  `more` text CHARACTER SET utf8mb4 COMMENT '扩展属性',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `table_id_status` (`table_name`,`object_id`,`status`) USING BTREE,
  KEY `object_id` (`object_id`) USING BTREE,
  KEY `status` (`status`) USING BTREE,
  KEY `parent_id` (`parent_id`) USING BTREE,
  KEY `create_time` (`create_time`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='评论表';




DROP TABLE cmf_hook;

CREATE TABLE `cmf_hook` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '钩子类型(1:系统钩子;2:应用钩子;3:模板钩子;4:后台模板钩子)',
  `once` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '是否只允许一个插件运行(0:多个;1:一个)',
  `name` varchar(50) NOT NULL DEFAULT '' COMMENT '钩子名称',
  `hook` varchar(50) NOT NULL DEFAULT '' COMMENT '钩子',
  `app` varchar(15) NOT NULL DEFAULT '' COMMENT '应用名(只有应用钩子才用)',
  `description` varchar(255) NOT NULL DEFAULT '' COMMENT '描述',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=72 DEFAULT CHARSET=utf8mb4 COMMENT='系统钩子表';

INSERT INTO cmf_hook VALUES("2","1","0","应用开始","app_begin","cmf","应用开始");
INSERT INTO cmf_hook VALUES("3","1","0","模块初始化","module_init","cmf","模块初始化");
INSERT INTO cmf_hook VALUES("4","1","0","控制器开始","action_begin","cmf","控制器开始");
INSERT INTO cmf_hook VALUES("5","1","0","视图输出过滤","view_filter","cmf","视图输出过滤");
INSERT INTO cmf_hook VALUES("6","1","0","应用结束","app_end","cmf","应用结束");
INSERT INTO cmf_hook VALUES("7","1","0","日志write方法","log_write","cmf","日志write方法");
INSERT INTO cmf_hook VALUES("8","1","0","输出结束","response_end","cmf","输出结束");
INSERT INTO cmf_hook VALUES("9","1","0","后台控制器初始化","admin_init","cmf","后台控制器初始化");
INSERT INTO cmf_hook VALUES("10","1","0","前台控制器初始化","home_init","cmf","前台控制器初始化");
INSERT INTO cmf_hook VALUES("11","1","1","发送手机验证码","send_mobile_verification_code","cmf","发送手机验证码");
INSERT INTO cmf_hook VALUES("12","3","0","模板 body标签开始","body_start","","模板 body标签开始");
INSERT INTO cmf_hook VALUES("13","3","0","模板 head标签结束前","before_head_end","","模板 head标签结束前");
INSERT INTO cmf_hook VALUES("14","3","0","模板底部开始","footer_start","","模板底部开始");
INSERT INTO cmf_hook VALUES("15","3","0","模板底部开始之前","before_footer","","模板底部开始之前");
INSERT INTO cmf_hook VALUES("16","3","0","模板底部结束之前","before_footer_end","","模板底部结束之前");
INSERT INTO cmf_hook VALUES("17","3","0","模板 body 标签结束之前","before_body_end","","模板 body 标签结束之前");
INSERT INTO cmf_hook VALUES("18","3","0","模板左边栏开始","left_sidebar_start","","模板左边栏开始");
INSERT INTO cmf_hook VALUES("19","3","0","模板左边栏结束之前","before_left_sidebar_end","","模板左边栏结束之前");
INSERT INTO cmf_hook VALUES("20","3","0","模板右边栏开始","right_sidebar_start","","模板右边栏开始");
INSERT INTO cmf_hook VALUES("21","3","0","模板右边栏结束之前","before_right_sidebar_end","","模板右边栏结束之前");
INSERT INTO cmf_hook VALUES("22","3","1","评论区","comment","","评论区");
INSERT INTO cmf_hook VALUES("23","3","1","留言区","guestbook","","留言区");
INSERT INTO cmf_hook VALUES("24","2","0","后台首页仪表盘","admin_dashboard","admin","后台首页仪表盘");
INSERT INTO cmf_hook VALUES("25","4","0","后台模板 head标签结束前","admin_before_head_end","","后台模板 head标签结束前");
INSERT INTO cmf_hook VALUES("26","4","0","后台模板 body 标签结束之前","admin_before_body_end","","后台模板 body 标签结束之前");
INSERT INTO cmf_hook VALUES("27","2","0","后台登录页面","admin_login","admin","后台登录页面");
INSERT INTO cmf_hook VALUES("28","1","1","前台模板切换","switch_theme","cmf","前台模板切换");
INSERT INTO cmf_hook VALUES("29","3","0","主要内容之后","after_content","","主要内容之后");
INSERT INTO cmf_hook VALUES("32","2","1","获取上传界面","fetch_upload_view","user","获取上传界面");
INSERT INTO cmf_hook VALUES("33","3","0","主要内容之前","before_content","cmf","主要内容之前");
INSERT INTO cmf_hook VALUES("34","1","0","日志写入完成","log_write_done","cmf","日志写入完成");
INSERT INTO cmf_hook VALUES("35","1","1","后台模板切换","switch_admin_theme","cmf","后台模板切换");
INSERT INTO cmf_hook VALUES("36","1","1","验证码图片","captcha_image","cmf","验证码图片");
INSERT INTO cmf_hook VALUES("37","2","1","后台模板设计界面","admin_theme_design_view","admin","后台模板设计界面");
INSERT INTO cmf_hook VALUES("38","2","1","后台设置网站信息界面","admin_setting_site_view","admin","后台设置网站信息界面");
INSERT INTO cmf_hook VALUES("39","2","1","后台清除缓存界面","admin_setting_clear_cache_view","admin","后台清除缓存界面");
INSERT INTO cmf_hook VALUES("40","2","1","后台导航管理界面","admin_nav_index_view","admin","后台导航管理界面");
INSERT INTO cmf_hook VALUES("41","2","1","后台友情链接管理界面","admin_link_index_view","admin","后台友情链接管理界面");
INSERT INTO cmf_hook VALUES("42","2","1","后台幻灯片管理界面","admin_slide_index_view","admin","后台幻灯片管理界面");
INSERT INTO cmf_hook VALUES("43","2","1","后台管理员列表界面","admin_user_index_view","admin","后台管理员列表界面");
INSERT INTO cmf_hook VALUES("44","2","1","后台角色管理界面","admin_rbac_index_view","admin","后台角色管理界面");
INSERT INTO cmf_hook VALUES("49","2","1","用户管理本站用户列表界面","user_admin_index_view","user","用户管理本站用户列表界面");
INSERT INTO cmf_hook VALUES("50","2","1","资源管理列表界面","user_admin_asset_index_view","user","资源管理列表界面");
INSERT INTO cmf_hook VALUES("51","2","1","用户管理第三方用户列表界面","user_admin_oauth_index_view","user","用户管理第三方用户列表界面");
INSERT INTO cmf_hook VALUES("52","2","1","后台首页界面","admin_index_index_view","admin","后台首页界面");
INSERT INTO cmf_hook VALUES("53","2","1","后台回收站界面","admin_recycle_bin_index_view","admin","后台回收站界面");
INSERT INTO cmf_hook VALUES("54","2","1","后台菜单管理界面","admin_menu_index_view","admin","后台菜单管理界面");
INSERT INTO cmf_hook VALUES("55","2","1","后台自定义登录是否开启钩子","admin_custom_login_open","admin","后台自定义登录是否开启钩子");
INSERT INTO cmf_hook VALUES("64","2","1","后台幻灯片页面列表界面","admin_slide_item_index_view","admin","后台幻灯片页面列表界面");
INSERT INTO cmf_hook VALUES("65","2","1","后台幻灯片页面添加界面","admin_slide_item_add_view","admin","后台幻灯片页面添加界面");
INSERT INTO cmf_hook VALUES("66","2","1","后台幻灯片页面编辑界面","admin_slide_item_edit_view","admin","后台幻灯片页面编辑界面");
INSERT INTO cmf_hook VALUES("67","2","1","后台管理员添加界面","admin_user_add_view","admin","后台管理员添加界面");
INSERT INTO cmf_hook VALUES("68","2","1","后台管理员编辑界面","admin_user_edit_view","admin","后台管理员编辑界面");
INSERT INTO cmf_hook VALUES("69","2","1","后台角色添加界面","admin_rbac_role_add_view","admin","后台角色添加界面");
INSERT INTO cmf_hook VALUES("70","2","1","后台角色编辑界面","admin_rbac_role_edit_view","admin","后台角色编辑界面");
INSERT INTO cmf_hook VALUES("71","2","1","后台角色授权界面","admin_rbac_authorize_view","admin","后台角色授权界面");



DROP TABLE cmf_hook_plugin;

CREATE TABLE `cmf_hook_plugin` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `list_order` float NOT NULL DEFAULT '10000' COMMENT '排序',
  `status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '状态(0:禁用,1:启用)',
  `hook` varchar(50) NOT NULL DEFAULT '' COMMENT '钩子名',
  `plugin` varchar(50) NOT NULL DEFAULT '' COMMENT '插件',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COMMENT='系统钩子插件表';

INSERT INTO cmf_hook_plugin VALUES("2","10000","1","app_begin","Configs");
INSERT INTO cmf_hook_plugin VALUES("3","10000","1","fetch_upload_view","Oss");
INSERT INTO cmf_hook_plugin VALUES("4","10000","1","admin_init","AdminJournal");
INSERT INTO cmf_hook_plugin VALUES("5","10000","1","admin_login","FengiyLogin");



DROP TABLE cmf_member;

CREATE TABLE `cmf_member` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nickname` varchar(30) DEFAULT NULL COMMENT '昵称',
  `avatar` varchar(200) DEFAULT NULL COMMENT '头像',
  `openid` varchar(80) DEFAULT NULL COMMENT 'openid',
  `phone` varchar(15) DEFAULT NULL COMMENT '手机号',
  `pass` varchar(100) DEFAULT NULL COMMENT '密码',
  `balance` decimal(11,2) DEFAULT '0.00' COMMENT '余额',
  `point` decimal(11,2) DEFAULT '0.00' COMMENT '积分',
  `ip` varchar(255) DEFAULT NULL COMMENT '登录ip地址',
  `login_time` bigint(20) DEFAULT NULL COMMENT '最后登录时间',
  `login_city` varchar(255) DEFAULT NULL COMMENT '登录城市',
  `create_time` bigint(20) DEFAULT NULL COMMENT '创建时间',
  `update_time` bigint(20) DEFAULT NULL COMMENT '更新时间',
  `delete_time` bigint(20) DEFAULT '0' COMMENT '删除时间',
  `invite_code` varchar(255) DEFAULT NULL COMMENT '邀请码',
  `pid` int(11) DEFAULT NULL COMMENT '上级',
  `unit` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COMMENT='用户表';

INSERT INTO cmf_member VALUES("1","Ctrl","https://oss.ausite.cn/dz000/default/20230602/8fb025339dcafcb3e2f9e34f862e1976.png","1","1","1","50.00","50.00","","0","","1685676913","1712127137","0","","0","");
INSERT INTO cmf_member VALUES("2","Dᴇʟɪʙᴇʀᴀᴛᴇʟʏ .","dzkf382/default/20241022/2ec5a0352f7813c8f20465915026d957.jpg","oZ-l86Owj57JzU5rUecIqzaNKjgg","17613851580","","0.00","0.00","123.14.172.192","1729474419","郑州市","1728634934","1729580184","0","SL7OV50rI9D4tZR77MnX","0","单位");
INSERT INTO cmf_member VALUES("3","开发组售后小郭","dzkf382/default/20241024/73ba19478df9ae1cf763cba8dc1707d3.jpg","oZ-l86LATw3dAAg8JzN6W3b00bko","13333333333","","0.00","0.00","202.110.95.238","1729477310","平顶山市","1729477310","1729739846","0","SCF95k5NpK42cFPAIzm7","0","开发部");
INSERT INTO cmf_member VALUES("4","梅","https://thirdwx.qlogo.cn/mmopen/vi_32/ricV7H8iayA8ebnqL71obqpNl1oICYrDpAZTOMUgrh5wo103cKjKP1PpjVb3CQDazYY2XmicpibOJLKGqGqWXlzfgZRKgnvq1u98U4YmxDYwWVU/132","oZ-l86D4Zdy9cSPnVYmVCSkw3Vb4","","","0.00","0.00","182.118.238.63","1729741515","","1729741515","","0","wigYC6OpjRedW0MudlGa","0","");
INSERT INTO cmf_member VALUES("5","扬仔","https://thirdwx.qlogo.cn/mmopen/vi_32/Ee3rJFn8tPylTzxbg4aQQiakhX9bgSry5EGhC001eYRCLIzW4S1eh8IEnBUZVwuICy4mjPkMFBGs6ayXVcRdX9kfCcB95OBpQPPCnOiahgDoU/132","oZ-l86LIkLhBV-jDm7cv3NhkW4GI","","","0.00","0.00","113.248.218.136","1730087320","","1730087320","","0","sjXjVXjaNGa8tnmXq594","0","");



DROP TABLE cmf_member_gzh;

CREATE TABLE `cmf_member_gzh` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `openid` varchar(80) DEFAULT NULL COMMENT 'openid',
  `unionid` varchar(255) DEFAULT NULL COMMENT 'unionId',
  `ext` text CHARACTER SET utf8 COMMENT '扩展信息',
  `create_time` bigint(20) DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='公众号用户';




DROP TABLE cmf_option;

CREATE TABLE `cmf_option` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `autoload` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '是否自动加载;1:自动加载;0:不自动加载',
  `option_name` varchar(64) NOT NULL DEFAULT '' COMMENT '配置名',
  `option_value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '配置值',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `option_name` (`option_name`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COMMENT='全站配置表';

INSERT INTO cmf_option VALUES("1","1","site_info","{\"site_name\":\"微巨宝定制后台模板\",\"site_seo_title\":\"微巨宝定制后台模板\",\"site_seo_keywords\":\"\",\"site_seo_description\":\"\"}");
INSERT INTO cmf_option VALUES("2","1","set_config","{\"app_name\":\"渝辐科技\",\"app_logo\":\"dzkf382\\/default\\/20241008\\/d993653cf8d15bb29c6ddfe078f41a59.png\",\"user_agreement\":\"&lt;p&gt;用户协议&lt;\\/p&gt;\",\"privacy_agreement\":\"&lt;p&gt;&lt;span style=&quot;color: rgba(0, 0, 0, 0.85); font-family: &amp;quot;Helvetica Neue&amp;quot;, Helvetica, &amp;quot;PingFang SC&amp;quot;, Tahoma, Arial, sans-serif; font-size: 14px; font-weight: 700; text-align: right; background-color: rgb(255, 255, 255);&quot;&gt;隐私协议&lt;\\/span&gt;&lt;\\/p&gt;\",\"group_id\":\"200\",\"app_logo_1\":\"https:\\/\\/oss.ausite.cn\\/dz000\\/default\\/20230217\\/2680011108c19b50228c124d86749b7d.jpg?watermark\",\"_plugin\":\"configs\",\"_controller\":\"admin_index\",\"_action\":\"index\",\"test\":\"df4w4e8f7e\\/sd4fds4f6sdf\\/4dsf4wef4we\\/sd44fwe54fwe8\\/4f5esf45wef45we\\/4f5we4f5we45ds\\/x4c5f45we7f45weg4e\\/4g5re7hh84r8h4er8\\/h45qwe84f5r\\/4g5w4g8we\\/4s545wef5ew4\",\"domain_name\":\"https:\\/\\/dzkf382.aejust.com\",\"s\":[\"sdfwe\",\"sfwaweew\"],\"f\":[\"fawefewfawefwe\"],\"debug_mode\":\"1\",\"app_expiration_time\":\"2042-02-28 00:00\",\"listorder\":{\"100\":\"1\",\"101\":\"2\",\"108\":\"100\"},\"label\":{\"137\":\"程序信息\"},\"name\":{\"137\":\"program_information\"},\"about\":{\"137\":\"\"},\"project_name\":\"管题公众号\",\"copyright\":\"技术支持：微巨宝科技有限公司\",\"local_domain_name\":\"http:\\/\\/answer.ikun\",\"number_of_days_for_log_files\":\"\",\"log_file_days\":\"10\",\"list_order\":{\"137\":\"100\",\"138\":\"200\"},\"video\":\"dzkf00000000001\\/default\\/20240624\\/c2dcc94117717aaad3d7d9664c2affcb.mp4\",\"file2\":\"dzkf00000000001\\/default\\/20240624\\/2cec82e71890d9b59a689e8a869c544e.docx\",\"video2\":\"dzkf00000000001\\/default\\/20240624\\/ab75196b4f0f699eb563758d59e662ca.mp4\",\"file333\":\"dzkf00000000001\\/default\\/20240624\\/9fff193bb6acaead8c8523bea7a76ad6.pdf\",\"program_information\":\"答题公众号-xww1989129\",\"program_code\":\"dzkf382\\/default\\/20241016\\/10b72558bbf1d6ae0739b0ef4bf0bc1b.jpg\"}");
INSERT INTO cmf_option VALUES("3","1","storage","{\"storages\":{\"Oss\":{\"name\":\"阿里云OSS存储\",\"driver\":\"\\\\plugins\\\\oss\\\\lib\\\\Oss\"}},\"type\":\"Oss\"}");
INSERT INTO cmf_option VALUES("4","1","weipay","{\"wx_mp_app_id\":\"wx1821109f3501db59\",\"wx_mini_app_id\":\"\",\"wx_mp_app_secret\":\"cd47628bee95bca073277292e5675b0f\",\"wx_mini_app_secret\":\"\",\"wx_token\":\"\",\"wx_encodingaeskey\":\"\",\"wx_app_id\":\"\",\"wx_mch_id\":\"\",\"wx_v2_mch_secret_key\":\"Qwertyuiopasdfghjklzxcvbnm123456\",\"wx_v3_mch_secret_key\":\"Qwertyuiopasdfghjklzxcvbnm123456\",\"wx_mch_secret_cert\":\"\",\"wx_mch_public_cert_path\":\"\",\"wx_notify_url\":\"\\/api\\/wxapp\\/notify\\/wxPayNotify\",\"ali_app_id\":\"\",\"ali_app_secret_cert\":\"\",\"ali_app_public_cert_path\":\"\",\"ali_alipay_public_cert_path\":\"\",\"ali_alipay_root_cert_path\":\"\",\"ali_notify_url\":\"\",\"ali_return_url\":\"\",\"wx_system_type\":\"wx_mp\"}");
INSERT INTO cmf_option VALUES("5","1","upload_setting","{\"max_files\":\"20\",\"chunk_size\":\"512\",\"file_types\":{\"image\":{\"upload_max_filesize\":\"15360\",\"extensions\":\"jpg,jpeg,png,gif,bmp4,mp3\"},\"video\":{\"upload_max_filesize\":\"15360\",\"extensions\":\"mp4,avi,wmv,rm,rmvb,mkv\"},\"audio\":{\"upload_max_filesize\":\"15360\",\"extensions\":\"mp3,wma,wav\"},\"file\":{\"upload_max_filesize\":\"15360\",\"extensions\":\"txt,pdf,doc,docx,xls,xlsx,ppt,pptx,zip,rar,pem\"}}}");



DROP TABLE cmf_plugin;

CREATE TABLE `cmf_plugin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '自增id',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '插件类型;1:网站;8:微信',
  `has_admin` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '是否有后台管理,0:没有;1:有',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '状态;1:开启;0:禁用',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '插件安装时间',
  `name` varchar(50) NOT NULL DEFAULT '' COMMENT '插件标识名,英文字母(惟一)',
  `title` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '插件名称',
  `demo_url` varchar(50) NOT NULL DEFAULT '' COMMENT '演示地址，带协议',
  `hooks` varchar(255) NOT NULL DEFAULT '' COMMENT '实现的钩子;以“,”分隔',
  `author` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '插件作者',
  `author_url` varchar(50) NOT NULL DEFAULT '' COMMENT '作者网站链接',
  `version` varchar(20) NOT NULL DEFAULT '' COMMENT '插件版本号',
  `description` varchar(255) NOT NULL COMMENT '插件描述',
  `config` text COMMENT '插件配置',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COMMENT='插件表';

INSERT INTO cmf_plugin VALUES("1","1","1","1","1660558216","Weipay","APP信息&支付信息","","","wjb","","1.0.0","微信小程序&公众号&支付宝支付信息","[]");
INSERT INTO cmf_plugin VALUES("2","1","1","1","1660558220","Swagger","Swagger","http://demo.thinkcmf.com","","ThinkCMF","http://www.thinkcmf.com","1.0.0","Swagger","[]");
INSERT INTO cmf_plugin VALUES("4","1","1","1","1660723183","Configs","系统参数设置","","","lampzww","","1.0","config读取配置参数扩展","[]");
INSERT INTO cmf_plugin VALUES("6","1","0","1","1660723194","Oss","OSS上传","","","zsl","","1.0.0","OSS上传","{\"accessKey\":\"LTAI5t9uSAQt9GiYcZ7X34Xe\",\"secretKey\":\"4zgCseVv6ufMsAu2oP1BoK5SFoGOi3\",\"protocol\":\"https\",\"domain\":\"oss.ausite.cn\",\"bucket\":\"twjbdzoss\",\"style_separator\":\"?\",\"dir\":\"dzkf382\"}");
INSERT INTO cmf_plugin VALUES("8","1","1","1","1660723805","Form","表单生成","http://demo.thinkcmf.com","","idcpj","http://www.thinkcmf.com","1.1","表单生成","{\"custom_config\":\"0\",\"text\":\"hello,ThinkCMF!\",\"password\":\"\",\"number\":\"1.0\",\"select\":\"1\",\"checkbox\":1,\"radio\":\"1\",\"radio2\":\"1\",\"textarea\":\"\\u8fd9\\u91cc\\u662f\\u4f60\\u8981\\u586b\\u5199\\u7684\\u5185\\u5bb9\",\"date\":\"2017-05-20\",\"datetime\":\"2017-05-20\",\"color\":\"#103633\",\"image\":\"\",\"file\":\"\",\"location\":\"\"}");
INSERT INTO cmf_plugin VALUES("9","1","1","1","1662171892","AdminJournal","操作日志","https://www.wzxaini9.cn/","","Powerless","https://www.wzxaini9.cn/","1.2.0","后台操作日志","[]");
INSERT INTO cmf_plugin VALUES("10","1","0","1","1670382358","FengiyLogin","微巨宝自定义登录页","","","Fengiy","","1.0","支持大背景/轮播图/Logo/名称自定义","{\"b_bg\":\"\",\"b_bg_illus\":\"\"}");
INSERT INTO cmf_plugin VALUES("11","1","1","1","1718330446","LoginTime","登陆状态时长控制","http://www.songzhenjiang.cn","","Tangchao","http://www.songzhenjiang.cn","1.0","登陆状态时长控制","[]");



DROP TABLE cmf_recycle_bin;

CREATE TABLE `cmf_recycle_bin` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `object_id` int(11) DEFAULT '0' COMMENT '删除内容 id',
  `create_time` int(10) unsigned DEFAULT '0' COMMENT '创建时间',
  `table_name` varchar(60) DEFAULT '' COMMENT '删除内容所在表名',
  `name` varchar(255) DEFAULT '' COMMENT '删除内容名称',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '用户id',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT=' 回收站';




DROP TABLE cmf_role;

CREATE TABLE `cmf_role` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '父角色ID',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '状态;0:禁用;1:正常',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `list_order` float NOT NULL DEFAULT '0' COMMENT '排序',
  `name` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '角色名称',
  `remark` varchar(255) NOT NULL DEFAULT '' COMMENT '备注',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `parent_id` (`parent_id`) USING BTREE,
  KEY `status` (`status`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COMMENT='角色表';

INSERT INTO cmf_role VALUES("1","0","1","1329633709","1329633709","0","超级管理员","拥有网站最高管理员权限！");
INSERT INTO cmf_role VALUES("2","0","1","1329633709","1329633709","0","普通管理员","权限由最高管理员分配！");



DROP TABLE cmf_role_user;

CREATE TABLE `cmf_role_user` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `role_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '角色 id',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '用户id',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `role_id` (`role_id`) USING BTREE,
  KEY `user_id` (`user_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='用户角色对应表';

INSERT INTO cmf_role_user VALUES("1","2","2");



DROP TABLE cmf_route;

CREATE TABLE `cmf_route` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '路由id',
  `list_order` float NOT NULL DEFAULT '10000' COMMENT '排序',
  `status` tinyint(2) NOT NULL DEFAULT '1' COMMENT '状态;1:启用,0:不启用',
  `type` tinyint(4) NOT NULL DEFAULT '1' COMMENT 'URL规则类型;1:用户自定义;2:别名添加',
  `full_url` varchar(255) NOT NULL DEFAULT '' COMMENT '完整url',
  `url` varchar(255) NOT NULL DEFAULT '' COMMENT '实际显示的url',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='url路由表';




DROP TABLE cmf_slide;

CREATE TABLE `cmf_slide` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `status` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '状态,1:显示,0不显示',
  `delete_time` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '删除时间',
  `name` varchar(50) CHARACTER SET utf8 NOT NULL DEFAULT '' COMMENT '幻灯片分类',
  `remark` varchar(255) CHARACTER SET utf8 NOT NULL DEFAULT '' COMMENT '分类备注',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COMMENT='幻灯片表';

INSERT INTO cmf_slide VALUES("1","1","0","首页轮播图","首页轮播图[请勿删除]");



DROP TABLE cmf_slide_item;

CREATE TABLE `cmf_slide_item` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `slide_id` int(11) NOT NULL DEFAULT '0' COMMENT '幻灯片id',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '状态,1:显示;0:隐藏',
  `list_order` float NOT NULL DEFAULT '10000' COMMENT '排序',
  `title` varchar(50) NOT NULL DEFAULT '' COMMENT '幻灯片名称',
  `image` varchar(255) CHARACTER SET utf8 NOT NULL DEFAULT '' COMMENT '幻灯片图片',
  `url` varchar(255) CHARACTER SET utf8 NOT NULL DEFAULT '' COMMENT '幻灯片链接',
  `target` varchar(10) NOT NULL DEFAULT '' COMMENT '友情链接打开方式',
  `description` varchar(255) CHARACTER SET utf8 NOT NULL COMMENT '幻灯片描述',
  `content` text CHARACTER SET utf8 COMMENT '幻灯片内容',
  `more` text COMMENT '扩展信息',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `slide_id` (`slide_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COMMENT='幻灯片子项表';

INSERT INTO cmf_slide_item VALUES("1","1","1","1000","1","dz000/admin/20220928/f6eb31a4707d3e8705bce2402f331592.jpg","","_blank","","","");



DROP TABLE cmf_theme;

CREATE TABLE `cmf_theme` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '安装时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '最后升级时间',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '模板状态,1:正在使用;0:未使用',
  `is_compiled` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '是否为已编译模板',
  `theme` varchar(20) NOT NULL DEFAULT '' COMMENT '主题目录名，用于主题的维一标识',
  `name` varchar(20) NOT NULL DEFAULT '' COMMENT '主题名称',
  `version` varchar(20) NOT NULL DEFAULT '' COMMENT '主题版本号',
  `demo_url` varchar(50) NOT NULL DEFAULT '' COMMENT '演示地址，带协议',
  `thumbnail` varchar(100) NOT NULL DEFAULT '' COMMENT '缩略图',
  `author` varchar(20) NOT NULL DEFAULT '' COMMENT '主题作者',
  `author_url` varchar(50) NOT NULL DEFAULT '' COMMENT '作者网站链接',
  `lang` varchar(10) NOT NULL DEFAULT '' COMMENT '支持语言',
  `keywords` varchar(50) NOT NULL DEFAULT '' COMMENT '主题关键字',
  `description` varchar(100) NOT NULL DEFAULT '' COMMENT '主题描述',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='轮播图';

INSERT INTO cmf_theme VALUES("1","0","0","0","0","default","default","1.0.0","http://demo.thinkcmf.com","","ThinkCMF","http://www.thinkcmf.com","zh-cn","ThinkCMF默认模板","ThinkCMF默认模板");



DROP TABLE cmf_theme_file;

CREATE TABLE `cmf_theme_file` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `is_public` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否公共的模板文件',
  `list_order` float NOT NULL DEFAULT '10000' COMMENT '排序',
  `theme` varchar(20) NOT NULL DEFAULT '' COMMENT '模板名称',
  `name` varchar(20) NOT NULL DEFAULT '' COMMENT '模板文件名',
  `action` varchar(50) NOT NULL DEFAULT '' COMMENT '操作',
  `file` varchar(50) NOT NULL DEFAULT '' COMMENT '模板文件，相对于模板根目录，如Portal/index.html',
  `description` varchar(100) NOT NULL DEFAULT '' COMMENT '模板文件描述',
  `more` text COMMENT '模板更多配置,用户自己后台设置的',
  `config_more` text COMMENT '模板更多配置,来源模板的配置文件',
  `draft_more` text COMMENT '模板更多配置,用户临时保存的配置',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='轮播图,图片';

INSERT INTO cmf_theme_file VALUES("1","0","5","default","首页","demo/Index/index","demo/index","首页模板文件","{\"vars\":{\"top_slide\":{\"title\":\"\\u9876\\u90e8\\u5e7b\\u706f\\u7247\",\"value\":\"\",\"type\":\"text\",\"dataSource\":{\"api\":\"admin\\/Slide\\/index\",\"multi\":false},\"placeholder\":\"\\u8bf7\\u9009\\u62e9\\u9876\\u90e8\\u5e7b\\u706f\\u7247\",\"tip\":\"\\u9876\\u90e8\\u5e7b\\u706f\\u7247\",\"rule\":{\"require\":true}}},\"widgets\":{\"features\":{\"title\":\"\\u5feb\\u901f\\u4e86\\u89e3ThinkCMF\",\"display\":\"1\",\"vars\":{\"sub_title\":{\"title\":\"\\u526f\\u6807\\u9898\",\"value\":\"Quickly understand the ThinkCMF\",\"type\":\"text\",\"placeholder\":\"\\u8bf7\\u8f93\\u5165\\u526f\\u6807\\u9898\",\"tip\":\"\",\"rule\":{\"require\":true}},\"features\":{\"title\":\"\\u7279\\u6027\\u4ecb\\u7ecd\",\"value\":[{\"title\":\"MVC\\u5206\\u5c42\\u6a21\\u5f0f\",\"icon\":\"bars\",\"content\":\"\\u4f7f\\u7528MVC\\u5e94\\u7528\\u7a0b\\u5e8f\\u88ab\\u5206\\u6210\\u4e09\\u4e2a\\u6838\\u5fc3\\u90e8\\u4ef6\\uff1a\\u6a21\\u578b\\uff08M\\uff09\\u3001\\u89c6\\u56fe\\uff08V\\uff09\\u3001\\u63a7\\u5236\\u5668\\uff08C\\uff09\\uff0c\\u4ed6\\u4e0d\\u662f\\u4e00\\u4e2a\\u65b0\\u7684\\u6982\\u5ff5\\uff0c\\u53ea\\u662fThinkCMF\\u5c06\\u5176\\u53d1\\u6325\\u5230\\u4e86\\u6781\\u81f4\\u3002\"},{\"title\":\"\\u7528\\u6237\\u7ba1\\u7406\",\"icon\":\"group\",\"content\":\"ThinkCMF\\u5185\\u7f6e\\u4e86\\u7075\\u6d3b\\u7684\\u7528\\u6237\\u7ba1\\u7406\\u65b9\\u5f0f\\uff0c\\u5e76\\u53ef\\u76f4\\u63a5\\u4e0e\\u7b2c\\u4e09\\u65b9\\u7ad9\\u70b9\\u8fdb\\u884c\\u4e92\\u8054\\u4e92\\u901a\\uff0c\\u5982\\u679c\\u4f60\\u613f\\u610f\\u751a\\u81f3\\u53ef\\u4ee5\\u5bf9\\u5355\\u4e2a\\u7528\\u6237\\u6216\\u7fa4\\u4f53\\u7528\\u6237\\u7684\\u884c\\u4e3a\\u8fdb\\u884c\\u8bb0\\u5f55\\u53ca\\u5206\\u4eab\\uff0c\\u4e3a\\u60a8\\u7684\\u8fd0\\u8425\\u51b3\\u7b56\\u63d0\\u4f9b\\u6709\\u6548\\u53c2\\u8003\\u6570\\u636e\\u3002\"},{\"title\":\"\\u4e91\\u7aef\\u90e8\\u7f72\",\"icon\":\"cloud\",\"content\":\"\\u901a\\u8fc7\\u9a71\\u52a8\\u7684\\u65b9\\u5f0f\\u53ef\\u4ee5\\u8f7b\\u677e\\u652f\\u6301\\u4e91\\u5e73\\u53f0\\u7684\\u90e8\\u7f72\\uff0c\\u8ba9\\u4f60\\u7684\\u7f51\\u7ad9\\u65e0\\u7f1d\\u8fc1\\u79fb\\uff0c\\u5185\\u7f6e\\u5df2\\u7ecf\\u652f\\u6301SAE\\u3001BAE\\uff0c\\u6b63\\u5f0f\\u7248\\u5c06\\u5bf9\\u4e91\\u7aef\\u90e8\\u7f72\\u8fdb\\u884c\\u8fdb\\u4e00\\u6b65\\u4f18\\u5316\\u3002\"},{\"title\":\"\\u5b89\\u5168\\u7b56\\u7565\",\"icon\":\"heart\",\"content\":\"\\u63d0\\u4f9b\\u7684\\u7a33\\u5065\\u7684\\u5b89\\u5168\\u7b56\\u7565\\uff0c\\u5305\\u62ec\\u5907\\u4efd\\u6062\\u590d\\uff0c\\u5bb9\\u9519\\uff0c\\u9632\\u6cbb\\u6076\\u610f\\u653b\\u51fb\\u767b\\u9646\\uff0c\\u7f51\\u9875\\u9632\\u7be1\\u6539\\u7b49\\u591a\\u9879\\u5b89\\u5168\\u7ba1\\u7406\\u529f\\u80fd\\uff0c\\u4fdd\\u8bc1\\u7cfb\\u7edf\\u5b89\\u5168\\uff0c\\u53ef\\u9760\\uff0c\\u7a33\\u5b9a\\u7684\\u8fd0\\u884c\\u3002\"},{\"title\":\"\\u5e94\\u7528\\u6a21\\u5757\\u5316\",\"icon\":\"cubes\",\"content\":\"\\u63d0\\u51fa\\u5168\\u65b0\\u7684\\u5e94\\u7528\\u6a21\\u5f0f\\u8fdb\\u884c\\u6269\\u5c55\\uff0c\\u4e0d\\u7ba1\\u662f\\u4f60\\u5f00\\u53d1\\u4e00\\u4e2a\\u5c0f\\u529f\\u80fd\\u8fd8\\u662f\\u4e00\\u4e2a\\u5168\\u65b0\\u7684\\u7ad9\\u70b9\\uff0c\\u5728ThinkCMF\\u4e2d\\u4f60\\u53ea\\u662f\\u589e\\u52a0\\u4e86\\u4e00\\u4e2aAPP\\uff0c\\u6bcf\\u4e2a\\u72ec\\u7acb\\u8fd0\\u884c\\u4e92\\u4e0d\\u5f71\\u54cd\\uff0c\\u4fbf\\u4e8e\\u7075\\u6d3b\\u6269\\u5c55\\u548c\\u4e8c\\u6b21\\u5f00\\u53d1\\u3002\"},{\"title\":\"\\u514d\\u8d39\\u5f00\\u6e90\",\"icon\":\"certificate\",\"content\":\"\\u4ee3\\u7801\\u9075\\u5faaApache2\\u5f00\\u6e90\\u534f\\u8bae\\uff0c\\u514d\\u8d39\\u4f7f\\u7528\\uff0c\\u5bf9\\u5546\\u4e1a\\u7528\\u6237\\u4e5f\\u65e0\\u4efb\\u4f55\\u9650\\u5236\\u3002\"}],\"type\":\"array\",\"item\":{\"title\":{\"title\":\"\\u6807\\u9898\",\"value\":\"\",\"type\":\"text\",\"rule\":{\"require\":true}},\"icon\":{\"title\":\"\\u56fe\\u6807\",\"value\":\"\",\"type\":\"text\"},\"content\":{\"title\":\"\\u63cf\\u8ff0\",\"value\":\"\",\"type\":\"textarea\"}},\"tip\":\"\"}}},\"last_news\":{\"title\":\"\\u6700\\u65b0\\u8d44\\u8baf\",\"display\":\"1\",\"vars\":{\"last_news_category_id\":{\"title\":\"\\u6587\\u7ae0\\u5206\\u7c7bID\",\"value\":\"\",\"type\":\"text\",\"dataSource\":{\"api\":\"portal\\/Category\\/index\",\"multi\":true},\"placeholder\":\"\\u8bf7\\u9009\\u62e9\\u5206\\u7c7b\",\"tip\":\"\",\"rule\":{\"require\":true}}}}}}","{\"vars\":{\"top_slide\":{\"title\":\"\\u9876\\u90e8\\u5e7b\\u706f\\u7247\",\"value\":\"\",\"type\":\"text\",\"dataSource\":{\"api\":\"admin\\/Slide\\/index\",\"multi\":false},\"placeholder\":\"\\u8bf7\\u9009\\u62e9\\u9876\\u90e8\\u5e7b\\u706f\\u7247\",\"tip\":\"\\u9876\\u90e8\\u5e7b\\u706f\\u7247\",\"rule\":{\"require\":true}}},\"widgets\":{\"features\":{\"title\":\"\\u5feb\\u901f\\u4e86\\u89e3ThinkCMF\",\"display\":\"1\",\"vars\":{\"sub_title\":{\"title\":\"\\u526f\\u6807\\u9898\",\"value\":\"Quickly understand the ThinkCMF\",\"type\":\"text\",\"placeholder\":\"\\u8bf7\\u8f93\\u5165\\u526f\\u6807\\u9898\",\"tip\":\"\",\"rule\":{\"require\":true}},\"features\":{\"title\":\"\\u7279\\u6027\\u4ecb\\u7ecd\",\"value\":[{\"title\":\"MVC\\u5206\\u5c42\\u6a21\\u5f0f\",\"icon\":\"bars\",\"content\":\"\\u4f7f\\u7528MVC\\u5e94\\u7528\\u7a0b\\u5e8f\\u88ab\\u5206\\u6210\\u4e09\\u4e2a\\u6838\\u5fc3\\u90e8\\u4ef6\\uff1a\\u6a21\\u578b\\uff08M\\uff09\\u3001\\u89c6\\u56fe\\uff08V\\uff09\\u3001\\u63a7\\u5236\\u5668\\uff08C\\uff09\\uff0c\\u4ed6\\u4e0d\\u662f\\u4e00\\u4e2a\\u65b0\\u7684\\u6982\\u5ff5\\uff0c\\u53ea\\u662fThinkCMF\\u5c06\\u5176\\u53d1\\u6325\\u5230\\u4e86\\u6781\\u81f4\\u3002\"},{\"title\":\"\\u7528\\u6237\\u7ba1\\u7406\",\"icon\":\"group\",\"content\":\"ThinkCMF\\u5185\\u7f6e\\u4e86\\u7075\\u6d3b\\u7684\\u7528\\u6237\\u7ba1\\u7406\\u65b9\\u5f0f\\uff0c\\u5e76\\u53ef\\u76f4\\u63a5\\u4e0e\\u7b2c\\u4e09\\u65b9\\u7ad9\\u70b9\\u8fdb\\u884c\\u4e92\\u8054\\u4e92\\u901a\\uff0c\\u5982\\u679c\\u4f60\\u613f\\u610f\\u751a\\u81f3\\u53ef\\u4ee5\\u5bf9\\u5355\\u4e2a\\u7528\\u6237\\u6216\\u7fa4\\u4f53\\u7528\\u6237\\u7684\\u884c\\u4e3a\\u8fdb\\u884c\\u8bb0\\u5f55\\u53ca\\u5206\\u4eab\\uff0c\\u4e3a\\u60a8\\u7684\\u8fd0\\u8425\\u51b3\\u7b56\\u63d0\\u4f9b\\u6709\\u6548\\u53c2\\u8003\\u6570\\u636e\\u3002\"},{\"title\":\"\\u4e91\\u7aef\\u90e8\\u7f72\",\"icon\":\"cloud\",\"content\":\"\\u901a\\u8fc7\\u9a71\\u52a8\\u7684\\u65b9\\u5f0f\\u53ef\\u4ee5\\u8f7b\\u677e\\u652f\\u6301\\u4e91\\u5e73\\u53f0\\u7684\\u90e8\\u7f72\\uff0c\\u8ba9\\u4f60\\u7684\\u7f51\\u7ad9\\u65e0\\u7f1d\\u8fc1\\u79fb\\uff0c\\u5185\\u7f6e\\u5df2\\u7ecf\\u652f\\u6301SAE\\u3001BAE\\uff0c\\u6b63\\u5f0f\\u7248\\u5c06\\u5bf9\\u4e91\\u7aef\\u90e8\\u7f72\\u8fdb\\u884c\\u8fdb\\u4e00\\u6b65\\u4f18\\u5316\\u3002\"},{\"title\":\"\\u5b89\\u5168\\u7b56\\u7565\",\"icon\":\"heart\",\"content\":\"\\u63d0\\u4f9b\\u7684\\u7a33\\u5065\\u7684\\u5b89\\u5168\\u7b56\\u7565\\uff0c\\u5305\\u62ec\\u5907\\u4efd\\u6062\\u590d\\uff0c\\u5bb9\\u9519\\uff0c\\u9632\\u6cbb\\u6076\\u610f\\u653b\\u51fb\\u767b\\u9646\\uff0c\\u7f51\\u9875\\u9632\\u7be1\\u6539\\u7b49\\u591a\\u9879\\u5b89\\u5168\\u7ba1\\u7406\\u529f\\u80fd\\uff0c\\u4fdd\\u8bc1\\u7cfb\\u7edf\\u5b89\\u5168\\uff0c\\u53ef\\u9760\\uff0c\\u7a33\\u5b9a\\u7684\\u8fd0\\u884c\\u3002\"},{\"title\":\"\\u5e94\\u7528\\u6a21\\u5757\\u5316\",\"icon\":\"cubes\",\"content\":\"\\u63d0\\u51fa\\u5168\\u65b0\\u7684\\u5e94\\u7528\\u6a21\\u5f0f\\u8fdb\\u884c\\u6269\\u5c55\\uff0c\\u4e0d\\u7ba1\\u662f\\u4f60\\u5f00\\u53d1\\u4e00\\u4e2a\\u5c0f\\u529f\\u80fd\\u8fd8\\u662f\\u4e00\\u4e2a\\u5168\\u65b0\\u7684\\u7ad9\\u70b9\\uff0c\\u5728ThinkCMF\\u4e2d\\u4f60\\u53ea\\u662f\\u589e\\u52a0\\u4e86\\u4e00\\u4e2aAPP\\uff0c\\u6bcf\\u4e2a\\u72ec\\u7acb\\u8fd0\\u884c\\u4e92\\u4e0d\\u5f71\\u54cd\\uff0c\\u4fbf\\u4e8e\\u7075\\u6d3b\\u6269\\u5c55\\u548c\\u4e8c\\u6b21\\u5f00\\u53d1\\u3002\"},{\"title\":\"\\u514d\\u8d39\\u5f00\\u6e90\",\"icon\":\"certificate\",\"content\":\"\\u4ee3\\u7801\\u9075\\u5faaApache2\\u5f00\\u6e90\\u534f\\u8bae\\uff0c\\u514d\\u8d39\\u4f7f\\u7528\\uff0c\\u5bf9\\u5546\\u4e1a\\u7528\\u6237\\u4e5f\\u65e0\\u4efb\\u4f55\\u9650\\u5236\\u3002\"}],\"type\":\"array\",\"item\":{\"title\":{\"title\":\"\\u6807\\u9898\",\"value\":\"\",\"type\":\"text\",\"rule\":{\"require\":true}},\"icon\":{\"title\":\"\\u56fe\\u6807\",\"value\":\"\",\"type\":\"text\"},\"content\":{\"title\":\"\\u63cf\\u8ff0\",\"value\":\"\",\"type\":\"textarea\"}},\"tip\":\"\"}}},\"last_news\":{\"title\":\"\\u6700\\u65b0\\u8d44\\u8baf\",\"display\":\"1\",\"vars\":{\"last_news_category_id\":{\"title\":\"\\u6587\\u7ae0\\u5206\\u7c7bID\",\"value\":\"\",\"type\":\"text\",\"dataSource\":{\"api\":\"portal\\/Category\\/index\",\"multi\":true},\"placeholder\":\"\\u8bf7\\u9009\\u62e9\\u5206\\u7c7b\",\"tip\":\"\",\"rule\":{\"require\":true}}}}}}","");
INSERT INTO cmf_theme_file VALUES("2","0","5","default","首页","portal/Index/index","portal/index","首页模板文件","{\"vars\":{\"top_slide\":{\"title\":\"\\u9876\\u90e8\\u5e7b\\u706f\\u7247\",\"value\":\"\",\"type\":\"text\",\"dataSource\":{\"api\":\"admin\\/Slide\\/index\",\"multi\":false},\"placeholder\":\"\\u8bf7\\u9009\\u62e9\\u9876\\u90e8\\u5e7b\\u706f\\u7247\",\"tip\":\"\\u9876\\u90e8\\u5e7b\\u706f\\u7247\",\"rule\":{\"require\":true}}},\"widgets\":{\"features\":{\"title\":\"\\u5feb\\u901f\\u4e86\\u89e3ThinkCMF\",\"display\":\"1\",\"vars\":{\"sub_title\":{\"title\":\"\\u526f\\u6807\\u9898\",\"value\":\"Quickly understand the ThinkCMF\",\"type\":\"text\",\"placeholder\":\"\\u8bf7\\u8f93\\u5165\\u526f\\u6807\\u9898\",\"tip\":\"\",\"rule\":{\"require\":true}},\"features\":{\"title\":\"\\u7279\\u6027\\u4ecb\\u7ecd\",\"value\":[{\"title\":\"MVC\\u5206\\u5c42\\u6a21\\u5f0f\",\"icon\":\"bars\",\"content\":\"\\u4f7f\\u7528MVC\\u5e94\\u7528\\u7a0b\\u5e8f\\u88ab\\u5206\\u6210\\u4e09\\u4e2a\\u6838\\u5fc3\\u90e8\\u4ef6\\uff1a\\u6a21\\u578b\\uff08M\\uff09\\u3001\\u89c6\\u56fe\\uff08V\\uff09\\u3001\\u63a7\\u5236\\u5668\\uff08C\\uff09\\uff0c\\u4ed6\\u4e0d\\u662f\\u4e00\\u4e2a\\u65b0\\u7684\\u6982\\u5ff5\\uff0c\\u53ea\\u662fThinkCMF\\u5c06\\u5176\\u53d1\\u6325\\u5230\\u4e86\\u6781\\u81f4\\u3002\"},{\"title\":\"\\u7528\\u6237\\u7ba1\\u7406\",\"icon\":\"group\",\"content\":\"ThinkCMF\\u5185\\u7f6e\\u4e86\\u7075\\u6d3b\\u7684\\u7528\\u6237\\u7ba1\\u7406\\u65b9\\u5f0f\\uff0c\\u5e76\\u53ef\\u76f4\\u63a5\\u4e0e\\u7b2c\\u4e09\\u65b9\\u7ad9\\u70b9\\u8fdb\\u884c\\u4e92\\u8054\\u4e92\\u901a\\uff0c\\u5982\\u679c\\u4f60\\u613f\\u610f\\u751a\\u81f3\\u53ef\\u4ee5\\u5bf9\\u5355\\u4e2a\\u7528\\u6237\\u6216\\u7fa4\\u4f53\\u7528\\u6237\\u7684\\u884c\\u4e3a\\u8fdb\\u884c\\u8bb0\\u5f55\\u53ca\\u5206\\u4eab\\uff0c\\u4e3a\\u60a8\\u7684\\u8fd0\\u8425\\u51b3\\u7b56\\u63d0\\u4f9b\\u6709\\u6548\\u53c2\\u8003\\u6570\\u636e\\u3002\"},{\"title\":\"\\u4e91\\u7aef\\u90e8\\u7f72\",\"icon\":\"cloud\",\"content\":\"\\u901a\\u8fc7\\u9a71\\u52a8\\u7684\\u65b9\\u5f0f\\u53ef\\u4ee5\\u8f7b\\u677e\\u652f\\u6301\\u4e91\\u5e73\\u53f0\\u7684\\u90e8\\u7f72\\uff0c\\u8ba9\\u4f60\\u7684\\u7f51\\u7ad9\\u65e0\\u7f1d\\u8fc1\\u79fb\\uff0c\\u5185\\u7f6e\\u5df2\\u7ecf\\u652f\\u6301SAE\\u3001BAE\\uff0c\\u6b63\\u5f0f\\u7248\\u5c06\\u5bf9\\u4e91\\u7aef\\u90e8\\u7f72\\u8fdb\\u884c\\u8fdb\\u4e00\\u6b65\\u4f18\\u5316\\u3002\"},{\"title\":\"\\u5b89\\u5168\\u7b56\\u7565\",\"icon\":\"heart\",\"content\":\"\\u63d0\\u4f9b\\u7684\\u7a33\\u5065\\u7684\\u5b89\\u5168\\u7b56\\u7565\\uff0c\\u5305\\u62ec\\u5907\\u4efd\\u6062\\u590d\\uff0c\\u5bb9\\u9519\\uff0c\\u9632\\u6cbb\\u6076\\u610f\\u653b\\u51fb\\u767b\\u9646\\uff0c\\u7f51\\u9875\\u9632\\u7be1\\u6539\\u7b49\\u591a\\u9879\\u5b89\\u5168\\u7ba1\\u7406\\u529f\\u80fd\\uff0c\\u4fdd\\u8bc1\\u7cfb\\u7edf\\u5b89\\u5168\\uff0c\\u53ef\\u9760\\uff0c\\u7a33\\u5b9a\\u7684\\u8fd0\\u884c\\u3002\"},{\"title\":\"\\u5e94\\u7528\\u6a21\\u5757\\u5316\",\"icon\":\"cubes\",\"content\":\"\\u63d0\\u51fa\\u5168\\u65b0\\u7684\\u5e94\\u7528\\u6a21\\u5f0f\\u8fdb\\u884c\\u6269\\u5c55\\uff0c\\u4e0d\\u7ba1\\u662f\\u4f60\\u5f00\\u53d1\\u4e00\\u4e2a\\u5c0f\\u529f\\u80fd\\u8fd8\\u662f\\u4e00\\u4e2a\\u5168\\u65b0\\u7684\\u7ad9\\u70b9\\uff0c\\u5728ThinkCMF\\u4e2d\\u4f60\\u53ea\\u662f\\u589e\\u52a0\\u4e86\\u4e00\\u4e2aAPP\\uff0c\\u6bcf\\u4e2a\\u72ec\\u7acb\\u8fd0\\u884c\\u4e92\\u4e0d\\u5f71\\u54cd\\uff0c\\u4fbf\\u4e8e\\u7075\\u6d3b\\u6269\\u5c55\\u548c\\u4e8c\\u6b21\\u5f00\\u53d1\\u3002\"},{\"title\":\"\\u514d\\u8d39\\u5f00\\u6e90\",\"icon\":\"certificate\",\"content\":\"\\u4ee3\\u7801\\u9075\\u5faaApache2\\u5f00\\u6e90\\u534f\\u8bae\\uff0c\\u514d\\u8d39\\u4f7f\\u7528\\uff0c\\u5bf9\\u5546\\u4e1a\\u7528\\u6237\\u4e5f\\u65e0\\u4efb\\u4f55\\u9650\\u5236\\u3002\"}],\"type\":\"array\",\"item\":{\"title\":{\"title\":\"\\u6807\\u9898\",\"value\":\"\",\"type\":\"text\",\"rule\":{\"require\":true}},\"icon\":{\"title\":\"\\u56fe\\u6807\",\"value\":\"\",\"type\":\"text\"},\"content\":{\"title\":\"\\u63cf\\u8ff0\",\"value\":\"\",\"type\":\"textarea\"}},\"tip\":\"\"}}},\"last_news\":{\"title\":\"\\u6700\\u65b0\\u8d44\\u8baf\",\"display\":\"1\",\"vars\":{\"last_news_category_id\":{\"title\":\"\\u6587\\u7ae0\\u5206\\u7c7bID\",\"value\":\"\",\"type\":\"text\",\"dataSource\":{\"api\":\"portal\\/Category\\/index\",\"multi\":true},\"placeholder\":\"\\u8bf7\\u9009\\u62e9\\u5206\\u7c7b\",\"tip\":\"\",\"rule\":{\"require\":true}}}}}}","{\"vars\":{\"top_slide\":{\"title\":\"\\u9876\\u90e8\\u5e7b\\u706f\\u7247\",\"value\":\"\",\"type\":\"text\",\"dataSource\":{\"api\":\"admin\\/Slide\\/index\",\"multi\":false},\"placeholder\":\"\\u8bf7\\u9009\\u62e9\\u9876\\u90e8\\u5e7b\\u706f\\u7247\",\"tip\":\"\\u9876\\u90e8\\u5e7b\\u706f\\u7247\",\"rule\":{\"require\":true}}},\"widgets\":{\"features\":{\"title\":\"\\u5feb\\u901f\\u4e86\\u89e3ThinkCMF\",\"display\":\"1\",\"vars\":{\"sub_title\":{\"title\":\"\\u526f\\u6807\\u9898\",\"value\":\"Quickly understand the ThinkCMF\",\"type\":\"text\",\"placeholder\":\"\\u8bf7\\u8f93\\u5165\\u526f\\u6807\\u9898\",\"tip\":\"\",\"rule\":{\"require\":true}},\"features\":{\"title\":\"\\u7279\\u6027\\u4ecb\\u7ecd\",\"value\":[{\"title\":\"MVC\\u5206\\u5c42\\u6a21\\u5f0f\",\"icon\":\"bars\",\"content\":\"\\u4f7f\\u7528MVC\\u5e94\\u7528\\u7a0b\\u5e8f\\u88ab\\u5206\\u6210\\u4e09\\u4e2a\\u6838\\u5fc3\\u90e8\\u4ef6\\uff1a\\u6a21\\u578b\\uff08M\\uff09\\u3001\\u89c6\\u56fe\\uff08V\\uff09\\u3001\\u63a7\\u5236\\u5668\\uff08C\\uff09\\uff0c\\u4ed6\\u4e0d\\u662f\\u4e00\\u4e2a\\u65b0\\u7684\\u6982\\u5ff5\\uff0c\\u53ea\\u662fThinkCMF\\u5c06\\u5176\\u53d1\\u6325\\u5230\\u4e86\\u6781\\u81f4\\u3002\"},{\"title\":\"\\u7528\\u6237\\u7ba1\\u7406\",\"icon\":\"group\",\"content\":\"ThinkCMF\\u5185\\u7f6e\\u4e86\\u7075\\u6d3b\\u7684\\u7528\\u6237\\u7ba1\\u7406\\u65b9\\u5f0f\\uff0c\\u5e76\\u53ef\\u76f4\\u63a5\\u4e0e\\u7b2c\\u4e09\\u65b9\\u7ad9\\u70b9\\u8fdb\\u884c\\u4e92\\u8054\\u4e92\\u901a\\uff0c\\u5982\\u679c\\u4f60\\u613f\\u610f\\u751a\\u81f3\\u53ef\\u4ee5\\u5bf9\\u5355\\u4e2a\\u7528\\u6237\\u6216\\u7fa4\\u4f53\\u7528\\u6237\\u7684\\u884c\\u4e3a\\u8fdb\\u884c\\u8bb0\\u5f55\\u53ca\\u5206\\u4eab\\uff0c\\u4e3a\\u60a8\\u7684\\u8fd0\\u8425\\u51b3\\u7b56\\u63d0\\u4f9b\\u6709\\u6548\\u53c2\\u8003\\u6570\\u636e\\u3002\"},{\"title\":\"\\u4e91\\u7aef\\u90e8\\u7f72\",\"icon\":\"cloud\",\"content\":\"\\u901a\\u8fc7\\u9a71\\u52a8\\u7684\\u65b9\\u5f0f\\u53ef\\u4ee5\\u8f7b\\u677e\\u652f\\u6301\\u4e91\\u5e73\\u53f0\\u7684\\u90e8\\u7f72\\uff0c\\u8ba9\\u4f60\\u7684\\u7f51\\u7ad9\\u65e0\\u7f1d\\u8fc1\\u79fb\\uff0c\\u5185\\u7f6e\\u5df2\\u7ecf\\u652f\\u6301SAE\\u3001BAE\\uff0c\\u6b63\\u5f0f\\u7248\\u5c06\\u5bf9\\u4e91\\u7aef\\u90e8\\u7f72\\u8fdb\\u884c\\u8fdb\\u4e00\\u6b65\\u4f18\\u5316\\u3002\"},{\"title\":\"\\u5b89\\u5168\\u7b56\\u7565\",\"icon\":\"heart\",\"content\":\"\\u63d0\\u4f9b\\u7684\\u7a33\\u5065\\u7684\\u5b89\\u5168\\u7b56\\u7565\\uff0c\\u5305\\u62ec\\u5907\\u4efd\\u6062\\u590d\\uff0c\\u5bb9\\u9519\\uff0c\\u9632\\u6cbb\\u6076\\u610f\\u653b\\u51fb\\u767b\\u9646\\uff0c\\u7f51\\u9875\\u9632\\u7be1\\u6539\\u7b49\\u591a\\u9879\\u5b89\\u5168\\u7ba1\\u7406\\u529f\\u80fd\\uff0c\\u4fdd\\u8bc1\\u7cfb\\u7edf\\u5b89\\u5168\\uff0c\\u53ef\\u9760\\uff0c\\u7a33\\u5b9a\\u7684\\u8fd0\\u884c\\u3002\"},{\"title\":\"\\u5e94\\u7528\\u6a21\\u5757\\u5316\",\"icon\":\"cubes\",\"content\":\"\\u63d0\\u51fa\\u5168\\u65b0\\u7684\\u5e94\\u7528\\u6a21\\u5f0f\\u8fdb\\u884c\\u6269\\u5c55\\uff0c\\u4e0d\\u7ba1\\u662f\\u4f60\\u5f00\\u53d1\\u4e00\\u4e2a\\u5c0f\\u529f\\u80fd\\u8fd8\\u662f\\u4e00\\u4e2a\\u5168\\u65b0\\u7684\\u7ad9\\u70b9\\uff0c\\u5728ThinkCMF\\u4e2d\\u4f60\\u53ea\\u662f\\u589e\\u52a0\\u4e86\\u4e00\\u4e2aAPP\\uff0c\\u6bcf\\u4e2a\\u72ec\\u7acb\\u8fd0\\u884c\\u4e92\\u4e0d\\u5f71\\u54cd\\uff0c\\u4fbf\\u4e8e\\u7075\\u6d3b\\u6269\\u5c55\\u548c\\u4e8c\\u6b21\\u5f00\\u53d1\\u3002\"},{\"title\":\"\\u514d\\u8d39\\u5f00\\u6e90\",\"icon\":\"certificate\",\"content\":\"\\u4ee3\\u7801\\u9075\\u5faaApache2\\u5f00\\u6e90\\u534f\\u8bae\\uff0c\\u514d\\u8d39\\u4f7f\\u7528\\uff0c\\u5bf9\\u5546\\u4e1a\\u7528\\u6237\\u4e5f\\u65e0\\u4efb\\u4f55\\u9650\\u5236\\u3002\"}],\"type\":\"array\",\"item\":{\"title\":{\"title\":\"\\u6807\\u9898\",\"value\":\"\",\"type\":\"text\",\"rule\":{\"require\":true}},\"icon\":{\"title\":\"\\u56fe\\u6807\",\"value\":\"\",\"type\":\"text\"},\"content\":{\"title\":\"\\u63cf\\u8ff0\",\"value\":\"\",\"type\":\"textarea\"}},\"tip\":\"\"}}},\"last_news\":{\"title\":\"\\u6700\\u65b0\\u8d44\\u8baf\",\"display\":\"1\",\"vars\":{\"last_news_category_id\":{\"title\":\"\\u6587\\u7ae0\\u5206\\u7c7bID\",\"value\":\"\",\"type\":\"text\",\"dataSource\":{\"api\":\"portal\\/Category\\/index\",\"multi\":true},\"placeholder\":\"\\u8bf7\\u9009\\u62e9\\u5206\\u7c7b\",\"tip\":\"\",\"rule\":{\"require\":true}}}}}}","");



DROP TABLE cmf_user;

CREATE TABLE `cmf_user` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_type` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '用户类型;1:admin;2:会员',
  `sex` tinyint(2) NOT NULL DEFAULT '0' COMMENT '性别;0:保密,1:男,2:女',
  `birthday` int(11) NOT NULL DEFAULT '0' COMMENT '生日',
  `last_login_time` int(11) NOT NULL DEFAULT '0' COMMENT '最后登录时间',
  `score` int(11) NOT NULL DEFAULT '0' COMMENT '用户积分',
  `coin` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '金币',
  `balance` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '余额',
  `create_time` int(11) NOT NULL DEFAULT '0' COMMENT '注册时间',
  `user_status` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '用户状态;0:禁用,1:正常,2:未验证',
  `user_login` varchar(60) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '用户名',
  `user_pass` varchar(64) NOT NULL DEFAULT '' COMMENT '登录密码;cmf_password加密',
  `user_nickname` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '用户昵称',
  `user_email` varchar(100) NOT NULL DEFAULT '' COMMENT '用户登录邮箱',
  `user_url` varchar(100) NOT NULL DEFAULT '' COMMENT '用户个人网址',
  `avatar` varchar(255) NOT NULL DEFAULT '' COMMENT '用户头像',
  `signature` varchar(255) NOT NULL DEFAULT '' COMMENT '个性签名',
  `last_login_ip` varchar(15) NOT NULL DEFAULT '' COMMENT '最后登录ip',
  `user_activation_key` varchar(60) NOT NULL DEFAULT '' COMMENT '激活码',
  `mobile` varchar(20) NOT NULL DEFAULT '' COMMENT '中国手机不带国家代码，国际手机号格式为：国家代码-手机号',
  `more` text COMMENT '扩展属性',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `user_login` (`user_login`) USING BTREE,
  KEY `user_nickname` (`user_nickname`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COMMENT='用户表';

INSERT INTO cmf_user VALUES("1","1","0","0","1730086167","0","0","0.00","1660558068","1","admin","###7a83c4a197d689babb621303f7f65c07","admin","admin@gmail.com","","","","113.248.218.136","","","");
INSERT INTO cmf_user VALUES("2","1","0","0","0","0","0","0.00","0","1","11","###c1f01d3d077d8c6d28de49cbadd1429e","","123456@qq.com","","","","","","","");



DROP TABLE cmf_user_login_attempt;

CREATE TABLE `cmf_user_login_attempt` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `login_attempts` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '尝试次数',
  `attempt_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '尝试登录时间',
  `locked_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '锁定时间',
  `ip` varchar(15) NOT NULL DEFAULT '' COMMENT '用户 ip',
  `account` varchar(100) NOT NULL DEFAULT '' COMMENT '用户账号,手机号,邮箱或用户名',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户登录尝试表';




DROP TABLE cmf_user_token;

CREATE TABLE `cmf_user_token` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '用户id',
  `expire_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT ' 过期时间',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `token` varchar(64) NOT NULL DEFAULT '' COMMENT 'token',
  `device_type` varchar(10) NOT NULL DEFAULT '' COMMENT '设备类型;mobile,android,iphone,ipad,web,pc,mac,wxapp',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COMMENT='用户客户端登录 token 表';

INSERT INTO cmf_user_token VALUES("1","1","1739756788","1724204788","4e2afa757800cccc3cca4448547c7732973a33993cc0b184729bab132dd56c36","web");



DROP TABLE cmf_verification_code;

CREATE TABLE `cmf_verification_code` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '表id',
  `count` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '当天已经发送成功的次数',
  `send_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '最后发送成功时间',
  `expire_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '验证码过期时间',
  `code` varchar(8) CHARACTER SET utf8 NOT NULL DEFAULT '' COMMENT '最后发送成功的验证码',
  `account` varchar(100) CHARACTER SET utf8 NOT NULL DEFAULT '' COMMENT '手机号或者邮箱',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='手机邮箱数字验证码表';




